package com.waseem.medical.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.waseem.medical.pro.data.Patient
import com.waseem.medical.pro.ui.*
import com.waseem.medical.pro.ui.screens.*
import com.waseem.medical.pro.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        // Enforce Arabic Right-to-Left (RTL) Layout Direction
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          MedicalClinicApp()
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicalClinicApp(viewModel: ClinicViewModel = viewModel()) {
  val context = LocalContext.current
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  val currentScreen by viewModel.currentScreen.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()
  val snackbarMessage by viewModel.snackbarMessage.collectAsState()
  val showSetupWizard by viewModel.showSetupWizard.collectAsState()
  val printPayload by viewModel.printPayload.collectAsState()
  val savedPatientShareModal by viewModel.savedPatientShareModal.collectAsState()

  val snackbarHostState = remember { SnackbarHostState() }

  // Reactive Snackbar handler
  LaunchedEffect(snackbarMessage) {
    snackbarMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  // Setup Wizard Dialog
  if (showSetupWizard) {
    SetupWizardDialog(
      currentProfile = centerProfile,
      onSave = { updated ->
        viewModel.saveFacilitySettings(updated)
      },
      onDismiss = { viewModel.toggleSetupWizard(false) }
    )
  }

  // Dual Save Share Modal
  savedPatientShareModal?.let { patient ->
    PatientShareModal(
      patient = patient,
      centerProfile = centerProfile,
      onDismiss = { viewModel.closeSavedPatientShareModal() },
      onSendWhatsApp = { phone, msg ->
        viewModel.sendWhatsApp(context, phone, msg)
      },
      onSendSMS = { phone, msg ->
        viewModel.sendSMS(context, phone, msg)
      },
      onOpenThermalPrint = { p ->
        val lines = listOf(
          "بطاقة مريض - ملف طبي",
          "--------------------------------",
          "رقم الملف: ${p.patientCode}",
          "الاسم: ${p.fullName}",
          "الهاتف: ${p.phone}",
          "العنوان: ${p.address.ifEmpty { "المدينة" }}",
          "العمر: ${p.age} سنة | الجنس: ${p.gender}",
          "طوارئ: ${p.emergencyRelation} (${p.emergencyPhone})",
          "--------------------------------",
          "تاريخ التسجيل: 2026-09-20"
        )
        viewModel.openPrintDialog(
          PrintPayload(
            type = "THERMAL_RECEIPT",
            title = "بطاقة تسجيل مريض جديد",
            contentLines = lines,
            docNumber = p.patientCode,
            patientName = p.fullName
          )
        )
      },
      onOpenA4Print = { p ->
        val lines = listOf(
          "استمارة فتح ملف واستقبال حالة طبية",
          "رقم السجل الطبي الموحد: ${p.patientCode}",
          "الاسم الرباعي: ${p.fullName}",
          "رقم الهاتف المحمول: ${p.phone}",
          "العنوان ومحل الإقامة: ${p.address.ifEmpty { "غير محدد" }}",
          "الجنس: ${p.gender} | تاريخ الميلاد / العمر: ${p.birthDate} (${p.age} سنة)",
          "بيانات الاتصال في حالات الطوارئ: ${p.emergencyRelation} - ${p.emergencyPhone}",
          "القسم الطبي المحال إليه: عام",
          "الملاحظات والتحسس الدوائي: ${p.notes.ifEmpty { "لا يوجد" }}",
          "--------------------------------------------------",
          "توقيع المريض / ولي الأمر: ......................",
          "ختم وتوقيع موظف الاستقبال: ......................"
        )
        viewModel.openPrintDialog(
          PrintPayload(
            type = "A4_INVOICE",
            title = "استمارة فتح ملف طبي رسمي",
            contentLines = lines,
            docNumber = p.patientCode,
            patientName = p.fullName
          )
        )
      }
    )
  }

  // Print Preview Dialog (Thermal or A4)
  printPayload?.let { payload ->
    PrintPreviewDialog(
      payload = payload,
      centerProfile = centerProfile,
      onDismiss = { viewModel.closePrintDialog() }
    )
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ClinicDrawerContent(
        currentScreen = currentScreen,
        centerProfile = centerProfile,
        onNavigate = { screen ->
          viewModel.navigateTo(screen)
        },
        onCloseDrawer = {
          scope.launch { drawerState.close() }
        }
      )
    }
  ) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        ClinicTopBar(
          currentScreen = currentScreen,
          centerProfile = centerProfile,
          onOpenDrawer = { scope.launch { drawerState.open() } },
          onQuickSearchClick = { viewModel.navigateTo(ClinicScreen.QUICK_SEARCH) },
          onSettingsClick = { viewModel.navigateTo(ClinicScreen.SETTINGS) }
        )
      },
      bottomBar = {
        ClinicBottomBar(
          currentScreen = currentScreen,
          onNavigate = { screen -> viewModel.navigateTo(screen) }
        )
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
          when (screen) {
            ClinicScreen.QUICK_SEARCH -> QuickSearchScreen(
              viewModel = viewModel,
              onNavigate = { viewModel.navigateTo(it) },
              onOpenPatient = { pId -> viewModel.openPatientDetails(pId) }
            )
            ClinicScreen.NEW_PATIENT -> NewPatientScreen(
              viewModel = viewModel,
              onOpenThermalPrint = { p ->
                val lines = listOf(
                  "بطاقة مريض - ملف طبي",
                  "رقم الملف: ${p.patientCode}",
                  "الاسم: ${p.fullName}",
                  "الهاتف: ${p.phone}",
                  "العمر: ${p.age} سنة"
                )
                viewModel.openPrintDialog(
                  PrintPayload(
                    type = "THERMAL_RECEIPT",
                    title = "بطاقة تسجيل مريض",
                    contentLines = lines,
                    docNumber = p.patientCode
                  )
                )
              },
              onOpenA4Print = { p ->
                val lines = listOf(
                  "استمارة استقبال وتسجيل حالة جديدة",
                  "رقم الملف الطبي: ${p.patientCode}",
                  "اسم المريض: ${p.fullName}",
                  "الهاتف: ${p.phone} | العنوان: ${p.address}",
                  "العمر: ${p.age} سنة | الجنس: ${p.gender}"
                )
                viewModel.openPrintDialog(
                  PrintPayload(
                    type = "A4_INVOICE",
                    title = "استمارة فتح ملف طبي رسمي",
                    contentLines = lines,
                    docNumber = p.patientCode
                  )
                )
              }
            )
            ClinicScreen.APPOINTMENTS -> AppointmentsScreen(viewModel = viewModel)
            ClinicScreen.PACKAGES -> PackagesScreen(viewModel = viewModel)
            ClinicScreen.PATIENTS -> PatientsScreen(
              viewModel = viewModel,
              onNavigate = { viewModel.navigateTo(it) },
              onOpenPatient = { pId -> viewModel.openPatientDetails(pId) }
            )
            ClinicScreen.STAFF -> StaffScreen(viewModel = viewModel)
            ClinicScreen.MEDICAL_STAFF -> MedicalStaffScreen(viewModel = viewModel)
            ClinicScreen.REPORTS -> ReportsScreen(viewModel = viewModel)
            ClinicScreen.FINANCE -> FinanceScreen(viewModel = viewModel)
            ClinicScreen.DEPARTMENTS -> DepartmentsScreen(viewModel = viewModel)
            ClinicScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
            ClinicScreen.BACKUP -> BackupScreen(viewModel = viewModel)
            ClinicScreen.TEMPLATES -> TemplatesScreen(viewModel = viewModel)
            ClinicScreen.SUPPORT -> SupportScreen(viewModel = viewModel)
            ClinicScreen.PATIENT_DETAILS -> PatientDetailsScreen(
              viewModel = viewModel,
              onBack = { viewModel.navigateTo(ClinicScreen.PATIENTS) }
            )
          }
        }
      }
    }
  }
}
