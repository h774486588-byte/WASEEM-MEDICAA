package com.waseem.medical.pro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.waseem.medical.pro.data.*
import com.waseem.medical.pro.ui.ClinicViewModel
import com.waseem.medical.pro.ui.DeveloperFooter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicalStaffScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val departments by viewModel.departments.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var showAddDialog by remember { mutableStateOf(false) }
  var staffForPayout by remember { mutableStateOf<MedicalStaff?>(null) }

  // Add dialog
  if (showAddDialog) {
    AddMedicalStaffDialog(
      departments = departments,
      onDismiss = { showAddDialog = false },
      onSave = { name, role, spec, deptId, phone, qual, contractType, share, salary ->
        viewModel.addMedicalStaff(name, role, spec, deptId, phone, qual, contractType, share, salary)
        showAddDialog = false
      }
    )
  }

  // Payout Dialog
  if (staffForPayout != null) {
    val doctor = staffForPayout!!
    PayDoctorDuesDialog(
      doctor = doctor,
      onDismiss = { staffForPayout = null },
      onConfirm = { amount, notes ->
        viewModel.addFinanceTransaction(
          docType = "سند صرف",
          amount = amount,
          paymentMethod = "نقداً",
          payerOrBeneficiary = doctor.name,
          patientId = null,
          doctorId = doctor.id,
          staffId = null,
          debitAccount = "مستحقات وأتعاب الأطباء والكوادر",
          creditAccount = "الصندوق الرئيسي (نقدية)",
          notes = "صرف أتعاب ${doctor.name} - $notes"
        )
        staffForPayout = null
      }
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "دليل الأطباء والكوادر الطبية والتمريض",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "إدارة النسب والرواتب وأرصدة المستحقات",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(
          onClick = { showAddDialog = true },
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("إضافة كادر")
        }
      }
    }

    // Doctor list
    items(medicalStaff) { doc ->
      val dept = departments.find { it.id == doc.departmentId }

      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = doc.name,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "${doc.role} - ${doc.specialty}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
              )
            }

            // Contract badge
            Surface(
              color = if (doc.contractType == "نسبة") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = if (doc.contractType == "نسبة") "نسبة: ${doc.sharePercent}%" else "راتب: ${doc.monthlySalary} ر.ي",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "🏥 القسم: ${dept?.name ?: "المركز الطبي"} | 📱 ${doc.phone}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          if (doc.qualification.isNotEmpty()) {
            Text(
              text = "المؤهل: ${doc.qualification}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.outline
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          // Dues Balance Highlight
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("رصيد الأتعاب والمستحقات المتبقية:", style = MaterialTheme.typography.bodySmall)
              Text(
                "${doc.balanceDues} ر.ي",
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              )
            }
          }

          Divider(modifier = Modifier.padding(vertical = 8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Button(
              onClick = { staffForPayout = doc },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("صرف أتعاب / دفعة")
            }

            IconButton(onClick = {
              viewModel.sendWhatsApp(context, doc.phone, "تحية طيبة د. ${doc.name}، من إدارة ${centerProfile?.facilityName}.")
            }) {
              Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color(0xFF25D366))
            }

            IconButton(onClick = { viewModel.callPhone(context, doc.phone) }) {
              Icon(Icons.Default.Call, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

/**
 * Dialog to add Medical Staff
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMedicalStaffDialog(
  departments: List<Department>,
  onDismiss: () -> Unit,
  onSave: (String, String, String, Long, String, String, String, Double, Double) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var role by remember { mutableStateOf("طبيب أخصائي") }
  var specialty by remember { mutableStateOf("") }
  var selectedDeptId by remember { mutableStateOf(departments.firstOrNull()?.id ?: 1L) }
  var phone by remember { mutableStateOf("") }
  var qualification by remember { mutableStateOf("") }
  var contractType by remember { mutableStateOf("نسبة") }
  var sharePercentText by remember { mutableStateOf("40") }
  var salaryText by remember { mutableStateOf("0") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("إضافة كادر طبي أو تمريضي جديد", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم الطبيب / الممرض *") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = role,
            onValueChange = { role = it },
            label = { Text("المسمى (استشاري/أخصائي/ممرض)") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = specialty,
            onValueChange = { specialty = it },
            label = { Text("التخصص الدقيق") },
            modifier = Modifier.weight(1f)
          )
        }

        // Dept
        var deptExpanded by remember { mutableStateOf(false) }
        val selDept = departments.find { it.id == selectedDeptId }
        ExposedDropdownMenuBox(expanded = deptExpanded, onExpandedChange = { deptExpanded = !deptExpanded }) {
          OutlinedTextField(
            value = selDept?.name ?: "اختر القسم",
            onValueChange = {},
            readOnly = true,
            label = { Text("القسم التابع له") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deptExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(expanded = deptExpanded, onDismissRequest = { deptExpanded = false }) {
            departments.forEach { d ->
              DropdownMenuItem(text = { Text(d.name) }, onClick = { selectedDeptId = d.id; deptExpanded = false })
            }
          }
        }

        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("رقم الهاتف") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = qualification,
          onValueChange = { qualification = it },
          label = { Text("المؤهل العلمي ورقم الترخيص") },
          modifier = Modifier.fillMaxWidth()
        )

        // Contract type: Share % or Fixed Salary
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = contractType == "نسبة",
            onClick = { contractType = "نسبة" },
            label = { Text("نظام النسبة %") }
          )
          FilterChip(
            selected = contractType == "راتب شهري",
            onClick = { contractType = "راتب شهري" },
            label = { Text("راتب شهري ثابت") }
          )
        }

        if (contractType == "نسبة") {
          OutlinedTextField(
            value = sharePercentText,
            onValueChange = { sharePercentText = it },
            label = { Text("نسبة الطبيب من الكشفية / الجلسة (%)") },
            modifier = Modifier.fillMaxWidth()
          )
        } else {
          OutlinedTextField(
            value = salaryText,
            onValueChange = { salaryText = it },
            label = { Text("الراتب الشهري (ر.ي)") },
            modifier = Modifier.fillMaxWidth()
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val share = sharePercentText.toDoubleOrNull() ?: 0.0
              val sal = salaryText.toDoubleOrNull() ?: 0.0
              if (name.isNotBlank()) {
                onSave(name, role, specialty, selectedDeptId, phone, qualification, contractType, share, sal)
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الكادر")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

/**
 * Payout Doctor Dues
 */
@Composable
fun PayDoctorDuesDialog(
  doctor: MedicalStaff,
  onDismiss: () -> Unit,
  onConfirm: (Double, String) -> Unit
) {
  var amountText by remember { mutableStateOf(doctor.balanceDues.toInt().toString()) }
  var notes by remember { mutableStateOf("صرف مستحقات أتعاب طبية") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("صرف أتعاب للطبيب: ${doctor.name}", fontWeight = FontWeight.Bold)
        Text("الرصيد المستحق الحالي: ${doctor.balanceDues} ر.ي", color = MaterialTheme.colorScheme.primary)

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("المبلغ المراد صرفه (ر.ي) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("البيان والملاحظات") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onConfirm(amt, notes)
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("إصدار سند صرف")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
