package com.waseem.medical.pro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.waseem.medical.pro.data.*
import com.waseem.medical.pro.ui.ClinicViewModel
import com.waseem.medical.pro.ui.DeveloperFooter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StaffScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val generalStaff by viewModel.generalStaff.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var showAddStaffDialog by remember { mutableStateOf(false) }
  var staffForSalaryPayment by remember { mutableStateOf<GeneralStaff?>(null) }

  // Add staff dialog
  if (showAddStaffDialog) {
    AddGeneralStaffDialog(
      onDismiss = { showAddStaffDialog = false },
      onSave = { name, title, dept, phone, id, addr, salary ->
        viewModel.addGeneralStaff(name, title, dept, phone, id, addr, salary)
        showAddStaffDialog = false
      }
    )
  }

  // Salary Payment Dialog
  if (staffForSalaryPayment != null) {
    val staff = staffForSalaryPayment!!
    PaySalaryDialog(
      staff = staff,
      onDismiss = { staffForSalaryPayment = null },
      onConfirm = { amount, type, notes ->
        viewModel.addFinanceTransaction(
          docType = "سند صرف",
          amount = amount,
          paymentMethod = "نقداً",
          payerOrBeneficiary = staff.fullName,
          patientId = null,
          doctorId = null,
          staffId = staff.id,
          debitAccount = "مصروفات رواتب وأجور ($type)",
          creditAccount = "الصندوق الرئيسي (نقدية)",
          notes = "$type للموظف ${staff.fullName} - $notes"
        )
        staffForSalaryPayment = null
      }
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "إدارة العاملين والموظفين",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "الاستقبال، المحاسبة، الإدارة والخدمات المساندة",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(
          onClick = { showAddStaffDialog = true },
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("إضافة موظف")
        }
      }
    }

    // Stats Bar
    item {
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("إجمالي الكادر الإداري والمساند:", fontWeight = FontWeight.Bold)
          Text("${generalStaff.size} موظف", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
      }
    }

    // Staff List
    items(generalStaff) { staff ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(staff.fullName, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
              Text(
                text = "${staff.jobTitle} | ${staff.department}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Surface(
              color = Color(0xFFDCFCE7),
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = "${staff.monthlySalary} ر.ي",
                color = Color(0xFF166534),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "📱 هاتف: ${staff.phone} | الهوية: ${staff.nationalId.ifEmpty { "مسجلة" }}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "تاريخ التعيين: ${staff.hireDate} | العنوان: ${staff.address}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
          )

          Divider(modifier = Modifier.padding(vertical = 8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Button(
              onClick = { staffForSalaryPayment = staff },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("صرف راتب / سلفة")
            }

            IconButton(onClick = {
              viewModel.sendWhatsApp(context, staff.phone, "السلام عليكم أخي ${staff.fullName}، من إدارة ${centerProfile?.facilityName}.")
            }) {
              Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color(0xFF25D366))
            }

            IconButton(onClick = { viewModel.callPhone(context, staff.phone) }) {
              Icon(Icons.Default.Call, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.primary)
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

/**
 * Dialog to add a general staff employee
 */
@Composable
fun AddGeneralStaffDialog(
  onDismiss: () -> Unit,
  onSave: (String, String, String, String, String, String, Double) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var jobTitle by remember { mutableStateOf("موظف استقبال") }
  var department by remember { mutableStateOf("الاستقبال والعملاء") }
  var phone by remember { mutableStateOf("") }
  var nationalId by remember { mutableStateOf("") }
  var address by remember { mutableStateOf("") }
  var salaryText by remember { mutableStateOf("120000") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("إضافة موظف إداري جديد", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("الاسم الكامل *") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = jobTitle,
            onValueChange = { jobTitle = it },
            label = { Text("المسمى الوظيفي") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = department,
            onValueChange = { department = it },
            label = { Text("القسم") },
            modifier = Modifier.weight(1f)
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("رقم الهاتف") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = salaryText,
            onValueChange = { salaryText = it },
            label = { Text("الراتب الشهري (ر.ي)") },
            modifier = Modifier.weight(1f)
          )
        }

        OutlinedTextField(
          value = nationalId,
          onValueChange = { nationalId = it },
          label = { Text("الرقم الوطني / الهوية") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("العنوان السكني") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val s = salaryText.toDoubleOrNull() ?: 100000.0
              if (name.isNotBlank()) {
                onSave(name, jobTitle, department, phone, nationalId, address, s)
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الموظف")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

/**
 * Dialog to pay salary or advance
 */
@Composable
fun PaySalaryDialog(
  staff: GeneralStaff,
  onDismiss: () -> Unit,
  onConfirm: (Double, String, String) -> Unit
) {
  var payType by remember { mutableStateOf("راتب شهري") }
  var amountText by remember { mutableStateOf(staff.monthlySalary.toInt().toString()) }
  var notes by remember { mutableStateOf("عن شهر العمل الحالي") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("صرف مالي للموظف: ${staff.fullName}", fontWeight = FontWeight.Bold)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = payType == "راتب شهري",
            onClick = {
              payType = "راتب شهري"
              amountText = staff.monthlySalary.toInt().toString()
            },
            label = { Text("راتب شهري") }
          )
          FilterChip(
            selected = payType == "سلفة",
            onClick = {
              payType = "سلفة"
              amountText = "30000"
            },
            label = { Text("سلفة على الحساب") }
          )
          FilterChip(
            selected = payType == "مكافأة",
            onClick = {
              payType = "مكافأة"
              amountText = "15000"
            },
            label = { Text("مكافأة تشجيعية") }
          )
        }

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = it },
          label = { Text("المبلغ المنصرف (ر.ي) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("البيان والملاحظات") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull() ?: 0.0
              if (amt > 0) {
                onConfirm(amt, payType, notes)
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("إصدار سند صرف")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
