package com.waseem.medical.pro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.waseem.medical.pro.data.*
import com.waseem.medical.pro.ui.ClinicViewModel
import com.waseem.medical.pro.ui.DeveloperFooter
import com.waseem.medical.pro.ui.PrintPayload
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val patients by viewModel.patients.collectAsState()
  val appointments by viewModel.appointments.collectAsState()
  val patientPackages by viewModel.patientPackages.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val financeTransactions by viewModel.financeTransactions.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var selectedTab by remember { mutableStateOf(0) } // 0: Operational, 1: Financial

  // Operational calculations
  val attendedAppointments = appointments.count { it.status == "تم الحضور" || it.status == "مكتمل" }
  val waitingAppointments = appointments.count { it.status == "في الانتظار" || it.status == "مؤكد" }
  val noShowAppointments = appointments.count { it.status == "لم يحضر" || it.status == "ملغي" }

  // Financial calculations
  val totalReceipts = financeTransactions.filter { it.docType == "سند قبض" }.sumOf { it.amount }
  val totalExpenses = financeTransactions.filter { it.docType == "سند صرف" }.sumOf { it.amount }
  val netIncome = totalReceipts - totalExpenses
  val totalDoctorDues = medicalStaff.sumOf { it.balanceDues }

  val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "مركز التقارير والإحصائيات",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "تحليلات تشغيلية ومالية مع تصدير وطباعة A4 / حراري",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          // Thermal summary print
          Button(
            onClick = {
              val lines = mutableListOf<String>()
              lines.add("ملخص التقارير اليومية - $today")
              lines.add("--------------------------------")
              lines.add("إجمالي المرضى: ${patients.size}")
              lines.add("المواعيد المحققة: $attendedAppointments")
              lines.add("إيرادات المقبوضات: $totalReceipts ر.ي")
              lines.add("إجمالي المصروفات: $totalExpenses ر.ي")
              lines.add("صافي الدخل: $netIncome ر.ي")
              lines.add("--------------------------------")
              lines.add("أرصدة الأطباء المتبقية: $totalDoctorDues ر.ي")

              viewModel.openPrintDialog(
                PrintPayload(
                  type = "THERMAL_RECEIPT",
                  title = "ملخص التقرير المالي والتشغيلي",
                  contentLines = lines,
                  docNumber = "REP-$today",
                  date = today
                )
              )
            },
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("طباعة الملخص")
          }
        }
      }
    }

    // Tabs: التشغيلية / المالية
    item {
      TabRow(selectedTabIndex = selectedTab) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("التقارير التشغيلية") }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("التقارير المالية والأرباح") }
        )
      }
    }

    if (selectedTab == 0) {
      // OPERATIONAL REPORTS
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("1. إحصائيات حركة المواعيد والحضور:", fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              StatBlock(title = "مواعيد مكتملة", value = "$attendedAppointments", color = Color(0xFF16A34A), modifier = Modifier.weight(1f))
              StatBlock(title = "في الانتظار", value = "$waitingAppointments", color = Color(0xFFD97706), modifier = Modifier.weight(1f))
              StatBlock(title = "لم يحضر / ملغي", value = "$noShowAppointments", color = Color(0xFFDC2626), modifier = Modifier.weight(1f))
            }
          }
        }
      }

      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("2. تقرير إنتاجية الأطباء والكوادر:", fontWeight = FontWeight.Bold)
            medicalStaff.forEach { doc ->
              val docAppointments = appointments.count { it.doctorId == doc.id }
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text("${doc.name} (${doc.specialty})", style = MaterialTheme.typography.bodySmall)
                Text("$docAppointments حالة / موعد", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
              }
              Divider()
            }
          }
        }
      }

      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("3. تقرير استهلاك الباقات والجلسات:", fontWeight = FontWeight.Bold)
            val totalSessionsCount = patientPackages.sumOf { it.totalSessions }
            val totalUsedCount = patientPackages.sumOf { it.usedSessions }
            val totalRemainingCount = patientPackages.sumOf { it.remainingSessions }

            Text("إجمالي الجلسات المسجلة: $totalSessionsCount جلسة", style = MaterialTheme.typography.bodySmall)
            Text("الجلسات المنجزة والمستهلكة: $totalUsedCount جلسة", style = MaterialTheme.typography.bodySmall)
            Text("الجلسات المتبقية في رصيد المرضى: $totalRemainingCount جلسة", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
          }
        }
      }
    } else {
      // FINANCIAL REPORTS
      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("قائمة الدخل وصافي الأرباح:", fontWeight = FontWeight.Bold)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              StatBlock(title = "إجمالي الإيرادات", value = "$totalReceipts ر.ي", color = Color(0xFF16A34A), modifier = Modifier.weight(1f))
              StatBlock(title = "إجمالي المصروفات", value = "$totalExpenses ر.ي", color = Color(0xFFDC2626), modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
              color = if (netIncome >= 0) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text("صافي الفائض / الأرباح:", fontWeight = FontWeight.Bold)
                Text(
                  "$netIncome ر.ي",
                  fontWeight = FontWeight.Bold,
                  color = if (netIncome >= 0) Color(0xFF166534) else Color(0xFF991B1B)
                )
              }
            }
          }
        }
      }

      item {
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("مستحقات وأرصدة الأطباء المحصلة:", fontWeight = FontWeight.Bold)
            medicalStaff.forEach { doc ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(doc.name, style = MaterialTheme.typography.bodySmall)
                Text("${doc.balanceDues} ر.ي", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
              }
              Divider()
            }
          }
        }
      }

      item {
        // WhatsApp Share of Financial Summary
        Button(
          onClick = {
            val msg = "تقرير مالي رسمي من ${centerProfile?.facilityName}:\n📅 التاريخ: $today\n💰 إجمالي الإيرادات: $totalReceipts ر.ي\n💸 إجمالي المصروفات: $totalExpenses ر.ي\n📈 صافي الربح: $netIncome ر.ي\nتطوير: وسيم الفرح | هاتف: 774486588"
            viewModel.sendWhatsApp(context, centerProfile?.phone1 ?: "774486588", msg)
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
        ) {
          Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text("مشاركة التقرير المالي عبر الواتساب", color = Color.White, fontWeight = FontWeight.Bold)
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

@Composable
private fun StatBlock(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
  Surface(
    color = color.copy(alpha = 0.1f),
    shape = RoundedCornerShape(10.dp),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color))
      Text(text = title, style = MaterialTheme.typography.labelSmall, color = color)
    }
  }
}
