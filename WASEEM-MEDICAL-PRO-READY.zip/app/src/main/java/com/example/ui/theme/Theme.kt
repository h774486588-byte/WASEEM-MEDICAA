package com.waseem.medical.pro.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
  primary = MedicalTealPrimary,
  onPrimary = MedicalTealOnPrimary,
  primaryContainer = MedicalTealContainer,
  onPrimaryContainer = MedicalTealOnContainer,
  secondary = MedicalSlateSecondary,
  onSecondary = Color.White,
  secondaryContainer = MedicalSlateContainer,
  onSecondaryContainer = MedicalSlateOnContainer,
  tertiary = MedicalBlueTertiary,
  onTertiary = Color.White,
  tertiaryContainer = MedicalBlueContainer,
  onTertiaryContainer = MedicalBlueOnContainer,
  background = MedicalBackground,
  onBackground = Color(0xFF171D1E),
  surface = MedicalSurface,
  onSurface = Color(0xFF171D1E),
  surfaceVariant = MedicalSurfaceVariant,
  onSurfaceVariant = Color(0xFF3F484A),
  outline = MedicalOutline,
  outlineVariant = MedicalOutlineVariant
)

private val DarkColorScheme = darkColorScheme(
  primary = MedicalDarkPrimary,
  onPrimary = Color(0xFF00373A),
  primaryContainer = Color(0xFF004F53),
  onPrimaryContainer = MedicalTealContainer,
  secondary = MedicalDarkSecondary,
  onSecondary = Color(0xFF1C3538),
  secondaryContainer = Color(0xFF324B4F),
  onSecondaryContainer = MedicalSlateContainer,
  tertiary = Color(0xFF8DCDFF),
  onTertiary = Color(0xFF003450),
  tertiaryContainer = Color(0xFF004B71),
  onTertiaryContainer = MedicalBlueContainer,
  background = MedicalDarkBackground,
  onBackground = Color(0xFFDEE4E5),
  surface = MedicalDarkSurface,
  onSurface = Color(0xFFDEE4E5),
  surfaceVariant = MedicalDarkSurfaceVariant,
  onSurfaceVariant = Color(0xFFBEC8C9)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use our tailored clinical palette by default
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
