package com.waseem.medical.pro.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.waseem.medical.pro.data.*
import com.waseem.medical.pro.ui.*
import java.text.SimpleDateFormat
import java.util.*

enum class AppointmentViewMode { DAILY, WEEKLY, MONTHLY }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentsScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val appointments by viewModel.appointments.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val departments by viewModel.departments.collectAsState()
  val services by viewModel.services.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var viewMode by remember { mutableStateOf(AppointmentViewMode.DAILY) }
  var showBookingDialog by remember { mutableStateOf(false) }
  var conflictList by remember { mutableStateOf<List<Appointment>>(emptyList()) }
  var showConflictDialog by remember { mutableStateOf(false) }

  // Filter date
  val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
  var selectedDate by remember { mutableStateOf(todayStr) }

  val filteredAppointments = remember(appointments, viewMode, selectedDate) {
    when (viewMode) {
      AppointmentViewMode.DAILY -> appointments.filter { it.appointmentDate == selectedDate }
      AppointmentViewMode.WEEKLY -> appointments // in full week window
      AppointmentViewMode.MONTHLY -> appointments // full month
    }
  }

  // Conflict Alert Dialog
  if (showConflictDialog && conflictList.isNotEmpty()) {
    ConflictAlertDialog(
      conflicts = conflictList,
      onDismiss = { showConflictDialog = false }
    )
  }

  // Booking Dialog
  if (showBookingDialog) {
    NewAppointmentDialog(
      patients = patients,
      departments = departments,
      services = services,
      medicalStaff = medicalStaff,
      defaultDate = selectedDate,
      onDismiss = { showBookingDialog = false },
      onBook = { patientId, patientName, patientPhone, deptId, deptName, srvId, srvName, docId, docName, date, start, end, notes ->
        viewModel.bookAppointment(
          patientId = patientId,
          patientName = patientName,
          patientPhone = patientPhone,
          departmentId = deptId,
          departmentName = deptName,
          serviceId = srvId,
          serviceName = srvName,
          doctorId = docId,
          doctorName = docName,
          date = date,
          startTime = start,
          endTime = end,
          notes = notes,
          onConflictDetected = { conflicts ->
            conflictList = conflicts
            showConflictDialog = true
          },
          onSuccess = {
            showBookingDialog = false
          }
        )
      }
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Controls Bar: View Switcher (Daily, Weekly, Monthly) + Add Button
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      SingleChoiceSegmentedButtonRow {
        SegmentedButton(
          selected = viewMode == AppointmentViewMode.DAILY,
          onClick = { viewMode = AppointmentViewMode.DAILY },
          shape = SegmentedButtonDefaults.itemShape(index = 0, count = 3)
        ) {
          Text("يومي")
        }
        SegmentedButton(
          selected = viewMode == AppointmentViewMode.WEEKLY,
          onClick = { viewMode = AppointmentViewMode.WEEKLY },
          shape = SegmentedButtonDefaults.itemShape(index = 1, count = 3)
        ) {
          Text("أسبوعي")
        }
        SegmentedButton(
          selected = viewMode == AppointmentViewMode.MONTHLY,
          onClick = { viewMode = AppointmentViewMode.MONTHLY },
          shape = SegmentedButtonDefaults.itemShape(index = 2, count = 3)
        ) {
          Text("شهري")
        }
      }

      Button(
        onClick = { showBookingDialog = true },
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("حجز موعد")
      }
    }

    // Action Row: Quick Print Agenda & WhatsApp Reminders
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      OutlinedButton(
        onClick = {
          // Print daily agenda
          val lines = mutableListOf<String>()
          lines.add("جدول مواعيد التاريخ: $selectedDate")
          lines.add("--------------------------------")
          filteredAppointments.forEach { appt ->
            lines.add("${appt.startTime} - ${appt.patientName} | د. ${appt.doctorName} [${appt.status}]")
          }
          lines.add("--------------------------------")
          lines.add("إجمالي المواعيد: ${filteredAppointments.size}")

          viewModel.openPrintDialog(
            PrintPayload(
              type = "THERMAL_APPOINTMENTS",
              title = "جدول المواعيد اليومي",
              contentLines = lines,
              docNumber = "APT-LIST-${selectedDate}",
              date = selectedDate
            )
          )
        },
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("طباعة الجدول")
      }

      OutlinedButton(
        onClick = {
          // Send bulk or notify first waiting
          val firstWaiting = filteredAppointments.find { it.status == "في الانتظار" || it.status == "مؤكد" }
          if (firstWaiting != null) {
            val msg = "مرحباً ${firstWaiting.patientName} 🌸، نود تذكيركم بموعدكم القادم في ${centerProfile?.facilityName} اليوم الساعة ${firstWaiting.startTime} لدى ${firstWaiting.doctorName} لخدمة ${firstWaiting.serviceName}."
            viewModel.sendWhatsApp(context, firstWaiting.patientPhone, msg)
          } else {
            viewModel.showMessage("لا يوجد موعد بالانتظار لإرسال تذكير")
          }
        },
        modifier = Modifier.weight(1f)
      ) {
        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF25D366))
        Spacer(modifier = Modifier.width(4.dp))
        Text("تذكير واتساب")
      }
    }

    // Appointments Count Header
    Surface(
      color = MaterialTheme.colorScheme.surfaceVariant,
      shape = RoundedCornerShape(10.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (viewMode == AppointmentViewMode.DAILY) "مواعيد اليوم ($selectedDate)" else "كافة مواعيد الأجندة",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "${filteredAppointments.size} موعد",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }
    }

    // List of appointments
    if (filteredAppointments.isEmpty()) {
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth(),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.EventBusy, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
          Spacer(modifier = Modifier.height(8.dp))
          Text("لا توجد مواعيد مسجلة لهذه الفترة", color = MaterialTheme.colorScheme.outline)
          Spacer(modifier = Modifier.height(12.dp))
          Button(onClick = { showBookingDialog = true }) {
            Text("إضافة أول موعد الآن")
          }
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(filteredAppointments) { appt ->
          AppointmentCard(
            appointment = appt,
            onStatusChange = { newStatus ->
              viewModel.updateAppointmentStatus(appt, newStatus)
            },
            onWhatsAppReminder = {
              val msg = "عزيزي ${appt.patientName}، نذكرك بموعدك في ${centerProfile?.facilityName} بتاريخ ${appt.appointmentDate} الساعة ${appt.startTime} مع ${appt.doctorName}."
              viewModel.sendWhatsApp(context, appt.patientPhone, msg)
            },
            onDelete = { viewModel.deleteAppointment(appt) }
          )
        }

        item {
          DeveloperFooter()
        }
      }
    }
  }
}

@Composable
fun AppointmentCard(
  appointment: Appointment,
  onStatusChange: (String) -> Unit,
  onWhatsAppReminder: () -> Unit,
  onDelete: () -> Unit
) {
  var expandedStatusMenu by remember { mutableStateOf(false) }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = appointment.appointmentCode,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = appointment.patientName,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }

        // Status badge clickable to change
        Box {
          Surface(
            modifier = Modifier.clickable { expandedStatusMenu = true }
          ) {
            StatusBadge(status = appointment.status)
          }
          DropdownMenu(
            expanded = expandedStatusMenu,
            onDismissRequest = { expandedStatusMenu = false }
          ) {
            listOf("في الانتظار", "تم الحضور", "مؤكد", "لم يحضر", "ملغي", "مكتمل").forEach { s ->
              DropdownMenuItem(
                text = { Text(s) },
                onClick = {
                  onStatusChange(s)
                  expandedStatusMenu = false
                }
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Doctor, Dept & Service
      Text(
        text = "🩺 ${appointment.serviceName} | 👨‍⚕️ ${appointment.doctorName}",
        style = MaterialTheme.typography.bodyMedium
      )
      Text(
        text = "🏥 ${appointment.departmentName}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      // Time & Notes
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "${appointment.appointmentDate} | ${appointment.startTime} - ${appointment.endTime}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(onClick = onWhatsAppReminder, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Send, contentDescription = "تذكير واتساب", tint = Color(0xFF25D366), modifier = Modifier.size(18.dp))
          }
          IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
          }
        }
      }

      if (appointment.notes.isNotEmpty()) {
        Text(
          text = "ملاحظات: ${appointment.notes}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.outline,
          modifier = Modifier.padding(top = 4.dp)
        )
      }
    }
  }
}

/**
 * Booking Dialog with real-time Doctor & Patient selection
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewAppointmentDialog(
  patients: List<Patient>,
  departments: List<Department>,
  services: List<MedicalService>,
  medicalStaff: List<MedicalStaff>,
  defaultDate: String,
  onDismiss: () -> Unit,
  onBook: (Long, String, String, Long, String, Long, String, Long, String, String, String, String, String) -> Unit
) {
  var selectedPatientId by remember { mutableStateOf<Long?>(patients.firstOrNull()?.id) }
  var selectedDeptId by remember { mutableStateOf<Long?>(departments.firstOrNull()?.id) }
  var selectedServiceId by remember { mutableStateOf<Long?>(null) }
  var selectedDoctorId by remember { mutableStateOf<Long?>(medicalStaff.firstOrNull()?.id) }
  var date by remember { mutableStateOf(defaultDate) }
  var startTime by remember { mutableStateOf("10:00") }
  var endTime by remember { mutableStateOf("10:30") }
  var notes by remember { mutableStateOf("") }

  val filteredServices = remember(selectedDeptId, services) {
    if (selectedDeptId == null) services
    else services.filter { it.departmentId == selectedDeptId }
  }

  val filteredDoctors = remember(selectedDeptId, medicalStaff) {
    if (selectedDeptId == null) medicalStaff
    else {
      val inDept = medicalStaff.filter { it.departmentId == selectedDeptId }
      if (inDept.isNotEmpty()) inDept else medicalStaff
    }
  }

  LaunchedEffect(filteredServices) {
    if (filteredServices.isNotEmpty()) selectedServiceId = filteredServices.first().id
  }
  LaunchedEffect(filteredDoctors) {
    if (filteredDoctors.isNotEmpty()) selectedDoctorId = filteredDoctors.first().id
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.9f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = "حجز موعد طبي جديد (مع فحص منع التعارض)",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )

        // Patient Selector
        var patientExpanded by remember { mutableStateOf(false) }
        val selPatient = patients.find { it.id == selectedPatientId }
        val patientText = selPatient?.let { "${it.patientCode} - ${it.fullName}" } ?: "اختر المريض"

        ExposedDropdownMenuBox(
          expanded = patientExpanded,
          onExpandedChange = { patientExpanded = !patientExpanded }
        ) {
          OutlinedTextField(
            value = patientText,
            onValueChange = {},
            readOnly = true,
            label = { Text("المريض *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = patientExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = patientExpanded,
            onDismissRequest = { patientExpanded = false }
          ) {
            patients.forEach { p ->
              DropdownMenuItem(
                text = { Text("${p.patientCode} - ${p.fullName} (${p.phone})") },
                onClick = {
                  selectedPatientId = p.id
                  patientExpanded = false
                }
              )
            }
          }
        }

        // Department
        var deptExpanded by remember { mutableStateOf(false) }
        val selDept = departments.find { it.id == selectedDeptId }

        ExposedDropdownMenuBox(
          expanded = deptExpanded,
          onExpandedChange = { deptExpanded = !deptExpanded }
        ) {
          OutlinedTextField(
            value = selDept?.name ?: "اختر القسم",
            onValueChange = {},
            readOnly = true,
            label = { Text("القسم الطبي") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deptExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = deptExpanded,
            onDismissRequest = { deptExpanded = false }
          ) {
            departments.forEach { d ->
              DropdownMenuItem(
                text = { Text(d.name) },
                onClick = {
                  selectedDeptId = d.id
                  deptExpanded = false
                }
              )
            }
          }
        }

        // Service
        var srvExpanded by remember { mutableStateOf(false) }
        val selSrv = filteredServices.find { it.id == selectedServiceId }

        ExposedDropdownMenuBox(
          expanded = srvExpanded,
          onExpandedChange = { srvExpanded = !srvExpanded }
        ) {
          OutlinedTextField(
            value = selSrv?.let { "${it.name} (${it.defaultPrice} ر.ي)" } ?: "اختر الخدمة",
            onValueChange = {},
            readOnly = true,
            label = { Text("الخدمة الطبية") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = srvExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = srvExpanded,
            onDismissRequest = { srvExpanded = false }
          ) {
            filteredServices.forEach { s ->
              DropdownMenuItem(
                text = { Text("${s.name} - ${s.defaultPrice} ر.ي") },
                onClick = {
                  selectedServiceId = s.id
                  srvExpanded = false
                }
              )
            }
          }
        }

        // Doctor
        var docExpanded by remember { mutableStateOf(false) }
        val selDoc = filteredDoctors.find { it.id == selectedDoctorId }

        ExposedDropdownMenuBox(
          expanded = docExpanded,
          onExpandedChange = { docExpanded = !docExpanded }
        ) {
          OutlinedTextField(
            value = selDoc?.name ?: "اختر الطبيب",
            onValueChange = {},
            readOnly = true,
            label = { Text("الطبيب المعالج *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = docExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = docExpanded,
            onDismissRequest = { docExpanded = false }
          ) {
            filteredDoctors.forEach { d ->
              DropdownMenuItem(
                text = { Text("${d.name} (${d.specialty})") },
                onClick = {
                  selectedDoctorId = d.id
                  docExpanded = false
                }
              )
            }
          }
        }

        // Date and Time
        OutlinedTextField(
          value = date,
          onValueChange = { date = it },
          label = { Text("تاريخ الموعد (YYYY-MM-DD)") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = startTime,
            onValueChange = { startTime = it },
            label = { Text("وقت البداية") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = endTime,
            onValueChange = { endTime = it },
            label = { Text("وقت النهاية") },
            modifier = Modifier.weight(1f)
          )
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات إضافية للحجز") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val p = selPatient ?: return@Button
              val d = selDept ?: departments.first()
              val s = selSrv ?: filteredServices.firstOrNull() ?: MedicalService(departmentId = d.id, name = "كشفية عامة", defaultPrice = 3000.0)
              val doc = selDoc ?: filteredDoctors.first()

              onBook(
                p.id,
                p.fullName,
                p.phone,
                d.id,
                d.name,
                s.id,
                s.name,
                doc.id,
                doc.name,
                date,
                startTime,
                endTime,
                notes
              )
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("تأكيد وفحص التعارض")
          }

          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
