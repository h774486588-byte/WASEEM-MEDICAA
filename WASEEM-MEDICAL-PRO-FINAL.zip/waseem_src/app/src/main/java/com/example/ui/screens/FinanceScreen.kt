package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.ConfirmActionDialog
import com.example.ui.DeveloperFooter
import com.example.ui.PrintPayload
import com.example.ui.formatAmountInput
import com.example.ui.parseAmountInput

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val transactions by viewModel.financeTransactions.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val generalStaff by viewModel.generalStaff.collectAsState()
  val chartOfAccounts by viewModel.chartOfAccounts.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var showNewVoucherDialog by remember { mutableStateOf(false) }
  var voucherType by remember { mutableStateOf("سند قبض") } // "سند قبض" or "سند صرف"
  var searchQuery by remember { mutableStateOf("") }
  var filterType by remember { mutableStateOf("الكل") }

  // Voiding dialog state
  var transactionToVoid by remember { mutableStateOf<FinanceTransaction?>(null) }
  var voidReason by remember { mutableStateOf("") }

  // Double-entry balances (ignoring voided transactions)
  val validTx = transactions.filter { !it.isVoided }
  val totalReceipts = validTx.filter { it.docType == "سند قبض" }.sumOf { it.amount }
  val totalPayments = validTx.filter { it.docType == "سند صرف" }.sumOf { it.amount }
  val cashInHand = validTx.filter { it.paymentMethod == "نقداً" }
    .sumOf { if (it.docType == "سند قبض") it.amount else -it.amount }
  val bankBalance = validTx.filter { it.paymentMethod != "نقداً" }
    .sumOf { if (it.docType == "سند قبض") it.amount else -it.amount }

  val filteredList = transactions.reversed().filter { tx ->
    val matchesQuery = searchQuery.isEmpty() ||
      tx.docNumber.contains(searchQuery, ignoreCase = true) ||
      tx.payerOrBeneficiary.contains(searchQuery, ignoreCase = true) ||
      tx.notes.contains(searchQuery, ignoreCase = true)
    val matchesFilter = when (filterType) {
      "سند قبض" -> tx.docType == "سند قبض"
      "سند صرف" -> tx.docType == "سند صرف"
      "ملغي" -> tx.isVoided
      else -> true
    }
    matchesQuery && matchesFilter
  }

  // Dialog to issue new voucher
  if (showNewVoucherDialog) {
    NewVoucherDialog(
      initialType = voucherType,
      patients = patients,
      medicalStaff = medicalStaff,
      generalStaff = generalStaff,
      accounts = chartOfAccounts,
      onDismiss = { showNewVoucherDialog = false },
      onSave = { docType, amt, method, payer, pId, dId, sId, debit, credit, prevBal, notes ->
        viewModel.addFinanceTransaction(
          docType = docType,
          amount = amt,
          paymentMethod = method,
          payerOrBeneficiary = payer,
          patientId = pId,
          doctorId = dId,
          staffId = sId,
          debitAccount = debit,
          creditAccount = credit,
          previousBalance = prevBal,
          notes = notes
        )
        showNewVoucherDialog = false
      }
    )
  }

  // Dialog to void transaction
  if (transactionToVoid != null) {
    AlertDialog(
      onDismissRequest = { transactionToVoid = null },
      icon = { Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
      title = { Text("إلغاء سند مالي (عكس القيد)", fontWeight = FontWeight.Bold) },
      text = {
        Column {
          Text("تنبيه: سيتم عكس أثر السند رقم [${transactionToVoid!!.docNumber}] بقيمة ${viewModel.formatMoney(transactionToVoid!!.amount)} ر.ي في شجرة الحسابات والصندوق وتوثيق العملية في سجل التدقيق.")
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = voidReason,
            onValueChange = { voidReason = it },
            label = { Text("سبب الإلغاء الإلزامي *") },
            placeholder = { Text("مثال: خطأ في إدخال المبلغ، إلغاء الحجز...") },
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (voidReason.isNotBlank()) {
              viewModel.voidFinanceTransaction(transactionToVoid!!.id, voidReason)
              transactionToVoid = null
              voidReason = ""
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("تأكيد إلغاء السند")
        }
      },
      dismissButton = {
        OutlinedButton(onClick = { transactionToVoid = null }) {
          Text("تراجع")
        }
      }
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header & Quick Voucher Buttons
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "الإدارة المالية والمحاسبة",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "نظام القيد المزدوج، سندات القبض والصرف الرسمية",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Button(
            onClick = {
              voucherType = "سند قبض"
              showNewVoucherDialog = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("سند قبض")
          }

          Button(
            onClick = {
              voucherType = "سند صرف"
              showNewVoucherDialog = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("سند صرف")
          }
        }
      }
    }

    // Cash and Bank Summary Cards
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("الصندوق النقدي (الكاش)", style = MaterialTheme.typography.labelSmall)
            Text(
              text = "${viewModel.formatMoney(cashInHand)} ر.ي",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
            )
          }
        }

        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("الحسابات البنكية / شبكة", style = MaterialTheme.typography.labelSmall)
            Text(
              text = "${viewModel.formatMoney(bankBalance)} ر.ي",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
              )
            )
          }
        }
      }
    }

    // Income vs Expense Summary
    item {
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("إجمالي المقبوضات: ${viewModel.formatMoney(totalReceipts)} ر.ي", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A), fontSize = 13.sp)
            Text("إجمالي المصروفات: ${viewModel.formatMoney(totalPayments)} ر.ي", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626), fontSize = 13.sp)
          }
          Text(
            text = "الصافي: ${viewModel.formatMoney(totalReceipts - totalPayments)} ر.ي",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }
    }

    // Search and Filter Bar
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        label = { Text("بحث في السندات (الرقم، المستفيد، البيان)") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
      )
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("الكل", "سند قبض", "سند صرف", "ملغي").forEach { flt ->
          FilterChip(
            selected = filterType == flt,
            onClick = { filterType = flt },
            label = { Text(flt) }
          )
        }
      }
    }

    // Transactions list
    item {
      Text(
        text = "سجل السندات والمعاملات (${filteredList.size}):",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary
      )
    }

    items(filteredList) { tx ->
      val isReceipt = tx.docType == "سند قبض"
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (tx.isVoided) Color(0xFFFDE8E8) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                color = if (tx.isVoided) Color(0xFFB91C1C) else if (isReceipt) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = if (tx.isVoided) "ملغي / معكوس" else tx.docType,
                  color = if (tx.isVoided) Color.White else if (isReceipt) Color(0xFF166534) else Color(0xFF991B1B),
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${tx.docNumber} - ${tx.payerOrBeneficiary}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
            }

            Text(
              text = "${viewModel.formatMoney(tx.amount)} ر.ي",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (tx.isVoided) Color.Gray else if (isReceipt) Color(0xFF166534) else Color(0xFF991B1B)
              )
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "البيان: ${tx.notes}",
            style = MaterialTheme.typography.bodySmall
          )

          Text(
            text = "مدين: ${tx.debitAccount} | دائن: ${tx.creditAccount}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
          )

          if (tx.previousBalance > 0 || tx.finalBalance > 0) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "الرصيد السابق: ${viewModel.formatMoney(tx.previousBalance)} ر.ي",
                style = MaterialTheme.typography.labelSmall,
                color = Color.DarkGray
              )
              Text(
                text = "الرصيد المتبقي: ${viewModel.formatMoney(tx.finalBalance)} ر.ي",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.DarkGray
              )
            }
          }

          Divider(modifier = Modifier.padding(vertical = 6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "📅 ${tx.date} | طريقة الدفع: ${tx.paymentMethod}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.outline
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              // Thermal Print Receipt
              IconButton(
                onClick = {
                  val lines = listOf(
                    "رقم السند: ${tx.docNumber}",
                    "نوع المستند: ${tx.docType}",
                    "التاريخ: ${tx.date}",
                    "المستلم / المنصرف له: ${tx.payerOrBeneficiary}",
                    "المبلغ: ${viewModel.formatMoney(tx.amount)} ر.ي",
                    "الرصيد السابق: ${viewModel.formatMoney(tx.previousBalance)} ر.ي",
                    "الرصيد الحالي: ${viewModel.formatMoney(tx.finalBalance)} ر.ي",
                    "طريقة الدفع: ${tx.paymentMethod}",
                    "البيان: ${tx.notes}",
                    "حساب المدين: ${tx.debitAccount}",
                    "حساب الدائن: ${tx.creditAccount}"
                  )
                  viewModel.openPrintDialog(
                    PrintPayload(
                      type = "THERMAL_RECEIPT",
                      title = tx.docType,
                      contentLines = lines,
                      docNumber = tx.docNumber,
                      totalAmount = tx.amount,
                      date = tx.date
                    )
                  )
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Print, contentDescription = "طباعة حرارية", modifier = Modifier.size(18.dp))
              }

              // A4 Print Voucher
              IconButton(
                onClick = {
                  val lines = listOf(
                    "رقم المستند المالي: ${tx.docNumber}",
                    "نوع القيد: ${tx.docType}",
                    "التاريخ والوقت: ${tx.date}",
                    "المستفيد / الدافع: ${tx.payerOrBeneficiary}",
                    "المبلغ الإجمالي: ${viewModel.formatMoney(tx.amount)} ريال يمني",
                    "الرصيد السابق: ${viewModel.formatMoney(tx.previousBalance)} ر.ي",
                    "الرصيد النهائي: ${viewModel.formatMoney(tx.finalBalance)} ر.ي",
                    "طريقة التحصيل: ${tx.paymentMethod}",
                    "شرح القيد المحاسبي: ${tx.notes}",
                    "الطرف المدين (Debit): ${tx.debitAccount}",
                    "الطرف الدائن (Credit): ${tx.creditAccount}",
                    "المحاسب المسؤول: الإدارة المالية"
                  )
                  viewModel.openPrintDialog(
                    PrintPayload(
                      type = "A4_INVOICE",
                      title = "سند قيد محاسبي رسمي (${tx.docType})",
                      contentLines = lines,
                      docNumber = tx.docNumber,
                      totalAmount = tx.amount,
                      date = tx.date
                    )
                  )
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Description, contentDescription = "طباعة رسمية A4", modifier = Modifier.size(18.dp))
              }

              // WhatsApp Share
              IconButton(
                onClick = {
                  val msg = "إشعار مالي من ${centerProfile?.facilityName}:\nسند رقم: ${tx.docNumber} (${tx.docType})\nالمبلغ: ${viewModel.formatMoney(tx.amount)} ر.ي\nالمستفيد: ${tx.payerOrBeneficiary}\nالبيان: ${tx.notes}\nشكراً لتعاملكم معنا.\nتطوير: وسيم الفرح | هاتف: 774486588"
                  viewModel.sendWhatsApp(context, centerProfile?.phone1 ?: "774486588", msg)
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = Color(0xFF25D366), modifier = Modifier.size(18.dp))
              }

              // Void Voucher Button (if not already voided)
              if (!tx.isVoided) {
                IconButton(
                  onClick = { transactionToVoid = tx },
                  modifier = Modifier.size(32.dp)
                ) {
                  Icon(Icons.Default.Cancel, contentDescription = "إلغاء السند", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                }
              }
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

/**
 * Voucher Dialog (Receipt or Payment)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewVoucherDialog(
  initialType: String,
  patients: List<Patient>,
  medicalStaff: List<MedicalStaff>,
  generalStaff: List<GeneralStaff>,
  accounts: List<ChartOfAccount>,
  onDismiss: () -> Unit,
  onSave: (String, Double, String, String, Long?, Long?, Long?, String, String, Double, String) -> Unit
) {
  var docType by remember { mutableStateOf(initialType) }
  var amountText by remember { mutableStateOf("") }
  var previousBalanceText by remember { mutableStateOf("0") }
  var paymentMethod by remember { mutableStateOf("نقداً") }
  var beneficiary by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }

  var selectedPatientId by remember { mutableStateOf<Long?>(null) }
  var selectedDoctorId by remember { mutableStateOf<Long?>(null) }
  var selectedStaffId by remember { mutableStateOf<Long?>(null) }

  var selectedDebitAccount by remember {
    mutableStateOf(if (docType == "سند قبض") "الصندوق الرئيسي (نقدية)" else "مصروفات تشغيلية ومستلزمات طبية")
  }
  var selectedCreditAccount by remember {
    mutableStateOf(if (docType == "سند قبض") "إيرادات الكشوفات والخدمات الطبية" else "الصندوق الرئيسي (نقدية)")
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(16.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("إصدار مستند مالي (قيد مزدوج)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))

        // Doc type selector
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = docType == "سند قبض",
            onClick = {
              docType = "سند قبض"
              selectedDebitAccount = "الصندوق الرئيسي (نقدية)"
              selectedCreditAccount = "إيرادات الكشوفات والخدمات الطبية"
            },
            label = { Text("سند قبض (إيراد)") }
          )
          FilterChip(
            selected = docType == "سند صرف",
            onClick = {
              docType = "سند صرف"
              selectedDebitAccount = "مصروفات تشغيلية ومستلزمات طبية"
              selectedCreditAccount = "الصندوق الرئيسي (نقدية)"
            },
            label = { Text("سند صرف (مصروف)") }
          )
        }

        OutlinedTextField(
          value = amountText,
          onValueChange = { amountText = formatAmountInput(it) },
          label = { Text("المبلغ (ر.ي) *") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth()
        )
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            "الرصيد السابق والرصيد النهائي يُحسبان تلقائياً من حساب الشخص بعد اختيار الاسم، ولا حاجة لإدخالهما يدوياً.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(10.dp)
          )
        }

        // Payment method
        Text("طريقة الدفع:", style = MaterialTheme.typography.labelSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("نقداً", "شبكة / بنك", "حوالة").forEach { m ->
            FilterChip(
              selected = paymentMethod == m,
              onClick = {
                paymentMethod = m
                if (docType == "سند قبض") {
                  selectedDebitAccount = if (m == "نقداً") "الصندوق الرئيسي (نقدية)" else "حساب بنك الكريمي للتمويل"
                } else {
                  selectedCreditAccount = if (m == "نقداً") "الصندوق الرئيسي (نقدية)" else "حساب بنك الكريمي للتمويل"
                }
              },
              label = { Text(m) }
            )
          }
        }

        OutlinedTextField(
          value = beneficiary,
          onValueChange = {
            beneficiary = it
            if (docType == "سند قبض") {
              selectedPatientId = patients.firstOrNull { p -> p.fullName.equals(it.trim(), true) }?.id
            } else {
              selectedDoctorId = medicalStaff.firstOrNull { d -> d.name.equals(it.trim(), true) }?.id
              selectedStaffId = generalStaff.firstOrNull { e -> e.fullName.equals(it.trim(), true) }?.id
            }
          },
          label = { Text(if (docType == "سند قبض") "المريض / العميل" else "الطبيب / الموظف / المستفيد") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        val beneficiaryMatches = if (docType == "سند قبض") {
          patients.filter { it.fullName.contains(beneficiary.trim(), ignoreCase = true) }.take(6).map { it.fullName }
        } else {
          (medicalStaff.map { it.name } + generalStaff.map { it.fullName })
            .filter { it.contains(beneficiary.trim(), ignoreCase = true) }
            .distinct()
            .take(6)
        }
        if (beneficiary.trim().isNotEmpty() && beneficiaryMatches.isNotEmpty()) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(Modifier.fillMaxWidth().padding(4.dp)) {
              beneficiaryMatches.forEach { name ->
                TextButton(
                  onClick = {
                    beneficiary = name
                    if (docType == "سند قبض") {
                      selectedPatientId = patients.firstOrNull { it.fullName == name }?.id
                      selectedDoctorId = null
                      selectedStaffId = null
                    } else {
                      val doc = medicalStaff.firstOrNull { it.name == name }
                      val staff = generalStaff.firstOrNull { it.fullName == name }
                      selectedDoctorId = doc?.id
                      selectedStaffId = if (doc == null) staff?.id else null
                      selectedPatientId = null
                    }
                  },
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(name, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = null)
                  }
                }
              }
            }
          }
        }

        OutlinedTextField(
          value = selectedDebitAccount,
          onValueChange = { selectedDebitAccount = it },
          label = { Text("الطرف المدين (Debit) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = selectedCreditAccount,
          onValueChange = { selectedCreditAccount = it },
          label = { Text("الطرف الدائن (Credit) *") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("البيان وشرح المعاملة *") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val amt = parseAmountInput(amountText)
              val prevBal = parseAmountInput(previousBalanceText)
              if (amt > 0) {
                onSave(
                  docType,
                  amt,
                  paymentMethod,
                  beneficiary.ifBlank { "عميل عام" },
                  selectedPatientId,
                  selectedDoctorId,
                  selectedStaffId,
                  selectedDebitAccount,
                  selectedCreditAccount,
                  prevBal,
                  notes.ifBlank { "معاملة مالية" }
                )
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ المستند")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
