package com.example.ui

import java.text.NumberFormat
import java.util.Locale

/** Formats a user-entered integer amount with thousands separators while keeping only digits. */
fun formatAmountInput(value: String): String {
  val digits = value.filter { it.isDigit() }
  if (digits.isEmpty()) return ""
  return try {
    NumberFormat.getIntegerInstance(Locale.US).format(digits.toLong())
  } catch (_: Exception) {
    digits
  }
}

fun parseAmountInput(value: String): Double = value.replace(",", "").toDoubleOrNull() ?: 0.0
