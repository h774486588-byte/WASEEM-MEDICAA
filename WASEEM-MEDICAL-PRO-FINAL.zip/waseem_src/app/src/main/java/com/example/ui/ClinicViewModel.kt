package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

enum class ClinicScreen(val titleAr: String) {
  HOME("الرئيسية - لوحة التحكم"),
  QUICK_SEARCH("البحث السريع الفوري"),
  NEW_PATIENT("إدخال حالة جديدة"),
  PATIENTS("إدارة المرضى"),
  PATIENT_DETAILS("ملف المريض الشامل"),
  MEDICAL_CASES("الأمراض والحالات الطبية"),
  APPOINTMENTS("إدارة المواعيد"),
  SESSIONS("إدارة الجلسات والخصم"),
  PACKAGES("إدارة الباقات العلاجية"),
  FINANCE("سندات القبض والصرف"),
  ACCOUNTS_LEDGER("الحسابات والقيد المزدوج"),
  STAFF("الموظفون والرواتب"),
  MEDICAL_STAFF("الأطباء والكوادر الطبية"),
  REPORTS("التقارير الطبية والمالية"),
  NOTIFICATIONS("مركز الإشعارات الموحد"),
  DEPARTMENTS("دليل الأقسام والخدمات"),
  AUDIT_LOG("سجل العمليات والتدقيق"),
  SETTINGS("إعدادات النظام"),
  BACKUP("النسخ الاحتياطي والاستعادة"),
  TEMPLATES("مركز قوالب الرسائل"),
  SUPPORT("الدعم الفني والترخيص")
}

data class ConflictResult(
  val hasConflict: Boolean,
  val conflictingAppointments: List<Appointment> = emptyList()
)

data class PrintPayload(
  val type: String, // "THERMAL_RECEIPT", "A4_INVOICE", "A4_REPORT", "THERMAL_APPOINTMENTS", "PATIENT_ADMISSION"
  val title: String,
  val contentLines: List<String>,
  val patientName: String = "",
  val docNumber: String = "",
  val totalAmount: Double = 0.0,
  val date: String = "",
  val footerNotes: String = ""
)

class ClinicViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: ClinicRepository

  init {
    val database = ClinicDatabase.getDatabase(application, viewModelScope)
    repository = ClinicRepository(database.clinicDao())
    viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
      try {
        ClinicDatabase.checkAndPopulateIfEmpty(database.clinicDao())
        syncTrialPeriod()
      } catch (e: Exception) {
        android.util.Log.e("ClinicViewModel", "Init check error", e)
      }
    }
  }

  /** Keeps the free trial tied to the first successful installation/start, not a hard-coded day count. */
  private suspend fun syncTrialPeriod() {
    val prefs = getApplication<Application>().getSharedPreferences("waseem_license", Context.MODE_PRIVATE)
    val profile = repository.getCenterProfile() ?: return
    if (profile.isLicenseActive) return

    val now = System.currentTimeMillis()
    var startedAt = prefs.getLong("trial_started_at", 0L)
    if (startedAt == 0L) {
      startedAt = now
      prefs.edit().putLong("trial_started_at", startedAt).apply()
    }

    val elapsedDays = TimeUnit.MILLISECONDS.toDays((now - startedAt).coerceAtLeast(0L)).toInt()
    val remaining = (30 - elapsedDays).coerceAtLeast(0)
    if (profile.trialDaysRemaining != remaining) {
      repository.saveCenterProfile(profile.copy(trialDaysRemaining = remaining))
    }
    if (remaining == 0) {
      _snackbarMessage.value = "انتهت الفترة التجريبية المجانية لمدة 30 يوماً. أدخل مفتاح التفعيل الصادر من المطور."
    }
  }

  // Navigation state - defaults to HOME (Executive Dashboard)
  private val _currentScreen = MutableStateFlow(ClinicScreen.HOME)
  val currentScreen: StateFlow<ClinicScreen> = _currentScreen.asStateFlow()

  // Selected patient for details view
  private val _selectedPatientId = MutableStateFlow<Long?>(null)
  val selectedPatientId: StateFlow<Long?> = _selectedPatientId.asStateFlow()

  // Quick Search
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Global alert/snackbar message
  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  // Dialog visibilities
  private val _showSetupWizard = MutableStateFlow(false)
  val showSetupWizard: StateFlow<Boolean> = _showSetupWizard.asStateFlow()

  private val _showLicenseDialog = MutableStateFlow(false)
  val showLicenseDialog: StateFlow<Boolean> = _showLicenseDialog.asStateFlow()

  private val _showUserSwitchDialog = MutableStateFlow(false)
  val showUserSwitchDialog: StateFlow<Boolean> = _showUserSwitchDialog.asStateFlow()

  // Print Dialog Payload
  private val _printPayload = MutableStateFlow<PrintPayload?>(null)
  val printPayload: StateFlow<PrintPayload?> = _printPayload.asStateFlow()

  // Quick Share / Notification Modal for New Patient
  private val _savedPatientShareModal = MutableStateFlow<Patient?>(null)
  val savedPatientShareModal: StateFlow<Patient?> = _savedPatientShareModal.asStateFlow()

  // Current active user (defaults to المدير)
  private val _currentUser = MutableStateFlow(
    AppUser(id = 1, username = "admin", fullName = "المدير العام (وسيم الفرح)", role = "المدير")
  )
  val currentUser: StateFlow<AppUser> = _currentUser.asStateFlow()

  // Reactive Data Streams
  val centerProfile = repository.centerProfile.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), null
  )

  val departments = repository.allDepartments.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val services = repository.allServices.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val medicalStaff = repository.allMedicalStaff.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val generalStaff = repository.allGeneralStaff.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val patients = repository.allPatients.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val medicalCases = repository.allMedicalCases.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val clinicalSessions = repository.allClinicalSessions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val appointments = repository.allAppointments.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val packageDefinitions = repository.allPackageDefinitions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val patientPackages = repository.allPatientPackages.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val financeTransactions = repository.allFinanceTransactions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val chartOfAccounts = repository.allAccounts.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val notifications = repository.allNotifications.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val unreadNotificationsCount = repository.unreadNotificationsCount.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), 0
  )

  val appUsers = repository.allUsers.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val auditLogs = repository.allAuditLogs.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val templates = repository.allTemplates.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  // Selected Patient details
  val selectedPatient = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(null)
    else repository.allPatients.map { list -> list.find { it.id == id } }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val selectedPatientTimeline = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getTimeline(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientPackages = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getPatientPackages(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientCases = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getMedicalCasesByPatient(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientSessions = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getClinicalSessionsByPatient(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientAppointments = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getAppointmentsByPatient(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientFinance = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getFinanceByPatient(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Navigation actions
  fun navigateTo(screen: ClinicScreen) {
    _currentScreen.value = screen
  }

  fun openPatientDetails(patientId: Long) {
    _selectedPatientId.value = patientId
    _currentScreen.value = ClinicScreen.PATIENT_DETAILS
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun clearSnackbar() {
    _snackbarMessage.value = null
  }

  fun showMessage(msg: String) {
    _snackbarMessage.value = msg
  }

  fun toggleSetupWizard(show: Boolean) {
    _showSetupWizard.value = show
  }

  fun toggleLicenseDialog(show: Boolean) {
    _showLicenseDialog.value = show
  }

  fun toggleUserSwitchDialog(show: Boolean) {
    _showUserSwitchDialog.value = show
  }

  fun switchUser(user: AppUser) {
    _currentUser.value = user
    _showUserSwitchDialog.value = false
    showMessage("تم التبديل إلى المستخدم: ${user.fullName} (${user.role})")
  }

  fun closePrintDialog() {
    _printPayload.value = null
  }

  fun openPrintDialog(payload: PrintPayload) {
    _printPayload.value = payload
  }

  fun closeSavedPatientShareModal() {
    _savedPatientShareModal.value = null
  }

  // Next patient code
  suspend fun getNextPatientCode(): String {
    return repository.generateNextPatientCode()
  }

  // Formatting helpers
  fun formatMoney(amount: Double): String {
    val formatter = NumberFormat.getNumberInstance(Locale.US)
    formatter.maximumFractionDigits = 0
    return formatter.format(amount)
  }

  fun normalizePhone(phone: String): String {
    val clean = phone.replace(Regex("[^0-9+]"), "")
    return if (clean.startsWith("+967")) {
      clean.replace("+967", "")
    } else if (clean.startsWith("00967")) {
      clean.replace("00967", "")
    } else clean
  }

  // Facility Setup Save
  fun saveFacilitySettings(profile: CenterProfile) {
    viewModelScope.launch {
      repository.saveCenterProfile(profile)
      _showSetupWizard.value = false
      showMessage("تم حفظ إعدادات المنشأة بنجاح")
    }
  }

  // Activate license
  fun activateLicense(code: String) {
    viewModelScope.launch {
      val profile = centerProfile.value ?: return@launch
      if (code.trim().equals("WAS-2026-MEDPRO", ignoreCase = true)) {
        val updated = profile.copy(
          isLicenseActive = true,
          licenseKey = code.trim(),
          trialDaysRemaining = 365
        )
        repository.saveCenterProfile(updated)
        _showLicenseDialog.value = false
        showMessage("تهانينا! تم تفعيل النسخة المرخصة بالكامل بنجاح.")
      } else {
        showMessage("رمز الترخيص غير صحيح. يرجى التواصل مع المطور: 774486588")
      }
    }
  }

  // Toggle accounting period lock
  fun toggleAccountingPeriodLock() {
    viewModelScope.launch {
      val profile = centerProfile.value ?: return@launch
      val newStatus = !profile.accountingPeriodLocked
      repository.saveCenterProfile(profile.copy(accountingPeriodLocked = newStatus))
      val text = if (newStatus) "تم قفل الفترة المحاسبية (لا يمكن التعديل المالي)" else "تم إلغاء قفل الفترة المحاسبية"
      showMessage(text)
    }
  }

  // Save new patient
  fun saveNewPatient(
    fullName: String,
    phone: String,
    address: String,
    gender: String,
    birthDate: String,
    age: Int,
    emergencyRelation: String,
    emergencyPhone: String,
    deptId: Long,
    serviceId: Long,
    doctorId: Long,
    referralSource: String = "مباشر",
    notes: String,
    andOpenShareModal: Boolean
  ) {
    viewModelScope.launch {
      val patientCode = repository.generateNextPatientCode()
      val patient = Patient(
        patientCode = patientCode,
        fullName = fullName.trim(),
        phone = phone.trim(),
        address = address.trim(),
        gender = gender,
        birthDate = birthDate,
        age = age,
        emergencyRelation = emergencyRelation.trim(),
        emergencyPhone = emergencyPhone.trim(),
        departmentId = deptId,
        serviceId = serviceId,
        doctorId = doctorId,
        referralSource = referralSource.trim().ifEmpty { "مباشر" },
        notes = notes.trim()
      )
      val newId = repository.insertPatient(patient)
      val createdPatient = patient.copy(id = newId)

      // Add Notification
      repository.addNotification(
        title = "مريض جديد: ${patient.fullName}",
        message = "تم تسجيل ملف طبي جديد برقم $patientCode وتحويله للقسم المختص.",
        type = "مريض جديد"
      )

      // Audit Log
      repository.logAction(
        username = currentUser.value.fullName,
        role = currentUser.value.role,
        action = "إدخال حالة مريض جديدة",
        target = "ملف مريض",
        entityId = patientCode,
        oldVal = "غير موجود",
        newVal = patient.fullName
      )

      // Initial visit timeline if service was selected
      if (serviceId > 0) {
        val srv = services.value.find { it.id == serviceId }
        val doc = medicalStaff.value.find { it.id == doctorId }
        val dept = departments.value.find { it.id == deptId }
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        repository.insertTimeline(
          PatientTimeline(
            patientId = newId,
            visitDate = today,
            doctorName = doc?.name ?: "الاستقبال",
            serviceName = srv?.name ?: "فتح ملف وإدخال حالة",
            diagnosis = "تسجيل ملف طبي وإحالة للقسم",
            prescription = "-",
            notes = "القسم: ${dept?.name ?: "عام"} - السعر الافتراضي: ${srv?.defaultPrice ?: 0.0}"
          )
        )
      }

      if (andOpenShareModal) {
        _savedPatientShareModal.value = createdPatient
      } else {
        showMessage("تم حفظ بيانات المريض بنجاح برقم: $patientCode")
        navigateTo(ClinicScreen.PATIENTS)
      }
    }
  }

  // Medical Cases (الأمراض والحالات الطبية)
  fun addMedicalCase(
    patientId: Long,
    patientName: String,
    title: String,
    doctorId: Long,
    doctorName: String,
    departmentId: Long,
    departmentName: String,
    serviceId: Long,
    serviceName: String,
    status: String,
    notes: String,
    attachments: String
  ) {
    viewModelScope.launch {
      val count = medicalCases.value.size
      val code = String.format(Locale.US, "CAS-%04d", count + 1001)
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

      repository.insertMedicalCase(
        MedicalCase(
          caseCode = code,
          patientId = patientId,
          patientName = patientName,
          title = title.trim(),
          registrationDate = today,
          doctorId = doctorId,
          doctorName = doctorName,
          departmentId = departmentId,
          departmentName = departmentName,
          serviceId = serviceId,
          serviceName = serviceName,
          status = status,
          notes = notes.trim(),
          attachments = attachments.trim()
        )
      )

      // Notification for doctor
      repository.addNotification(
        title = "حالة جديدة مرتبطة بالطبيب $doctorName",
        message = "تم تسجيل حالة جديدة ($title) للمريض $patientName مرتبطة بـ $doctorName.",
        type = "حالة جديدة للطبيب"
      )

      showMessage("تم تسجيل الحالة الطبية بنجاح برقم: $code")
    }
  }

  // Clinical Sessions (الجلسات الفردية وخصم الباقات)
  fun registerClinicalSession(
    patientId: Long,
    patientName: String,
    doctorId: Long,
    doctorName: String,
    packageId: Long?,
    packageName: String,
    caseId: Long?,
    sessionNumber: Int,
    date: String,
    checkInTime: String,
    checkOutTime: String,
    status: String,
    notes: String
  ) {
    viewModelScope.launch {
      val message = repository.registerClinicalSession(
        patientId = patientId,
        patientName = patientName,
        doctorId = doctorId,
        doctorName = doctorName,
        packageId = packageId,
        packageName = packageName,
        caseId = caseId,
        sessionNumber = sessionNumber,
        date = date,
        checkInTime = checkInTime,
        checkOutTime = checkOutTime,
        status = status,
        notes = notes
      )
      showMessage(message)
    }
  }

  // Appointment operations with Conflict Prevention
  fun bookAppointment(
    patientId: Long,
    patientName: String,
    patientPhone: String,
    departmentId: Long,
    departmentName: String,
    serviceId: Long,
    serviceName: String,
    doctorId: Long,
    doctorName: String,
    date: String,
    startTime: String,
    endTime: String,
    notes: String,
    onConflictDetected: (List<Appointment>) -> Unit,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      val conflicts = repository.checkConflict(
        doctorId = doctorId,
        patientId = patientId,
        date = date,
        startTime = startTime,
        endTime = endTime
      )
      if (conflicts.isNotEmpty()) {
        onConflictDetected(conflicts)
        return@launch
      }

      val count = appointments.value.size
      val code = String.format(Locale.US, "APT-%04d", count + 1001)
      val appt = Appointment(
        appointmentCode = code,
        patientId = patientId,
        patientName = patientName,
        patientPhone = patientPhone,
        departmentId = departmentId,
        departmentName = departmentName,
        serviceId = serviceId,
        serviceName = serviceName,
        doctorId = doctorId,
        doctorName = doctorName,
        appointmentDate = date,
        startTime = startTime,
        endTime = endTime,
        status = "في الانتظار",
        notes = notes
      )
      repository.insertAppointment(appt)

      // Add Notification
      repository.addNotification(
        title = "موعد جديد: $patientName",
        message = "تم حجز موعد مع $doctorName بتاريخ $date الساعة $startTime.",
        type = "موعد قريب"
      )

      showMessage("تم حجز الموعد بنجاح برقم: $code")
      onSuccess()
    }
  }

  fun updateAppointmentStatus(appointment: Appointment, newStatus: String) {
    viewModelScope.launch {
      val message = repository.updateAppointmentStatus(appointment, newStatus)
      if (message != null) {
        showMessage(message)
      } else {
        showMessage("تم تحديث حالة الموعد إلى: $newStatus")
      }
    }
  }

  fun deleteAppointment(appointment: Appointment) {
    viewModelScope.launch {
      repository.deleteAppointment(appointment)
      showMessage("تم حذف الموعد")
    }
  }

  // Package Operations
  fun createPackageDefinition(
    name: String,
    departmentId: Long,
    departmentName: String,
    totalSessions: Int,
    price: Double,
    validityDays: Int
  ) {
    viewModelScope.launch {
      repository.insertPackageDefinition(
        PackageDefinition(
          name = name.trim(),
          departmentId = departmentId,
          departmentName = departmentName,
          totalSessions = totalSessions,
          price = price,
          validityDays = validityDays
        )
      )
      showMessage("تمت إضافة الباقة العلاجية بنجاح")
    }
  }

  fun assignPackageToPatient(patientId: Long, packageDef: PackageDefinition) {
    viewModelScope.launch {
      val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
      val now = Date()
      val purchaseDate = sdf.format(now)
      val expiryMillis = now.time + (packageDef.validityDays.toLong() * 24 * 60 * 60 * 1000)
      val expiryDate = sdf.format(Date(expiryMillis))

      val patientPkg = PatientPackage(
        patientId = patientId,
        packageDefId = packageDef.id,
        packageName = packageDef.name,
        totalSessions = packageDef.totalSessions,
        usedSessions = 0,
        remainingSessions = packageDef.totalSessions,
        purchaseDate = purchaseDate,
        expiryDate = expiryDate,
        price = packageDef.price,
        paidAmount = packageDef.price,
        remainingBalance = 0.0,
        status = "نشطة"
      )
      repository.insertPatientPackage(patientPkg)

      val patient = patients.value.find { it.id == patientId }
      val docNumber = repository.insertFinanceTransaction(
        docType = "سند قبض",
        amount = packageDef.price,
        paymentMethod = "نقداً",
        payerOrBeneficiary = patient?.fullName ?: "مريض",
        patientId = patientId,
        doctorId = null,
        staffId = null,
        debitAccount = "الصندوق الرئيسي (نقدية)",
        creditAccount = "إيرادات باقات العلاج الطبيعي والتأهيل",
        previousBalance = 0.0,
        notes = "قيمة شراء ${packageDef.name} (${packageDef.totalSessions} جلسات)"
      )

      showMessage("تم ربط الباقة بالمريض بنجاح وإصدار سند قبض فوري")
    }
  }

  // Finance Transactions with double-entry & previous/final balance calculation
  fun addFinanceTransaction(
    docType: String,
    amount: Double,
    paymentMethod: String,
    payerOrBeneficiary: String,
    patientId: Long? = null,
    doctorId: Long? = null,
    staffId: Long? = null,
    debitAccount: String,
    creditAccount: String,
    previousBalance: Double = 0.0,
    notes: String
  ) {
    viewModelScope.launch {
      // Check accounting period lock
      if (centerProfile.value?.accountingPeriodLocked == true) {
        showMessage("عذراً! الفترة المحاسبية مقفلة حالياً. لا يمكن إضافة أو تعديل سندات.")
        return@launch
      }

      val effectivePreviousBalance = patientId?.let { id ->
        patients.value.firstOrNull { it.id == id }?.balance ?: previousBalance
      } ?: previousBalance
      repository.insertFinanceTransaction(
        docType = docType,
        amount = amount,
        paymentMethod = paymentMethod,
        payerOrBeneficiary = payerOrBeneficiary.trim(),
        patientId = patientId,
        doctorId = doctorId,
        staffId = staffId,
        debitAccount = debitAccount,
        creditAccount = creditAccount,
        previousBalance = effectivePreviousBalance,
        notes = notes.trim()
      )

      if (docType == "سند صرف" && doctorId != null) {
        repository.updateStaffBalance(doctorId, -amount)
      }

      showMessage("تم حفظ $docType بنجاح وتحديث كشف الحساب والرصيد")
    }
  }

  // Safe Cancel / Voiding of Financial Voucher
  fun voidFinanceTransaction(id: Long, reason: String) {
    viewModelScope.launch {
      if (centerProfile.value?.accountingPeriodLocked == true) {
        showMessage("عذراً! الفترة المحاسبية مقفلة. لا يمكن إلغاء سندات.")
        return@launch
      }
      repository.voidFinanceTransaction(id, reason, currentUser.value.fullName)
      showMessage("تم إلغاء السند المالي بنجاح وعكس أثره المحاسبي في الصندوق والحسابات.")
    }
  }

  // Staff & Payroll operations
  fun addGeneralStaff(
    fullName: String,
    jobTitle: String,
    department: String,
    phone: String,
    nationalId: String,
    address: String,
    basicSalary: Double,
    allowances: Double = 0.0,
    bonuses: Double = 0.0,
    advances: Double = 0.0,
    deductions: Double = 0.0
  ) {
    viewModelScope.launch {
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
      val netSalary = (basicSalary + allowances + bonuses - advances - deductions).coerceAtLeast(0.0)

      repository.insertGeneralStaff(
        GeneralStaff(
          fullName = fullName.trim(),
          jobTitle = jobTitle.trim(),
          department = department.trim(),
          phone = phone.trim(),
          nationalId = nationalId.trim(),
          address = address.trim(),
          hireDate = today,
          monthlySalary = basicSalary,
          allowances = allowances,
          bonuses = bonuses,
          advances = advances,
          deductions = deductions,
          netSalary = netSalary
        )
      )
      showMessage("تمت إضافة الموظف بنجاح وحساب صافي الراتب: ${formatMoney(netSalary)} ر.ي")
    }
  }

  fun updateGeneralStaff(staff: GeneralStaff) {
    viewModelScope.launch {
      repository.updateGeneralStaff(staff)
      showMessage("تم تحديث بيانات الموظف")
    }
  }

  // Disburse Payroll Voucher
  fun disburseSalaryVoucher(staff: GeneralStaff, paymentMethod: String) {
    viewModelScope.launch {
      val netSalary = (staff.monthlySalary + staff.allowances + staff.bonuses - staff.advances - staff.deductions).coerceAtLeast(0.0)
      val cashAccount = if (paymentMethod == "نقداً") "الصندوق الرئيسي (نقدية)" else "حساب بنك الكريمي للتمويل"

      repository.insertFinanceTransaction(
        docType = "سند صرف",
        amount = netSalary,
        paymentMethod = paymentMethod,
        payerOrBeneficiary = staff.fullName,
        patientId = null,
        doctorId = null,
        staffId = staff.id,
        debitAccount = "مصروفات رواتب وأجور الكادر",
        creditAccount = cashAccount,
        previousBalance = netSalary,
        notes = "صرف صافي راتب شهر: ${staff.jobTitle} - [الأساسي: ${formatMoney(staff.monthlySalary)} + بدلات: ${formatMoney(staff.allowances)} - سلف/خصم: ${formatMoney(staff.advances + staff.deductions)}]"
      )

      showMessage("تم إصدار سند صرف الراتب بنجاح للموظف ${staff.fullName} بمبلغ ${formatMoney(netSalary)} ر.ي")
    }
  }

  // Medical Staff operations
  fun addMedicalStaff(
    name: String,
    role: String,
    specialty: String,
    departmentId: Long,
    phone: String,
    qualification: String,
    contractType: String,
    sharePercent: Double,
    monthlySalary: Double,
    workDays: String = "السبت - الخميس",
    workHours: String = "09:00 - 17:00"
  ) {
    viewModelScope.launch {
      repository.insertMedicalStaff(
        MedicalStaff(
          name = name.trim(),
          role = role,
          specialty = specialty.trim(),
          departmentId = departmentId,
          phone = phone.trim(),
          qualification = qualification.trim(),
          contractType = contractType,
          sharePercent = sharePercent,
          monthlySalary = monthlySalary,
          workDays = workDays.trim().ifEmpty { "السبت - الخميس" },
          workHours = workHours.trim().ifEmpty { "09:00 - 17:00" }
        )
      )
      showMessage("تمت إضافة الكادر الطبي بنجاح")
    }
  }

  fun updateMedicalStaff(staff: MedicalStaff) {
    viewModelScope.launch {
      repository.updateMedicalStaff(staff)
      showMessage("تم تحديث بيانات الكادر الطبي")
    }
  }

  // Department & Service Operations (with safe deactivation)
  fun addDepartment(name: String) {
    viewModelScope.launch {
      val count = departments.value.size
      repository.insertDepartment(Department(name = name.trim(), sortOrder = count + 1))
      showMessage("تمت إضافة القسم الطبي بنجاح")
    }
  }


  fun updateDepartment(dept: Department, newName: String) {
    viewModelScope.launch {
      if (newName.isBlank()) return@launch
      repository.updateDepartment(dept.copy(name = newName.trim()))
      showMessage("تم تعديل اسم القسم بنجاح")
    }
  }

  fun deleteDepartmentSafely(dept: Department) {
    viewModelScope.launch {
      val used = patients.value.any { it.departmentId == dept.id } ||
        services.value.any { it.departmentId == dept.id } ||
        medicalStaff.value.any { it.departmentId == dept.id }
      if (used) {
        repository.updateDepartment(dept.copy(isActive = false))
        showMessage("القسم مرتبط بسجلات سابقة، لذلك تم تعطيله بدلاً من حذفه لحماية البيانات")
      } else {
        repository.deleteDepartment(dept)
        showMessage("تم حذف القسم")
      }
    }
  }

  fun updateService(service: MedicalService, newName: String, price: Double, sharePercent: Double, duration: Int) {
    viewModelScope.launch {
      if (newName.isBlank()) return@launch
      repository.updateService(service.copy(name = newName.trim(), defaultPrice = price, doctorSharePercent = sharePercent, durationMinutes = duration))
      showMessage("تم تعديل الخدمة بنجاح")
    }
  }

  fun deleteServiceSafely(service: MedicalService) {
    viewModelScope.launch {
      val used = patients.value.any { it.serviceId == service.id }
      if (used) {
        repository.updateService(service.copy(isActive = false))
        showMessage("الخدمة مرتبطة بمرضى سابقين، لذلك تم تعطيلها بدلاً من حذفها")
      } else {
        repository.deleteService(service)
        showMessage("تم حذف الخدمة")
      }
    }
  }

  fun toggleDepartmentStatus(dept: Department) {
    viewModelScope.launch {
      repository.updateDepartment(dept.copy(isActive = !dept.isActive))
      showMessage("تم تعديل حالة القسم إلى: ${if (!dept.isActive) "نشط" else "معطل"}")
    }
  }

  fun addService(name: String, deptId: Long, price: Double, sharePercent: Double, duration: Int = 30) {
    viewModelScope.launch {
      repository.insertService(
        MedicalService(
          name = name.trim(),
          departmentId = deptId,
          defaultPrice = price,
          doctorSharePercent = sharePercent,
          durationMinutes = duration
        )
      )
      showMessage("تمت إضافة الخدمة الطبية بنجاح")
    }
  }

  fun toggleServiceStatus(srv: MedicalService) {
    viewModelScope.launch {
      repository.updateService(srv.copy(isActive = !srv.isActive))
      showMessage("تم تعديل حالة الخدمة إلى: ${if (!srv.isActive) "نشطة" else "معطلة"}")
    }
  }

  // Notifications operations
  fun markNotificationAsRead(id: Long) {
    viewModelScope.launch {
      repository.markNotificationAsRead(id)
    }
  }

  fun markAllNotificationsAsRead() {
    viewModelScope.launch {
      repository.markAllNotificationsAsRead()
      showMessage("تم تحديد جميع الإشعارات كمقروءة")
    }
  }

  fun clearAllNotifications() {
    viewModelScope.launch {
      repository.clearAllNotifications()
      showMessage("تم مسح جميع الإشعارات")
    }
  }

  // Message Template customization
  fun saveTemplate(key: String, title: String, body: String) {
    viewModelScope.launch {
      repository.saveTemplate(MessageTemplate(key = key, title = title, templateBody = body))
      showMessage("تم حفظ وتحديث قالب الرسالة بنجاح")
    }
  }

  // Patient timeline addition
  fun addPatientTimelineEntry(
    patientId: Long,
    doctorName: String,
    serviceName: String,
    diagnosis: String,
    prescription: String,
    attachmentTitle: String,
    notes: String
  ) {
    viewModelScope.launch {
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
      repository.insertTimeline(
        PatientTimeline(
          patientId = patientId,
          visitDate = today,
          doctorName = doctorName.trim(),
          serviceName = serviceName.trim(),
          diagnosis = diagnosis.trim(),
          prescription = prescription.trim(),
          attachmentTitle = attachmentTitle.trim(),
          notes = notes.trim()
        )
      )
      showMessage("تمت إضافة الزيارة والتشخيص إلى ملف المريض")
    }
  }

  // Communication Handlers: WhatsApp & SMS
  fun sendWhatsApp(context: Context, phoneNumber: String, message: String) {
    try {
      val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
      val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}")
      val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      try {
        val sendIntent = Intent(Intent.ACTION_VIEW).apply {
          data = Uri.parse("sms:${phoneNumber}")
          putExtra("sms_body", message)
          flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(sendIntent)
      } catch (ex: Exception) {
        showMessage("تعذر فتح تطبيق المراسلة: ${ex.localizedMessage}")
      }
    }
  }

  fun sendSMS(context: Context, phoneNumber: String, message: String) {
    try {
      val intent = Intent(Intent.ACTION_VIEW).apply {
        data = Uri.parse("sms:${phoneNumber}")
        putExtra("sms_body", message)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      showMessage("تعذر فتح تطبيق الرسائل القصيرة")
    }
  }

  fun callPhone(context: Context, phoneNumber: String) {
    try {
      val intent = Intent(Intent.ACTION_DIAL).apply {
        data = Uri.parse("tel:${phoneNumber}")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      showMessage("تعذر فتح جهات الاتصال")
    }
  }
}
