package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.ClinicScreen
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val HomeTeal = Color(0xFF0D9488)
private val HomeBlue = Color(0xFF1976D2)
private val HomeGold = Color(0xFFC9A34E)

@Composable
fun HomeScreen(
  viewModel: ClinicViewModel,
  onNavigate: (ClinicScreen) -> Unit
) {
  val profile by viewModel.centerProfile.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val appointments by viewModel.appointments.collectAsState()
  val sessions by viewModel.clinicalSessions.collectAsState()
  val transactions by viewModel.financeTransactions.collectAsState()
  val notifications by viewModel.notifications.collectAsState()
  val packages by viewModel.patientPackages.collectAsState()

  val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
  val todayAppointments = appointments.count { it.appointmentDate == today && it.status != "ملغي" }
  val todaySessions = sessions.count { it.sessionDate == today }
  val todayRevenue = transactions.filter { it.date == today && !it.isVoided && it.docType == "سند قبض" }.sumOf { it.amount }
  val activePackages = packages.count { it.status == "نشطة" }
  val lowPackages = packages.filter { it.status == "نشطة" && it.remainingSessions <= 2 }
  val unread = notifications.count { !it.isRead }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFFF7F9FC)),
    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "مرحبًا بك في نظام وسيم الطبي PRO",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
          color = Color(0xFF123047)
        )
        Text(
          text = profile?.facilityName ?: "إدارة المراكز والعيادات الطبية",
          style = MaterialTheme.typography.bodyMedium,
          color = Color(0xFF64748B)
        )

        // Quick search — deliberately full-width for small phones.
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onNavigate(ClinicScreen.QUICK_SEARCH) },
          shape = RoundedCornerShape(18.dp),
          color = Color.White,
          shadowElevation = 2.dp
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Search, contentDescription = null, tint = HomeTeal)
            Spacer(Modifier.width(10.dp))
            Text(
              "ابحث عن مريض أو رقم ملف أو هاتف...",
              color = Color(0xFF94A3B8),
              style = MaterialTheme.typography.bodyMedium,
              modifier = Modifier.weight(1f)
            )
            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Color(0xFF94A3B8))
          }
        }
      }
    }

    item {
      // Hero card inspired by the supplied reference, but branded for WASEEM MEDICAL PRO.
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(190.dp)
          .clip(RoundedCornerShape(24.dp))
      ) {
        Image(
          painter = painterResource(R.drawable.img_waseem_clinic_banner),
          contentDescription = "واجهة المركز الطبي",
          modifier = Modifier.fillMaxSize(),
          contentScale = ContentScale.Crop
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(Color.White.copy(alpha = 0.78f))
        )
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          Column {
            Text(
              text = profile?.facilityName ?: "نظام وسيم الطبي",
              style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
              color = Color(0xFF123047),
              maxLines = 2,
              overflow = TextOverflow.Ellipsis
            )
            Text(
              text = "إدارة طبية ومالية متكاملة",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = HomeTeal
            )
          }
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = HomeTeal.copy(alpha = 0.94f)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Favorite, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(7.dp))
              Text("رعاية أفضل.. إدارة أذكى", color = Color.White, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    item {
      // KPI cards: two columns on phones so nothing is squeezed or clipped.
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          HomeKpiCard("إجمالي المرضى", patients.size.toString(), Icons.Default.People, HomeTeal, Modifier.weight(1f)) {
            onNavigate(ClinicScreen.PATIENTS)
          }
          HomeKpiCard("مواعيد اليوم", todayAppointments.toString(), Icons.Default.CalendarMonth, HomeBlue, Modifier.weight(1f)) {
            onNavigate(ClinicScreen.APPOINTMENTS)
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          HomeKpiCard("جلسات اليوم", todaySessions.toString(), Icons.Default.AccessibilityNew, Color(0xFF7C3AED), Modifier.weight(1f)) {
            onNavigate(ClinicScreen.SESSIONS)
          }
          HomeKpiCard("إيرادات اليوم", "${viewModel.formatMoney(todayRevenue)} ر.ي", Icons.Default.AccountBalanceWallet, HomeGold, Modifier.weight(1f)) {
            onNavigate(ClinicScreen.FINANCE)
          }
        }
      }
    }

    item {
      Text(
        "الوصول السريع",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
        color = Color(0xFF123047),
        modifier = Modifier.padding(horizontal = 2.dp)
      )
    }

    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          HomeActionCard("تسجيل مريض جديد", Icons.Default.PersonAdd, HomeTeal, Modifier.weight(1f)) { onNavigate(ClinicScreen.NEW_PATIENT) }
          HomeActionCard("المواعيد", Icons.Default.CalendarMonth, HomeBlue, Modifier.weight(1f)) { onNavigate(ClinicScreen.APPOINTMENTS) }
          HomeActionCard("الأقسام والخدمات", Icons.Default.MedicalServices, HomeGold, Modifier.weight(1f)) { onNavigate(ClinicScreen.DEPARTMENTS) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
          HomeActionCard("الإدارة المالية", Icons.Default.AccountBalanceWallet, Color(0xFF64748B), Modifier.weight(1f)) { onNavigate(ClinicScreen.FINANCE) }
          HomeActionCard("التقارير والإحصائيات", Icons.Default.BarChart, Color(0xFF0F9D8A), Modifier.weight(1f)) { onNavigate(ClinicScreen.REPORTS) }
          HomeActionCard("إدارة الموظفين", Icons.Default.Groups, HomeBlue, Modifier.weight(1f)) { onNavigate(ClinicScreen.STAFF) }
        }
      }
    }

    item {
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        shadowElevation = 2.dp
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFFFF7DD)) {
            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = HomeGold, modifier = Modifier.padding(12.dp))
          }
          Spacer(Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("معلومة اليوم", fontWeight = FontWeight.ExtraBold, color = Color(0xFF123047))
            Text(
              "الالتزام بالمواعيد وتسجيل الحضور مباشرة يساعدان على دقة خصم الجلسات وتقارير المركز.",
              style = MaterialTheme.typography.bodySmall,
              color = Color(0xFF64748B)
            )
          }
        }
      }
    }

    item {
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        shadowElevation = 2.dp,
        onClick = { onNavigate(ClinicScreen.NOTIFICATIONS) }
      ) {
        Column(Modifier.padding(16.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = HomeTeal)
            Spacer(Modifier.width(8.dp))
            Text("تنبيهات تحتاج إلى متابعة", fontWeight = FontWeight.ExtraBold, color = Color(0xFF123047), modifier = Modifier.weight(1f))
            Badge { Text(unread.toString()) }
          }
          Spacer(Modifier.height(8.dp))
          if (lowPackages.isEmpty()) {
            Text("لا توجد باقات قاربت على الانتهاء حاليًا.", style = MaterialTheme.typography.bodySmall, color = Color(0xFF64748B))
          } else {
            lowPackages.take(3).forEach { pkg ->
              Text(
                "• ${patients.find { it.id == pkg.patientId }?.fullName ?: "مريض"}: المتبقي ${pkg.remainingSessions} جلسة",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF475569),
                modifier = Modifier.padding(vertical = 2.dp)
              )
            }
          }
          Spacer(Modifier.height(5.dp))
          Text("الباقات النشطة: $activePackages", style = MaterialTheme.typography.labelSmall, color = HomeTeal)
        }
      }
    }

    item {
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFFEAF7F6)
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = HomeTeal, modifier = Modifier.size(38.dp))
          Spacer(Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text("نظام وسيم لإدارة المراكز الطبية", fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F4C4A))
            Text("تطوير: وسيم الفرح | هاتف: 774486588", style = MaterialTheme.typography.bodySmall, color = Color(0xFF256B68))
          }
        }
      }
    }

    item { DeveloperFooter() }
    item { Spacer(Modifier.height(6.dp)) }
  }
}

@Composable
private fun HomeKpiCard(
  title: String,
  value: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  accent: Color,
  modifier: Modifier,
  onClick: () -> Unit
) {
  Surface(
    modifier = modifier.height(112.dp),
    shape = RoundedCornerShape(20.dp),
    color = Color.White,
    shadowElevation = 2.dp,
    onClick = onClick
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(26.dp))
      Text(value, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF123047), maxLines = 1, overflow = TextOverflow.Ellipsis)
      Text(title, style = MaterialTheme.typography.labelMedium, color = Color(0xFF64748B), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
  }
}

@Composable
private fun HomeActionCard(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  color: Color,
  modifier: Modifier,
  onClick: () -> Unit
) {
  Surface(
    modifier = modifier.height(112.dp),
    shape = RoundedCornerShape(20.dp),
    color = color,
    onClick = onClick
  ) {
    Column(
      modifier = Modifier.fillMaxSize().padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
      Spacer(Modifier.height(7.dp))
      Text(
        title,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )
      Text("›", color = Color.White.copy(alpha = .9f), fontSize = 20.sp, lineHeight = 18.sp)
    }
  }
}
