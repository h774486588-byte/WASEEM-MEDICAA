package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewPatientScreen(
  viewModel: ClinicViewModel,
  onOpenThermalPrint: (Patient) -> Unit,
  onOpenA4Print: (Patient) -> Unit
) {
  val departments by viewModel.departments.collectAsState()
  val services by viewModel.services.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()

  // Form Fields
  var patientCode by remember { mutableStateOf("جاري التوليد...") }
  var fullName by remember { mutableStateOf("") }
  var phone by remember { mutableStateOf("") }
  var address by remember { mutableStateOf("") }
  var gender by remember { mutableStateOf("ذكر") }
  var birthDate by remember { mutableStateOf("1995-01-01") }
  var ageText by remember { mutableStateOf("29") }
  var emergencyRelation by remember { mutableStateOf("") }
  var emergencyPhone by remember { mutableStateOf("") }

  // Medical Routing (الربط الطبي المباشر)
  var selectedDeptId by remember { mutableStateOf<Long?>(null) }
  var selectedServiceId by remember { mutableStateOf<Long?>(null) }
  var selectedDoctorId by remember { mutableStateOf<Long?>(null) }
  var notes by remember { mutableStateOf("") }

  // Fetch next sequential patient code on load
  LaunchedEffect(Unit) {
    patientCode = viewModel.getNextPatientCode()
    if (departments.isNotEmpty() && selectedDeptId == null) {
      selectedDeptId = departments.first().id
    }
  }

  // Filtered Services based on selected Department
  val filteredServices = remember(selectedDeptId, services) {
    if (selectedDeptId == null) emptyList()
    else services.filter { it.departmentId == selectedDeptId && it.isActive }
  }

  // Filtered Doctors based on selected Department
  val filteredDoctors = remember(selectedDeptId, medicalStaff) {
    if (selectedDeptId == null) medicalStaff
    else {
      val inDept = medicalStaff.filter { it.departmentId == selectedDeptId }
      if (inDept.isNotEmpty()) inDept else medicalStaff
    }
  }

  // Auto select first service & doctor when department changes
  LaunchedEffect(selectedDeptId, filteredServices, filteredDoctors) {
    if (filteredServices.isNotEmpty() && (selectedServiceId == null || !filteredServices.any { it.id == selectedServiceId })) {
      selectedServiceId = filteredServices.first().id
    }
    if (filteredDoctors.isNotEmpty() && (selectedDoctorId == null || !filteredDoctors.any { it.id == selectedDoctorId })) {
      selectedDoctorId = filteredDoctors.first().id
    }
  }

  val selectedService = filteredServices.find { it.id == selectedServiceId }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Header Banner
    Surface(
      color = MaterialTheme.colorScheme.primaryContainer,
      shape = RoundedCornerShape(14.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          Icons.Default.PersonAdd,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(32.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "إدخال حالة جديدة وتوليد ملف طبي",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onPrimaryContainer
          )
          Text(
            text = "الرقم التعريفي متسلسل وآلي مع ربط فوري بالقسم والخدمة والطبيب",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
          )
        }
      }
    }

    // SECTION 1: Patient Details
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Text(
          text = "البيانات الأساسية للمريض:",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )

        // Patient ID (Sequential & Read-Only)
        OutlinedTextField(
          value = patientCode,
          onValueChange = {},
          readOnly = true,
          label = { Text("رقم الملف / الرقم التعريفي (تلقائي غير قابل للتعديل)") },
          leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null) },
          trailingIcon = {
            Surface(
              color = MaterialTheme.colorScheme.primary,
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier.padding(end = 8.dp)
            ) {
              Text(
                text = "آلي",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          },
          modifier = Modifier.fillMaxWidth()
        )

        // Full Name
        OutlinedTextField(
          value = fullName,
          onValueChange = { fullName = it },
          label = { Text("اسم المريض الكامل *") },
          leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        // Phone & Address
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("رقم الجوال / واتساب *") },
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
            modifier = Modifier.weight(1.2f),
            singleLine = true
          )
          OutlinedTextField(
            value = address,
            onValueChange = { address = it },
            label = { Text("العنوان السكني") },
            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        // Gender & Age
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("الجنس:", style = MaterialTheme.typography.labelMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              FilterChip(
                selected = gender == "ذكر",
                onClick = { gender = "ذكر" },
                label = { Text("ذكر 👨") }
              )
              FilterChip(
                selected = gender == "أنثى",
                onClick = { gender = "أنثى" },
                label = { Text("أنثى 👩") }
              )
            }
          }

          OutlinedTextField(
            value = ageText,
            onValueChange = { ageText = it },
            label = { Text("العمر (سنة)") },
            modifier = Modifier.weight(0.7f),
            singleLine = true
          )
        }

        // Emergency Contact
        Text(
          text = "جهة اتصال للطوارئ (القرابة والهاتف):",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = emergencyRelation,
            onValueChange = { emergencyRelation = it },
            label = { Text("صلة القرابة (أب، أم، زوج...)") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          OutlinedTextField(
            value = emergencyPhone,
            onValueChange = { emergencyPhone = it.filter(Char::isDigit).take(15) },
            label = { Text("هاتف الطوارئ") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }
      }
    }

    // SECTION 2: Medical Routing
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Text(
          text = "الربط الطبي المباشر (التوجيه للقسم والطبيب):",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )

        // Department Selector Dropdown
        var deptExpanded by remember { mutableStateOf(false) }
        val currentDeptName = departments.find { it.id == selectedDeptId }?.name ?: "اختر القسم الطبي"

        ExposedDropdownMenuBox(
          expanded = deptExpanded,
          onExpandedChange = { deptExpanded = !deptExpanded }
        ) {
          OutlinedTextField(
            value = currentDeptName,
            onValueChange = {},
            readOnly = true,
            label = { Text("القسم الطبي المطلوب *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deptExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = deptExpanded,
            onDismissRequest = { deptExpanded = false }
          ) {
            departments.filter { it.isActive }.forEach { dept ->
              DropdownMenuItem(
                text = { Text(dept.name) },
                onClick = {
                  selectedDeptId = dept.id
                  deptExpanded = false
                }
              )
            }
          }
        }

        // Service selection filtered by Department
        var srvExpanded by remember { mutableStateOf(false) }
        val currentSrvName = selectedService?.let { "${it.name} - ${it.defaultPrice} ر.ي" } ?: "اختر الخدمة الطبية"

        ExposedDropdownMenuBox(
          expanded = srvExpanded,
          onExpandedChange = { srvExpanded = !srvExpanded }
        ) {
          OutlinedTextField(
            value = currentSrvName,
            onValueChange = {},
            readOnly = true,
            label = { Text("الخدمة المطلوبة (مفلترة تلقائياً بالسعر)") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = srvExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = srvExpanded,
            onDismissRequest = { srvExpanded = false }
          ) {
            if (filteredServices.isEmpty()) {
              DropdownMenuItem(
                text = { Text("لا توجد خدمات مسجلة لهذا القسم حالياً") },
                onClick = { srvExpanded = false }
              )
            } else {
              filteredServices.forEach { srv ->
                DropdownMenuItem(
                  text = {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                      Text(srv.name, fontWeight = FontWeight.SemiBold)
                      Text("${srv.defaultPrice} ر.ي", color = MaterialTheme.colorScheme.primary)
                    }
                  },
                  onClick = {
                    selectedServiceId = srv.id
                    srvExpanded = false
                  }
                )
              }
            }
          }
        }

        // Doctor / Specialist selection
        var docExpanded by remember { mutableStateOf(false) }
        val currentDoctor = medicalStaff.find { it.id == selectedDoctorId }
        val currentDoctorText = currentDoctor?.let { "${it.name} (${it.role} - ${it.specialty})" } ?: "اختر الطبيب المعالج"

        ExposedDropdownMenuBox(
          expanded = docExpanded,
          onExpandedChange = { docExpanded = !docExpanded }
        ) {
          OutlinedTextField(
            value = currentDoctorText,
            onValueChange = {},
            readOnly = true,
            label = { Text("الطبيب / الأخصائي المعالج المسؤول *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = docExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = docExpanded,
            onDismissRequest = { docExpanded = false }
          ) {
            filteredDoctors.filter { it.isActive }.forEach { doc ->
              DropdownMenuItem(
                text = {
                  Column {
                    Text(doc.name, fontWeight = FontWeight.Bold)
                    Text(
                      "${doc.role} | النسبة: ${if (doc.contractType == "نسبة") "${doc.sharePercent}%" else "راتب"}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                },
                onClick = {
                  selectedDoctorId = doc.id
                  docExpanded = false
                }
              )
            }
          }
        }

        // Notes / Medical summary
        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات طبية أولية أو حساسية الأدوية") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 2
        )
      }
    }

    // SECTION 3: Smart Dual Save Buttons
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = "أزرار الحفظ المزدوج الذكية:",
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Button 1: Save Only
          OutlinedButton(
            onClick = {
              if (fullName.isBlank()) {
                viewModel.showMessage("يرجى كتابة اسم المريض الكامل")
                return@OutlinedButton
              }
              val age = ageText.toIntOrNull() ?: 25
              viewModel.saveNewPatient(
                fullName = fullName,
                phone = phone,
                address = address,
                gender = gender,
                birthDate = birthDate,
                age = age,
                emergencyRelation = emergencyRelation,
                emergencyPhone = emergencyPhone,
                deptId = selectedDeptId ?: 0,
                serviceId = selectedServiceId ?: 0,
                doctorId = selectedDoctorId ?: 0,
                notes = notes,
                andOpenShareModal = false
              )
            },
            modifier = Modifier
              .weight(1f)
              .height(52.dp),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("حفظ فقط")
          }

          // Button 2: Save and Open Notification / Print Options
          Button(
            onClick = {
              if (fullName.isBlank()) {
                viewModel.showMessage("يرجى كتابة اسم المريض الكامل")
                return@Button
              }
              val age = ageText.toIntOrNull() ?: 25
              viewModel.saveNewPatient(
                fullName = fullName,
                phone = phone,
                address = address,
                gender = gender,
                birthDate = birthDate,
                age = age,
                emergencyRelation = emergencyRelation,
                emergencyPhone = emergencyPhone,
                deptId = selectedDeptId ?: 0,
                serviceId = selectedServiceId ?: 0,
                doctorId = selectedDoctorId ?: 0,
                notes = notes,
                andOpenShareModal = true
              )
            },
            modifier = Modifier
              .weight(1.3f)
              .height(52.dp),
            shape = RoundedCornerShape(12.dp)
          ) {
            Icon(Icons.Default.SendAndArchive, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("حفظ وإشعار / طباعة")
          }
        }
      }
    }

    // Developer Footprint
    DeveloperFooter()
  }
}
