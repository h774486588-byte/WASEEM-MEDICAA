package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClinicDao {

  // Center Profile
  @Query("SELECT * FROM center_profile WHERE id = 1 LIMIT 1")
  fun getCenterProfileFlow(): Flow<CenterProfile?>

  @Query("SELECT * FROM center_profile WHERE id = 1 LIMIT 1")
  suspend fun getCenterProfile(): CenterProfile?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveCenterProfile(profile: CenterProfile)

  // Departments
  @Query("SELECT * FROM departments ORDER BY sortOrder ASC, id ASC")
  fun getAllDepartments(): Flow<List<Department>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDepartment(dept: Department): Long

  @Update
  suspend fun updateDepartment(dept: Department)

  @Delete
  suspend fun deleteDepartment(dept: Department)

  // Medical Services
  @Query("SELECT * FROM medical_services ORDER BY id ASC")
  fun getAllServices(): Flow<List<MedicalService>>

  @Query("SELECT * FROM medical_services WHERE departmentId = :deptId AND isActive = 1 ORDER BY id ASC")
  fun getServicesByDepartment(deptId: Long): Flow<List<MedicalService>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertService(service: MedicalService): Long

  @Update
  suspend fun updateService(service: MedicalService)

  @Delete
  suspend fun deleteService(service: MedicalService)

  // Medical Staff (Doctors, Nurses, Specialists)
  @Query("SELECT * FROM medical_staff ORDER BY id ASC")
  fun getAllMedicalStaff(): Flow<List<MedicalStaff>>

  @Query("SELECT * FROM medical_staff WHERE departmentId = :deptId AND isActive = 1")
  fun getMedicalStaffByDept(deptId: Long): Flow<List<MedicalStaff>>

  @Query("SELECT * FROM medical_staff WHERE id = :id LIMIT 1")
  suspend fun getMedicalStaffById(id: Long): MedicalStaff?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMedicalStaff(staff: MedicalStaff): Long

  @Update
  suspend fun updateMedicalStaff(staff: MedicalStaff)

  @Delete
  suspend fun deleteMedicalStaff(staff: MedicalStaff)

  @Query("UPDATE medical_staff SET balanceDues = balanceDues + :delta WHERE id = :id")
  suspend fun updateStaffBalance(id: Long, delta: Double)

  // General Staff
  @Query("SELECT * FROM general_staff ORDER BY id ASC")
  fun getAllGeneralStaff(): Flow<List<GeneralStaff>>

  @Query("SELECT * FROM general_staff WHERE id = :id LIMIT 1")
  suspend fun getGeneralStaffById(id: Long): GeneralStaff?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGeneralStaff(staff: GeneralStaff): Long

  @Update
  suspend fun updateGeneralStaff(staff: GeneralStaff)

  @Delete
  suspend fun deleteGeneralStaff(staff: GeneralStaff)

  // Patients
  @Query("SELECT * FROM patients ORDER BY id DESC")
  fun getAllPatients(): Flow<List<Patient>>

  @Query("SELECT * FROM patients WHERE id = :id LIMIT 1")
  suspend fun getPatientById(id: Long): Patient?

  @Query("SELECT * FROM patients WHERE fullName LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' OR patientCode LIKE '%' || :query || '%' ORDER BY id DESC")
  fun searchPatients(query: String): Flow<List<Patient>>

  @Query("SELECT COUNT(*) FROM patients")
  fun getPatientsCount(): Flow<Int>

  @Query("SELECT COUNT(*) FROM patients")
  suspend fun getPatientsCountNow(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPatient(patient: Patient): Long

  @Update
  suspend fun updatePatient(patient: Patient)

  @Query("UPDATE patients SET balance = :balance WHERE id = :id")
  suspend fun updatePatientBalance(id: Long, balance: Double)

  @Delete
  suspend fun deletePatient(patient: Patient)

  // Medical Cases (الأمراض والحالات)
  @Query("SELECT * FROM medical_cases ORDER BY id DESC")
  fun getAllMedicalCases(): Flow<List<MedicalCase>>

  @Query("SELECT * FROM medical_cases WHERE patientId = :patientId ORDER BY id DESC")
  fun getMedicalCasesByPatient(patientId: Long): Flow<List<MedicalCase>>

  @Query("SELECT * FROM medical_cases WHERE doctorId = :doctorId ORDER BY id DESC")
  fun getMedicalCasesByDoctor(doctorId: Long): Flow<List<MedicalCase>>

  @Query("SELECT COUNT(*) FROM medical_cases WHERE status = 'نشطة'")
  fun getActiveCasesCount(): Flow<Int>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMedicalCase(item: MedicalCase): Long

  @Update
  suspend fun updateMedicalCase(item: MedicalCase)

  @Delete
  suspend fun deleteMedicalCase(item: MedicalCase)

  // Appointments
  @Query("SELECT * FROM appointments ORDER BY appointmentDate DESC, startTime ASC")
  fun getAllAppointments(): Flow<List<Appointment>>

  @Query("SELECT * FROM appointments WHERE appointmentDate = :date ORDER BY startTime ASC")
  fun getAppointmentsByDate(date: String): Flow<List<Appointment>>

  @Query("SELECT * FROM appointments WHERE patientId = :patientId ORDER BY appointmentDate DESC")
  fun getAppointmentsByPatient(patientId: Long): Flow<List<Appointment>>

  @Query("""
    SELECT * FROM appointments 
    WHERE appointmentDate = :date 
      AND status NOT IN ('ملغي', 'مكتمل')
      AND (doctorId = :doctorId OR patientId = :patientId)
      AND ((startTime < :endTime AND endTime > :startTime))
  """)
  suspend fun findConflictingAppointments(
    doctorId: Long,
    patientId: Long,
    date: String,
    startTime: String,
    endTime: String
  ): List<Appointment>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAppointment(appointment: Appointment): Long

  @Update
  suspend fun updateAppointment(appointment: Appointment)

  @Query("UPDATE appointments SET status = :status WHERE id = :id")
  suspend fun updateAppointmentStatus(id: Long, status: String)

  @Delete
  suspend fun deleteAppointment(appointment: Appointment)

  // Package Definitions
  @Query("SELECT * FROM package_definitions ORDER BY id ASC")
  fun getAllPackageDefinitions(): Flow<List<PackageDefinition>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPackageDefinition(pkg: PackageDefinition): Long

  @Update
  suspend fun updatePackageDefinition(pkg: PackageDefinition)

  @Delete
  suspend fun deletePackageDefinition(pkg: PackageDefinition)

  // Patient Packages
  @Query("SELECT * FROM patient_packages ORDER BY id DESC")
  fun getAllPatientPackages(): Flow<List<PatientPackage>>

  @Query("SELECT * FROM patient_packages WHERE patientId = :patientId ORDER BY id DESC")
  fun getPatientPackages(patientId: Long): Flow<List<PatientPackage>>

  @Query("SELECT * FROM patient_packages WHERE patientId = :patientId AND status = 'نشطة' AND remainingSessions > 0 LIMIT 1")
  suspend fun getActivePackageForPatient(patientId: Long): PatientPackage?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPatientPackage(pkg: PatientPackage): Long

  @Update
  suspend fun updatePatientPackage(pkg: PatientPackage)

  // Clinical Sessions (الجلسات الفردية وخصم الباقات)
  @Query("SELECT * FROM clinical_sessions ORDER BY id DESC")
  fun getAllClinicalSessions(): Flow<List<ClinicalSession>>

  @Query("SELECT * FROM clinical_sessions WHERE sessionDate = :date ORDER BY checkInTime DESC")
  fun getClinicalSessionsByDate(date: String): Flow<List<ClinicalSession>>

  @Query("SELECT * FROM clinical_sessions WHERE patientId = :patientId ORDER BY id DESC")
  fun getClinicalSessionsByPatient(patientId: Long): Flow<List<ClinicalSession>>

  @Query("SELECT * FROM clinical_sessions WHERE sessionTransactionId = :txId LIMIT 1")
  suspend fun getSessionByTxId(txId: String): ClinicalSession?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertClinicalSession(session: ClinicalSession): Long

  @Update
  suspend fun updateClinicalSession(session: ClinicalSession)

  @Delete
  suspend fun deleteClinicalSession(session: ClinicalSession)

  // Timeline / Medical Visits
  @Query("SELECT * FROM patient_timeline WHERE patientId = :patientId ORDER BY timestamp DESC")
  fun getTimelineByPatient(patientId: Long): Flow<List<PatientTimeline>>

  @Query("SELECT * FROM patient_timeline WHERE sessionTransactionId = :txId LIMIT 1")
  suspend fun getTimelineByTxId(txId: String): PatientTimeline?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTimeline(item: PatientTimeline): Long

  @Delete
  suspend fun deleteTimeline(item: PatientTimeline)

  // Finance Transactions & Bookkeeping
  @Query("SELECT * FROM finance_transactions ORDER BY id DESC")
  fun getAllFinanceTransactions(): Flow<List<FinanceTransaction>>

  @Query("SELECT * FROM finance_transactions WHERE patientId = :patientId ORDER BY id DESC")
  fun getFinanceByPatient(patientId: Long): Flow<List<FinanceTransaction>>

  @Query("SELECT * FROM finance_transactions WHERE id = :id LIMIT 1")
  suspend fun getFinanceTransactionById(id: Long): FinanceTransaction?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFinanceTransaction(tx: FinanceTransaction): Long

  @Query("UPDATE finance_transactions SET isVoided = 1, voidReason = :reason WHERE id = :id")
  suspend fun voidFinanceTransaction(id: Long, reason: String)

  // Chart of Accounts (دليل الحسابات - القيد المزدوج)
  @Query("SELECT * FROM chart_of_accounts ORDER BY accountCode ASC")
  fun getAllAccounts(): Flow<List<ChartOfAccount>>

  @Query("SELECT * FROM chart_of_accounts WHERE accountCode = :code LIMIT 1")
  suspend fun getAccountByCode(code: String): ChartOfAccount?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAccount(account: ChartOfAccount)

  @Query("UPDATE chart_of_accounts SET currentBalance = currentBalance + :delta WHERE accountCode = :code")
  suspend fun updateAccountBalance(code: String, delta: Double)

  // Notifications (مركز الإشعارات الموحد)
  @Query("SELECT * FROM app_notifications ORDER BY id DESC")
  fun getAllNotifications(): Flow<List<AppNotification>>

  @Query("SELECT COUNT(*) FROM app_notifications WHERE isRead = 0")
  fun getUnreadNotificationsCount(): Flow<Int>

  @Query("UPDATE app_notifications SET isRead = 1 WHERE id = :id")
  suspend fun markNotificationAsRead(id: Long)

  @Query("UPDATE app_notifications SET isRead = 1")
  suspend fun markAllNotificationsAsRead()

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertNotification(notification: AppNotification): Long

  @Query("DELETE FROM app_notifications")
  suspend fun clearAllNotifications()

  // App Users & Permissions (المستخدمون والصلاحيات)
  @Query("SELECT * FROM app_users ORDER BY id ASC")
  fun getAllUsers(): Flow<List<AppUser>>

  @Query("SELECT * FROM app_users WHERE username = :username LIMIT 1")
  suspend fun getUserByUsername(username: String): AppUser?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertUser(user: AppUser): Long

  @Update
  suspend fun updateUser(user: AppUser)

  @Delete
  suspend fun deleteUser(user: AppUser)

  // Audit Log (سجل العمليات والتدقيق)
  @Query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200")
  fun getAllAuditLogs(): Flow<List<AuditLog>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAuditLog(log: AuditLog): Long

  // Message Templates
  @Query("SELECT * FROM message_templates")
  fun getAllTemplates(): Flow<List<MessageTemplate>>

  @Query("SELECT * FROM message_templates WHERE `key` = :key LIMIT 1")
  suspend fun getTemplateByKey(key: String): MessageTemplate?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTemplate(template: MessageTemplate)
}
