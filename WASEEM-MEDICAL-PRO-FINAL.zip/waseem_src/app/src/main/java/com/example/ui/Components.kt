package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.*
import com.example.ui.theme.*

/**
 * Developer Stamp displayed at bottom of views and receipts
 */
@Composable
fun DeveloperFooter(modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    shape = RoundedCornerShape(12.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        Icons.Default.Code,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "تطوير: وسيم الفرح | هاتف: 774486588",
        style = MaterialTheme.typography.bodySmall.copy(
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      )
    }
  }
}

/**
 * Status badge with distinct colors for Appointments
 */
@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
  val (bgColor, textColor) = when (status) {
    "في الانتظار", "انتظار" -> StatusWaitingBg to StatusWaiting
    "تم الحضور", "حضر" -> StatusAttendedBg to StatusAttended
    "مؤكد" -> StatusConfirmedBg to StatusConfirmed
    "لم يحضر" -> StatusNoShowBg to StatusNoShow
    "ملغي" -> StatusCancelledBg to StatusCancelled
    "مكتمل", "مكتملة" -> StatusCompletedBg to StatusCompleted
    "نشط", "نشطة" -> StatusAttendedBg to StatusAttended
    "منتهية", "موقوف" -> StatusCancelledBg to StatusCancelled
    else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
  }

  Surface(
    color = bgColor,
    shape = RoundedCornerShape(8.dp),
    modifier = modifier
  ) {
    Text(
      text = status,
      color = textColor,
      style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
    )
  }
}

/**
 * App Top Bar designed precisely after WASEEM MEDICAL PRO template
 */
@Composable
fun ClinicTopBar(
  currentScreen: ClinicScreen,
  centerProfile: CenterProfile?,
  currentUser: AppUser,
  unreadCount: Int,
  onOpenDrawer: () -> Unit,
  onQuickSearchClick: () -> Unit,
  onNotificationsClick: () -> Unit,
  onUserSwitchClick: () -> Unit,
  onLicenseClick: () -> Unit,
  onSettingsClick: () -> Unit
) {
  Surface(
    color = Color.White,
    shadowElevation = 1.dp,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onOpenDrawer, modifier = Modifier.size(44.dp)) {
        Icon(Icons.Default.Menu, contentDescription = "القائمة", tint = Color(0xFF173B4D), modifier = Modifier.size(28.dp))
      }
      Spacer(Modifier.width(6.dp))
      Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("نظام وسيم الطبي", fontWeight = FontWeight.ExtraBold, color = Color(0xFF123047), fontSize = 17.sp, maxLines = 1)
        Text(centerProfile?.facilityName ?: "WASEEM MEDICAL PRO", color = Color(0xFF0D9488), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
      BadgedBox(
        badge = {
          if (unreadCount > 0) Badge(containerColor = Color(0xFFE53935)) { Text(unreadCount.toString()) }
        }
      ) {
        IconButton(onClick = onNotificationsClick, modifier = Modifier.size(44.dp)) {
          Icon(Icons.Default.Notifications, contentDescription = "الإشعارات", tint = Color(0xFF0D9488), modifier = Modifier.size(25.dp))
        }
      }
      Surface(onClick = onUserSwitchClick, shape = CircleShape, color = Color(0xFFE7F5F3), modifier = Modifier.size(40.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Icon(Icons.Default.Person, contentDescription = "المستخدم: ${currentUser.role}", tint = Color(0xFF0D9488), modifier = Modifier.size(24.dp))
        }
      }
    }
  }
}

/**
 * Modern Sidebar Drawer with all 30 pillars
 */
@Composable
fun ClinicDrawerContent(
  currentScreen: ClinicScreen,
  centerProfile: CenterProfile?,
  currentUser: AppUser,
  onNavigate: (ClinicScreen) -> Unit,
  onCloseDrawer: () -> Unit,
  onOpenLicense: () -> Unit
) {
  ModalDrawerSheet(
    modifier = Modifier.widthIn(max = 320.dp),
    drawerContainerColor = MaterialTheme.colorScheme.surface
  ) {
    // Header
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = WaseemBluePrimary
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Surface(
          shape = CircleShape,
          color = Color.White,
          border = androidx.compose.foundation.BorderStroke(2.5.dp, Color(0xFF10B981)),
          modifier = Modifier.size(60.dp)
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_waseem_logo),
            contentDescription = "شعار نظام وسيم الطبي",
            modifier = Modifier
              .fillMaxSize()
              .clip(CircleShape),
            contentScale = ContentScale.Crop
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "نظام وسيم الطبي PRO",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White,
            fontSize = 17.sp
          ),
          textAlign = TextAlign.Center
        )
        Text(
          text = "WASEEM MEDICAL PRO",
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.SemiBold,
            color = Color.White.copy(alpha = 0.95f),
            fontSize = 11.sp
          ),
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "${centerProfile?.facilityName ?: "الفرع الرئيسي - دمت"} | ${currentUser.fullName}",
          style = MaterialTheme.typography.bodySmall.copy(
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 10.sp
          ),
          textAlign = TextAlign.Center
        )
      }
    }

    Divider()

    // Navigation Items
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
      item {
        DrawerSectionTitle("الرئيسية والعمليات الطبية")
      }
      item {
        DrawerItem(
          icon = Icons.Default.Dashboard,
          label = "🏠 لوحة التحكم الرئيسية",
          isSelected = currentScreen == ClinicScreen.HOME
        ) {
          onNavigate(ClinicScreen.HOME)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Search,
          label = "🔍 واجهة البحث السريع",
          isSelected = currentScreen == ClinicScreen.QUICK_SEARCH
        ) {
          onNavigate(ClinicScreen.QUICK_SEARCH)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.PersonAdd,
          label = "➕ 1. إدخال حالة جديدة",
          isSelected = currentScreen == ClinicScreen.NEW_PATIENT
        ) {
          onNavigate(ClinicScreen.NEW_PATIENT)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.People,
          label = "👥 2. إدارة المرضى والملفات",
          isSelected = currentScreen == ClinicScreen.PATIENTS
        ) {
          onNavigate(ClinicScreen.PATIENTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Sick,
          label = "🩺 3. الأمراض والحالات الطبية",
          isSelected = currentScreen == ClinicScreen.MEDICAL_CASES
        ) {
          onNavigate(ClinicScreen.MEDICAL_CASES)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.CalendarMonth,
          label = "📅 4. إدارة المواعيد وجدولتها",
          isSelected = currentScreen == ClinicScreen.APPOINTMENTS
        ) {
          onNavigate(ClinicScreen.APPOINTMENTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.CheckCircle,
          label = "🩺 5. إدارة الجلسات والخصم التلقائي",
          isSelected = currentScreen == ClinicScreen.SESSIONS
        ) {
          onNavigate(ClinicScreen.SESSIONS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.MedicalServices,
          label = "📦 6. إدارة الباقات والتنبيهات",
          isSelected = currentScreen == ClinicScreen.PACKAGES
        ) {
          onNavigate(ClinicScreen.PACKAGES)
          onCloseDrawer()
        }
      }

      item {
        DrawerSectionTitle("المالية والمحاسبة والقيد المزدوج")
      }
      item {
        DrawerItem(
          icon = Icons.Default.ReceiptLong,
          label = "💵 7. سندات القبض والصرف",
          isSelected = currentScreen == ClinicScreen.FINANCE
        ) {
          onNavigate(ClinicScreen.FINANCE)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.AccountBalance,
          label = "📊 8. شجرة الحسابات واليومية العامة",
          isSelected = currentScreen == ClinicScreen.ACCOUNTS_LEDGER
        ) {
          onNavigate(ClinicScreen.ACCOUNTS_LEDGER)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Badge,
          label = "👨‍💼 9. الموظفون والرواتب والاستقطاعات",
          isSelected = currentScreen == ClinicScreen.STAFF
        ) {
          onNavigate(ClinicScreen.STAFF)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.HealthAndSafety,
          label = "👨‍⚕️ 10. الأطباء والكوادر وحساب الأتعاب",
          isSelected = currentScreen == ClinicScreen.MEDICAL_STAFF
        ) {
          onNavigate(ClinicScreen.MEDICAL_STAFF)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Assessment,
          label = "📈 11. التقارير الطبية والمالية",
          isSelected = currentScreen == ClinicScreen.REPORTS
        ) {
          onNavigate(ClinicScreen.REPORTS)
          onCloseDrawer()
        }
      }

      item {
        DrawerSectionTitle("إدارة النظام والرقابة")
      }
      item {
        DrawerItem(
          icon = Icons.Default.Notifications,
          label = "🔔 12. مركز الإشعارات الموحد",
          isSelected = currentScreen == ClinicScreen.NOTIFICATIONS
        ) {
          onNavigate(ClinicScreen.NOTIFICATIONS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.LocalHospital,
          label = "📋 13. دليل الأقسام والخدمات",
          isSelected = currentScreen == ClinicScreen.DEPARTMENTS
        ) {
          onNavigate(ClinicScreen.DEPARTMENTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.HistoryEdu,
          label = "📝 14. سجل العمليات والتدقيق (Audit Log)",
          isSelected = currentScreen == ClinicScreen.AUDIT_LOG
        ) {
          onNavigate(ClinicScreen.AUDIT_LOG)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Message,
          label = "💬 15. قوالب الرسائل التلقائية",
          isSelected = currentScreen == ClinicScreen.TEMPLATES
        ) {
          onNavigate(ClinicScreen.TEMPLATES)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Backup,
          label = "💾 16. النسخ الاحتياطي والاستعادة",
          isSelected = currentScreen == ClinicScreen.BACKUP
        ) {
          onNavigate(ClinicScreen.BACKUP)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Settings,
          label = "⚙️ 17. إعدادات النظام وقفل الفترات",
          isSelected = currentScreen == ClinicScreen.SETTINGS
        ) {
          onNavigate(ClinicScreen.SETTINGS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.VpnKey,
          label = "🔐 18. ترخيص النظام والتفعيل",
          isSelected = false
        ) {
          onOpenLicense()
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.SupportAgent,
          label = "📞 19. الدعم الفني وتواصل المطور",
          isSelected = currentScreen == ClinicScreen.SUPPORT
        ) {
          onNavigate(ClinicScreen.SUPPORT)
          onCloseDrawer()
        }
      }
    }

    // Permanent Developer Footprint in Drawer
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp),
      color = MaterialTheme.colorScheme.primaryContainer,
      shape = RoundedCornerShape(12.dp)
    ) {
      Column(
        modifier = Modifier.padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "نظام الشفاء لإدارة المراكز الطبية",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "تطوير: وسيم الفرح | هاتف: 774486588",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }
}

@Composable
private fun DrawerSectionTitle(title: String) {
  Text(
    text = title,
    style = MaterialTheme.typography.labelSmall.copy(
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary
    ),
    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
  )
}

@Composable
private fun DrawerItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  NavigationDrawerItem(
    icon = { Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp)) },
    label = {
      Text(
        text = label,
        style = MaterialTheme.typography.bodyMedium.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
          fontSize = 13.sp
        )
      )
    },
    selected = isSelected,
    onClick = onClick,
    modifier = Modifier.padding(vertical = 1.dp),
    shape = RoundedCornerShape(10.dp)
  )
}

/**
 * Bottom Navigation Bar styled after WASEEM MEDICAL PRO template
 */
@Composable
fun ClinicBottomBar(
  currentScreen: ClinicScreen,
  onNavigate: (ClinicScreen) -> Unit,
  onOpenMore: () -> Unit = {}
) {
  Surface(
    color = Color.White,
    shadowElevation = 10.dp,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 6.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceAround,
      verticalAlignment = Alignment.CenterVertically
    ) {
      WaseemBottomNavItem(Icons.Default.BarChart, "التقارير", currentScreen == ClinicScreen.REPORTS) { onNavigate(ClinicScreen.REPORTS) }
      WaseemBottomNavItem(Icons.Default.CalendarMonth, "المواعيد", currentScreen == ClinicScreen.APPOINTMENTS) { onNavigate(ClinicScreen.APPOINTMENTS) }
      WaseemBottomNavItem(Icons.Default.Home, "الرئيسية", currentScreen == ClinicScreen.HOME) { onNavigate(ClinicScreen.HOME) }
      WaseemBottomNavItem(Icons.Default.People, "المرضى", currentScreen == ClinicScreen.PATIENTS) { onNavigate(ClinicScreen.PATIENTS) }
      WaseemBottomNavItem(Icons.Default.MoreHoriz, "المزيد", false) { onOpenMore() }
    }
  }
}

@Composable
private fun WaseemBottomNavItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Column(
    modifier = Modifier
      .clip(RoundedCornerShape(18.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 9.dp, vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Surface(
      shape = CircleShape,
      color = if (isSelected) Color(0xFF0D9488) else Color.Transparent,
      modifier = Modifier.size(if (isSelected) 40.dp else 32.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, tint = if (isSelected) Color.White else Color(0xFF64748B), modifier = Modifier.size(22.dp))
      }
    }
    Text(label, color = if (isSelected) Color(0xFF0D766D) else Color(0xFF64748B), fontSize = 10.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
  }
}

/**
 * Confirmation dialog for sensitive operations (Delete, Cancel, Void)
 */
@Composable
fun ConfirmActionDialog(
  title: String,
  message: String,
  confirmButtonText: String = "تأكيد الإجراء",
  isDestructive: Boolean = true,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        if (isDestructive) Icons.Default.Warning else Icons.Default.Info,
        contentDescription = null,
        tint = if (isDestructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
      )
    },
    title = { Text(title, fontWeight = FontWeight.Bold) },
    text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
    confirmButton = {
      Button(
        onClick = {
          onConfirm()
          onDismiss()
        },
        colors = if (isDestructive) ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        else ButtonDefaults.buttonColors()
      ) {
        Text(confirmButtonText)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) {
        Text("تراجع وإلغاء")
      }
    }
  )
}

/**
 * User & Role Switching Dialog
 */
@Composable
fun UserSwitchDialog(
  users: List<AppUser>,
  currentUser: AppUser,
  onSelectUser: (AppUser) -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.SupervisorAccount, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("تبديل المستخدم والصلاحيات")
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "اختر المستخدم لتسجيل الدخول والتحكم بالصلاحيات المعينة له:",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)) {
          items(users) { u ->
            val isSelected = u.id == currentUser.id
            Surface(
              onClick = { onSelectUser(u) },
              shape = RoundedCornerShape(10.dp),
              color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
              border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(text = u.fullName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                  Text(text = "الدور: ${u.role}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
                if (isSelected) {
                  Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("إغلاق")
      }
    }
  )
}

/**
 * License & 30-Day Trial Dialog
 */
@Composable
fun LicenseDialog(
  profile: CenterProfile?,
  onActivate: (String) -> Unit,
  onDismiss: () -> Unit
) {
  var code by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.VpnKey, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "حالة ترخيص النظام", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (profile?.isLicenseActive == true) {
          Surface(
            color = Color(0xFFE8F5E9),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF2E7D32))
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text("النسخة مفعلة ومرخصة بالكامل ✓", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                Text("رمز الترخيص: ${profile.licenseKey}", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
              }
            }
          }
        } else {
          Surface(
            color = Color(0xFFFFF3E0),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text("أنت تعمل حالياً بالنسخة التجريبية المجانية", fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
              Text("المتبقي من الفترة التجريبية: ${profile?.trialDaysRemaining ?: 28} يوم", style = MaterialTheme.typography.bodyMedium, color = Color.DarkGray)
              Text("يرجى تفعيل النسخة لضمان عدم توقف الخدمات واستمرار الدعم والتحديثات.", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("أدخل رمز الترخيص والتفعيل الصادر من المطور") },
            placeholder = { Text("مثال: WAS-2026-MEDPRO") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
          )

          Spacer(modifier = Modifier.height(12.dp))

          Button(
            onClick = { onActivate(code) },
            modifier = Modifier.fillMaxWidth()
          ) {
            Text("تفعيل النسخة الآن")
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Developer info
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("للحصول على مفتاح التفعيل والدعم الفني:", style = MaterialTheme.typography.labelSmall)
            Text("المطور: وسيم الفرح | هاتف / واتساب: 774486588", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth()
        ) {
          Text("إغلاق")
        }
      }
    }
  }
}

/**
 * Dual Save Modal: Triggered on "حفظ وإرسال إشعار / طباعة"
 */
@Composable
fun PatientShareModal(
  patient: Patient,
  centerProfile: CenterProfile?,
  onDismiss: () -> Unit,
  onSendWhatsApp: (String, String) -> Unit,
  onSendSMS: (String, String) -> Unit,
  onOpenThermalPrint: (Patient) -> Unit,
  onOpenA4Print: (Patient) -> Unit
) {
  val centerName = centerProfile?.facilityName ?: "مجمع الشفاء الطبي"
  val welcomeMsg = "مرحباً بكم أخي الكريم / أختي الفاضلة ${patient.fullName} في $centerName 🏥.\nيسعدنا انضمامكم إلينا. تم تسجيل ملفكم الطبي بنجاح برقم: ${patient.patientCode}.\nنتمنى لكم دوام الصحة والعافية.\nتطوير: وسيم الفرح | هاتف: 774486588"

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("خيارات الإشعار والطباعة السريعة")
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "تم حفظ ملف المريض [${patient.fullName}] برقم (${patient.patientCode}) بنجاح.\nاختر الإجراء المطلوب الآن:",
          style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(16.dp))

        // WhatsApp button
        FilledTonalButton(
          onClick = {
            onSendWhatsApp(patient.phone, welcomeMsg)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF25D366).copy(alpha = 0.15f))
        ) {
          Text("🟢 إرسال رسالة ترحيبية عبر واتساب", color = Color(0xFF128C7E), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SMS button
        FilledTonalButton(
          onClick = {
            onSendSMS(patient.phone, welcomeMsg)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("💬 إرسال رسالة نصية (SMS)")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Thermal Print
        FilledTonalButton(
          onClick = {
            onOpenThermalPrint(patient)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("🖨️ طباعة إيصال حراري (بلوتوث 58/80mm)")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // A4 Print
        FilledTonalButton(
          onClick = {
            onOpenA4Print(patient)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("📄 طباعة استمارة رسمية عادية (A4 / A5)")
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("إغلاق والعودة")
      }
    }
  )
}

/**
 * Print Preview Dialog (Thermal 80mm or A4 layout)
 */
@Composable
fun PrintPreviewDialog(
  payload: PrintPayload,
  centerProfile: CenterProfile?,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isThermal = payload.type.startsWith("THERMAL")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.85f),
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Modal Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(if (isThermal) Color(0xFF2E383F) else MaterialTheme.colorScheme.primary)
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              if (isThermal) Icons.Default.Receipt else Icons.Default.Description,
              contentDescription = null,
              tint = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isThermal) "معاينة الطباعة الحرارية" else "معاينة الطباعة الرسمية A4",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
          }
        }

        // Printable Canvas / Document Container
        Box(
          modifier = Modifier
            .weight(1f)
            .background(Color(0xFFEFEFEF))
            .padding(12.dp)
        ) {
          Surface(
            modifier = Modifier
              .fillMaxWidth(if (isThermal) 0.88f else 1f)
              .align(Alignment.TopCenter)
              .verticalScroll(rememberScrollState()),
            color = Color.White,
            shadowElevation = 4.dp,
            shape = RoundedCornerShape(if (isThermal) 0.dp else 4.dp)
          ) {
            Column(
              modifier = Modifier.padding(if (isThermal) 14.dp else 20.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              // Facility Header
              Text(
                text = centerProfile?.facilityName ?: "مجمع الشفاء الطبي التخصصي",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
              )
              Text(
                text = "${centerProfile?.facilityType ?: "عيادة طبية"} | هاتف: ${centerProfile?.phone1 ?: "774486588"}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.DarkGray
              )
              Text(
                text = centerProfile?.address ?: "الشارع العام",
                style = MaterialTheme.typography.labelSmall,
                color = Color.Gray
              )

              Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = if (isThermal) 1.dp else 2.dp)

              // Document Title
              Surface(
                color = if (isThermal) Color(0xFFEEEEEE) else MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = payload.title,
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(6.dp)
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Content Lines
              payload.contentLines.forEach { line ->
                if (line.startsWith("---")) {
                  Divider(modifier = Modifier.padding(vertical = 4.dp))
                } else {
                  Text(
                    text = line,
                    style = if (isThermal) MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    else MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                  )
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Barcode simulation
              Surface(
                color = Color(0xFFFAFAFA),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray),
                modifier = Modifier
                  .fillMaxWidth(0.7f)
                  .height(38.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Text(
                    text = "||||| | |||| ||| ||||| ${payload.docNumber.ifEmpty { "W-1092" }} ||||",
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      letterSpacing = 2.sp
                    )
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Developer Footprint
              Divider(modifier = Modifier.padding(vertical = 6.dp))
              Text(
                text = "تطوير: وسيم الفرح | هاتف: 774486588",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.DarkGray
              )
            }
          }
        }

        // Action Buttons
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              Toast.makeText(context, "جاري إرسال أمر الطباعة للطابعة...", Toast.LENGTH_SHORT).show()
              onDismiss()
            },
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("طباعة المستند")
          }

          OutlinedButton(
            onClick = {
              val fullText = buildString {
                appendLine(centerProfile?.facilityName ?: "مجمع الشفاء الطبي")
                appendLine(payload.title)
                appendLine(payload.contentLines.joinToString("\n"))
                appendLine("تطوير: وسيم الفرح | هاتف: 774486588")
              }
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              clipboard.setPrimaryClip(ClipData.newPlainText("Print Content", fullText))
              Toast.makeText(context, "تم نسخ نص الإيصال بالكامل", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("نسخ النص")
          }
        }
      }
    }
  }
}

/**
 * Setup Wizard Dialog for registering facility profile
 */
@Composable
fun SetupWizardDialog(
  currentProfile: CenterProfile?,
  onSave: (CenterProfile) -> Unit,
  onDismiss: () -> Unit
) {
  var facilityName by remember { mutableStateOf(currentProfile?.facilityName ?: "مجمع الشفاء الطبي التخصصي") }
  var facilityType by remember { mutableStateOf(currentProfile?.facilityType ?: "مركز طبي") }
  var address by remember { mutableStateOf(currentProfile?.address ?: "الشارع العام - مجمع النخبة") }
  var phone1 by remember { mutableStateOf(currentProfile?.phone1 ?: "774486588") }
  var phone2 by remember { mutableStateOf(currentProfile?.phone2 ?: "01-445566") }
  var doctorInCharge by remember { mutableStateOf(currentProfile?.doctorInCharge ?: "د. وسيم الفرح") }
  var commercialRecord by remember { mutableStateOf(currentProfile?.commercialRecord ?: "CR-2024-8891") }
  var headerNotes by remember { mutableStateOf(currentProfile?.headerNotes ?: "رعاية طبية تخصصية متكاملة") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.9f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Storefront, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "إعدادات المنشأة والعيادة (Setup Wizard)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
        Text(
          text = "سجل بيانات منشأتك لتظهر تلقائياً في الترويسة والتقارير والسندات الرسمية",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Type selector
        Text("نوع المنشأة:", style = MaterialTheme.typography.labelMedium)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("مركز طبي", "عيادة تخصصية", "مجمع عيادات").forEach { type ->
            FilterChip(
              selected = facilityType == type,
              onClick = { facilityType = type },
              label = { Text(type) }
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = facilityName,
          onValueChange = { facilityName = it },
          label = { Text("اسم العيادة / المركز الطبي *") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = doctorInCharge,
          onValueChange = { doctorInCharge = it },
          label = { Text("المدير الطبي / الطبيب المسؤول") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("العنوان والموقع الجغرافي") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = phone1,
            onValueChange = { phone1 = it },
            label = { Text("هاتف 1 / واتساب *") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          OutlinedTextField(
            value = phone2,
            onValueChange = { phone2 = it },
            label = { Text("هاتف 2 / أرضي") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = commercialRecord,
          onValueChange = { commercialRecord = it },
          label = { Text("رقم الترخيص / السجل التجاري") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = headerNotes,
          onValueChange = { headerNotes = it },
          label = { Text("الترويسة والشعار النصي في التقارير") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Fixed Developer Signature
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "تطوير: وسيم الفرح | هاتف: 774486588",
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(8.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (facilityName.isNotBlank()) {
                onSave(
                  (currentProfile ?: CenterProfile()).copy(
                    facilityName = facilityName,
                    facilityType = facilityType,
                    address = address,
                    phone1 = phone1,
                    phone2 = phone2,
                    doctorInCharge = doctorInCharge,
                    commercialRecord = commercialRecord,
                    headerNotes = headerNotes,
                    isConfigured = true
                  )
                )
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الإعدادات")
          }
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

/**
 * Conflict Alert Dialog for Appointments
 */
@Composable
fun ConflictAlertDialog(
  conflicts: List<Appointment>,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.width(8.dp))
        Text("نظام منع التعارض الذكي (Conflict Alert)", color = MaterialTheme.colorScheme.error)
      }
    },
    text = {
      Column {
        Text(
          text = "تنبيه! لا يمكن حجز الموعد لوجود تعارض زمني مباشر في نفس الفترة المحددة:",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(8.dp))
        conflicts.forEach { c ->
          Surface(
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(
                text = "الموعد: ${c.appointmentCode} - الوقت: ${c.startTime} إلى ${c.endTime}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall
              )
              Text(
                text = "المريض: ${c.patientName} | الطبيب: ${c.doctorName}",
                style = MaterialTheme.typography.bodySmall
              )
            }
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "يرجى اختيار وقت بداية أو نهاية مختلف أو تغيير الطبيب المعالج.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    },
    confirmButton = {
      Button(onClick = onDismiss) {
        Text("حسناً، سأعدل الوقت")
      }
    }
  )
}
