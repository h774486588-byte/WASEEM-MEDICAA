package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.theme.*

/**
 * Developer Stamp displayed at bottom of views and receipts
 */
@Composable
fun DeveloperFooter(modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
    shape = RoundedCornerShape(12.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        Icons.Default.Code,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "تطوير: وسيم الفرح | هاتف: 774486588",
        style = MaterialTheme.typography.bodySmall.copy(
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      )
    }
  }
}

/**
 * Status badge with distinct colors for Appointments
 */
@Composable
fun StatusBadge(status: String, modifier: Modifier = Modifier) {
  val (bgColor, textColor) = when (status) {
    "في الانتظار" -> StatusWaitingBg to StatusWaiting
    "تم الحضور" -> StatusAttendedBg to StatusAttended
    "مؤكد" -> StatusConfirmedBg to StatusConfirmed
    "لم يحضر" -> StatusNoShowBg to StatusNoShow
    "ملغي" -> StatusCancelledBg to StatusCancelled
    "مكتمل" -> StatusCompletedBg to StatusCompleted
    else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
  }

  Surface(
    color = bgColor,
    shape = RoundedCornerShape(8.dp),
    modifier = modifier
  ) {
    Text(
      text = status,
      color = textColor,
      style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
    )
  }
}

/**
 * App Top Bar with quick search and facility name
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClinicTopBar(
  currentScreen: ClinicScreen,
  centerProfile: CenterProfile?,
  onOpenDrawer: () -> Unit,
  onQuickSearchClick: () -> Unit,
  onSettingsClick: () -> Unit
) {
  TopAppBar(
    title = {
      Column {
        Text(
          text = currentScreen.titleAr,
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = centerProfile?.facilityName ?: "مجمع الشفاء الطبي",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    },
    navigationIcon = {
      IconButton(onClick = onOpenDrawer) {
        Icon(Icons.Default.Menu, contentDescription = "القائمة")
      }
    },
    actions = {
      IconButton(onClick = onQuickSearchClick) {
        Icon(Icons.Default.Search, contentDescription = "بحث سريع")
      }
      IconButton(onClick = onSettingsClick) {
        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
      }
    },
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.primaryContainer,
      titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
      navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
      actionIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
    )
  )
}

/**
 * Modern Sidebar Drawer with all required sections
 */
@Composable
fun ClinicDrawerContent(
  currentScreen: ClinicScreen,
  centerProfile: CenterProfile?,
  onNavigate: (ClinicScreen) -> Unit,
  onCloseDrawer: () -> Unit
) {
  val context = LocalContext.current

  ModalDrawerSheet(
    modifier = Modifier.widthIn(max = 320.dp),
    drawerContainerColor = MaterialTheme.colorScheme.surface
  ) {
    // Header
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = MaterialTheme.colorScheme.primary
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(Color.White),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.LocalHospital,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(40.dp)
          )
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = centerProfile?.facilityName ?: "مجمع الشفاء الطبي التخصصي",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            color = Color.White
          ),
          textAlign = TextAlign.Center
        )
        Text(
          text = "${centerProfile?.facilityType ?: "مركز طبي"} - هاتف: ${centerProfile?.phone1 ?: "774486588"}",
          style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
        )
      }
    }

    Divider()

    // Navigation Items
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
      item {
        DrawerSectionTitle("العمليات الرئيسية")
      }
      item {
        DrawerItem(
          icon = Icons.Default.Search,
          label = "واجهة البحث السريع",
          isSelected = currentScreen == ClinicScreen.QUICK_SEARCH
        ) {
          onNavigate(ClinicScreen.QUICK_SEARCH)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.PersonAdd,
          label = "1. إدخال حالة جديدة",
          isSelected = currentScreen == ClinicScreen.NEW_PATIENT
        ) {
          onNavigate(ClinicScreen.NEW_PATIENT)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Event,
          label = "2. إدارة المواعيد",
          isSelected = currentScreen == ClinicScreen.APPOINTMENTS
        ) {
          onNavigate(ClinicScreen.APPOINTMENTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.MedicalServices,
          label = "3. إدارة الجلسات والباقات",
          isSelected = currentScreen == ClinicScreen.PACKAGES
        ) {
          onNavigate(ClinicScreen.PACKAGES)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.People,
          label = "4. إدارة المرضى والملفات",
          isSelected = currentScreen == ClinicScreen.PATIENTS
        ) {
          onNavigate(ClinicScreen.PATIENTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Badge,
          label = "5. إدارة العاملين والموظفين",
          isSelected = currentScreen == ClinicScreen.STAFF
        ) {
          onNavigate(ClinicScreen.STAFF)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.HealthAndSafety,
          label = "6. دليل الكوادر والأطباء",
          isSelected = currentScreen == ClinicScreen.MEDICAL_STAFF
        ) {
          onNavigate(ClinicScreen.MEDICAL_STAFF)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Assessment,
          label = "7. التقارير والإحصائيات",
          isSelected = currentScreen == ClinicScreen.REPORTS
        ) {
          onNavigate(ClinicScreen.REPORTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.AccountBalanceWallet,
          label = "8. الإدارة المالية والمحاسبة",
          isSelected = currentScreen == ClinicScreen.FINANCE
        ) {
          onNavigate(ClinicScreen.FINANCE)
          onCloseDrawer()
        }
      }

      item {
        DrawerSectionTitle("القائمة الجانبية وإعدادات النظام")
      }
      item {
        DrawerItem(
          icon = Icons.Default.LocalHospital,
          label = "1. إدارة الأقسام والخدمات",
          isSelected = currentScreen == ClinicScreen.DEPARTMENTS
        ) {
          onNavigate(ClinicScreen.DEPARTMENTS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Contacts,
          label = "2. دليل الكوادر الطبية",
          isSelected = currentScreen == ClinicScreen.MEDICAL_STAFF
        ) {
          onNavigate(ClinicScreen.MEDICAL_STAFF)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Storefront,
          label = "3. إعدادات المركز والعيادة",
          isSelected = currentScreen == ClinicScreen.SETTINGS
        ) {
          onNavigate(ClinicScreen.SETTINGS)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Backup,
          label = "4. النسخ الاحتياطي وقاعدة البيانات",
          isSelected = currentScreen == ClinicScreen.BACKUP
        ) {
          onNavigate(ClinicScreen.BACKUP)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.Message,
          label = "5. مركز الرسائل وإعادة الصياغة",
          isSelected = currentScreen == ClinicScreen.TEMPLATES
        ) {
          onNavigate(ClinicScreen.TEMPLATES)
          onCloseDrawer()
        }
      }
      item {
        DrawerItem(
          icon = Icons.Default.SupportAgent,
          label = "6. الدعم الفني والتواصل",
          isSelected = currentScreen == ClinicScreen.SUPPORT
        ) {
          onNavigate(ClinicScreen.SUPPORT)
          onCloseDrawer()
        }
      }
    }

    // Permanent Developer Footprint in Drawer
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp),
      color = MaterialTheme.colorScheme.primaryContainer,
      shape = RoundedCornerShape(12.dp)
    ) {
      Column(
        modifier = Modifier.padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Text(
          text = "نظام وسيم لإدارة المراكز الطبية",
          style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "تطوير: وسيم الفرح | هاتف: 774486588",
          style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }
}

@Composable
private fun DrawerSectionTitle(title: String) {
  Text(
    text = title,
    style = MaterialTheme.typography.labelSmall.copy(
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.primary
    ),
    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
  )
}

@Composable
private fun DrawerItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  NavigationDrawerItem(
    icon = { Icon(icon, contentDescription = null) },
    label = {
      Text(
        text = label,
        style = MaterialTheme.typography.bodyMedium.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
      )
    },
    selected = isSelected,
    onClick = onClick,
    modifier = Modifier.padding(vertical = 2.dp),
    shape = RoundedCornerShape(10.dp)
  )
}

/**
 * Bottom Navigation Bar for rapid one-tap screen switching
 */
@Composable
fun ClinicBottomBar(
  currentScreen: ClinicScreen,
  onNavigate: (ClinicScreen) -> Unit
) {
  NavigationBar(
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    NavigationBarItem(
      selected = currentScreen == ClinicScreen.QUICK_SEARCH,
      onClick = { onNavigate(ClinicScreen.QUICK_SEARCH) },
      icon = { Icon(Icons.Default.Search, contentDescription = "بحث") },
      label = { Text("بحث سريع") }
    )
    NavigationBarItem(
      selected = currentScreen == ClinicScreen.NEW_PATIENT,
      onClick = { onNavigate(ClinicScreen.NEW_PATIENT) },
      icon = { Icon(Icons.Default.PersonAdd, contentDescription = "حالة جديدة") },
      label = { Text("حالة جديدة") }
    )
    NavigationBarItem(
      selected = currentScreen == ClinicScreen.APPOINTMENTS,
      onClick = { onNavigate(ClinicScreen.APPOINTMENTS) },
      icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "المواعيد") },
      label = { Text("المواعيد") }
    )
    NavigationBarItem(
      selected = currentScreen == ClinicScreen.PACKAGES,
      onClick = { onNavigate(ClinicScreen.PACKAGES) },
      icon = { Icon(Icons.Default.MedicalServices, contentDescription = "الباقات") },
      label = { Text("الباقات") }
    )
    NavigationBarItem(
      selected = currentScreen == ClinicScreen.FINANCE,
      onClick = { onNavigate(ClinicScreen.FINANCE) },
      icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "المالية") },
      label = { Text("المالية") }
    )
  }
}

/**
 * Dual Save Modal: Triggered on "حفظ وإرسال إشعار / طباعة"
 */
@Composable
fun PatientShareModal(
  patient: Patient,
  centerProfile: CenterProfile?,
  onDismiss: () -> Unit,
  onSendWhatsApp: (String, String) -> Unit,
  onSendSMS: (String, String) -> Unit,
  onOpenThermalPrint: (Patient) -> Unit,
  onOpenA4Print: (Patient) -> Unit
) {
  val centerName = centerProfile?.facilityName ?: "مجمع الشفاء الطبي"
  val welcomeMsg = "مرحباً بكم أخي الكريم / أختي الفاضلة ${patient.fullName} في $centerName 🏥.\nيسعدنا انضمامكم إلينا. تم تسجيل ملفكم الطبي بنجاح برقم: ${patient.patientCode}.\nنتمنى لكم دوام الصحة والعافية.\nتطوير: وسيم الفرح | هاتف: 774486588"

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("خيارات الإشعار والطباعة السريعة")
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "تم حفظ ملف المريض [${patient.fullName}] برقم (${patient.patientCode}) بنجاح.\nاختر الإجراء المطلوب الآن:",
          style = MaterialTheme.typography.bodyMedium
        )
        Spacer(modifier = Modifier.height(16.dp))

        // WhatsApp button
        FilledTonalButton(
          onClick = {
            onSendWhatsApp(patient.phone, welcomeMsg)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.filledTonalButtonColors(containerColor = Color(0xFF25D366).copy(alpha = 0.15f))
        ) {
          Text("🟢 إرسال رسالة ترحيبية عبر واتساب", color = Color(0xFF128C7E), fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // SMS button
        FilledTonalButton(
          onClick = {
            onSendSMS(patient.phone, welcomeMsg)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Sms, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("💬 إرسال رسالة نصية (SMS)")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Thermal Print
        FilledTonalButton(
          onClick = {
            onOpenThermalPrint(patient)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("🖨️ طباعة إيصال حراري (بلوتوث 58/80mm)")
        }

        Spacer(modifier = Modifier.height(8.dp))

        // A4 Print
        FilledTonalButton(
          onClick = {
            onOpenA4Print(patient)
            onDismiss()
          },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("📄 طباعة استمارة رسمية عادية (A4 / A5)")
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("إغلاق والعودة")
      }
    }
  )
}

/**
 * Print Preview Dialog (Thermal 80mm or A4 layout)
 */
@Composable
fun PrintPreviewDialog(
  payload: PrintPayload,
  centerProfile: CenterProfile?,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val isThermal = payload.type.startsWith("THERMAL")

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.85f),
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Modal Header
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(if (isThermal) Color(0xFF2E383F) else MaterialTheme.colorScheme.primary)
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              if (isThermal) Icons.Default.Receipt else Icons.Default.Description,
              contentDescription = null,
              tint = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isThermal) "معاينة الطباعة الحرارية" else "معاينة الطباعة الرسمية A4",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
          }
        }

        // Printable Canvas / Document Container
        Box(
          modifier = Modifier
            .weight(1f)
            .background(Color(0xFFEFEFEF))
            .padding(12.dp)
        ) {
          Surface(
            modifier = Modifier
              .fillMaxWidth(if (isThermal) 0.88f else 1f)
              .align(Alignment.TopCenter)
              .verticalScroll(rememberScrollState()),
            color = Color.White,
            shadowElevation = 4.dp,
            shape = RoundedCornerShape(if (isThermal) 0.dp else 4.dp)
          ) {
            Column(
              modifier = Modifier.padding(if (isThermal) 14.dp else 20.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              // Facility Header
              Text(
                text = centerProfile?.facilityName ?: "مجمع الشفاء الطبي التخصصي",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
              )
              Text(
                text = "${centerProfile?.facilityType ?: "عيادة طبية"} | هاتف: ${centerProfile?.phone1 ?: "774486588"}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.DarkGray
              )
              Text(
                text = centerProfile?.address ?: "الشارع العام",
                style = MaterialTheme.typography.labelSmall,
                color = Color.Gray
              )

              Divider(modifier = Modifier.padding(vertical = 8.dp), thickness = if (isThermal) 1.dp else 2.dp)

              // Document Title
              Surface(
                color = if (isThermal) Color(0xFFEEEEEE) else MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = payload.title,
                  style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(6.dp)
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              // Content Lines
              payload.contentLines.forEach { line ->
                if (line.startsWith("---")) {
                  Divider(modifier = Modifier.padding(vertical = 4.dp))
                } else {
                  Text(
                    text = line,
                    style = if (isThermal) MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    else MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                  )
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              // Barcode simulation
              Surface(
                color = Color(0xFFFAFAFA),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.LightGray),
                modifier = Modifier
                  .fillMaxWidth(0.7f)
                  .height(38.dp)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Text(
                    text = "||||| | |||| ||| ||||| ${payload.docNumber.ifEmpty { "W-1092" }} ||||",
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontFamily = FontFamily.Monospace,
                      fontWeight = FontWeight.Bold,
                      letterSpacing = 2.sp
                    )
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Developer Footprint
              Divider(modifier = Modifier.padding(vertical = 6.dp))
              Text(
                text = "تطوير: وسيم الفرح | هاتف: 774486588",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = Color.DarkGray
              )
            }
          }
        }

        // Action Buttons
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              Toast.makeText(context, "جاري إرسال أمر الطباعة للطابعة...", Toast.LENGTH_SHORT).show()
              onDismiss()
            },
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("طباعة المستند")
          }

          OutlinedButton(
            onClick = {
              val fullText = buildString {
                appendLine(centerProfile?.facilityName ?: "مجمع الشفاء الطبي")
                appendLine(payload.title)
                appendLine(payload.contentLines.joinToString("\n"))
                appendLine("تطوير: وسيم الفرح | هاتف: 774486588")
              }
              val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
              clipboard.setPrimaryClip(ClipData.newPlainText("Print Content", fullText))
              Toast.makeText(context, "تم نسخ نص الإيصال بالكامل", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier.weight(1f)
          ) {
            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("نسخ النص")
          }
        }
      }
    }
  }
}

/**
 * Setup Wizard Dialog for registering facility profile
 */
@Composable
fun SetupWizardDialog(
  currentProfile: CenterProfile?,
  onSave: (CenterProfile) -> Unit,
  onDismiss: () -> Unit
) {
  var facilityName by remember { mutableStateOf(currentProfile?.facilityName ?: "مجمع الشفاء الطبي التخصصي") }
  var facilityType by remember { mutableStateOf(currentProfile?.facilityType ?: "مركز طبي") }
  var address by remember { mutableStateOf(currentProfile?.address ?: "الشارع العام - مجمع النخبة") }
  var phone1 by remember { mutableStateOf(currentProfile?.phone1 ?: "774486588") }
  var phone2 by remember { mutableStateOf(currentProfile?.phone2 ?: "01-445566") }
  var doctorInCharge by remember { mutableStateOf(currentProfile?.doctorInCharge ?: "د. وسيم الفرح") }
  var commercialRecord by remember { mutableStateOf(currentProfile?.commercialRecord ?: "CR-2024-8891") }
  var headerNotes by remember { mutableStateOf(currentProfile?.headerNotes ?: "رعاية طبية تخصصية متكاملة") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .fillMaxHeight(0.9f)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Storefront, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "إعدادات المنشأة والعيادة (Setup Wizard)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
        Text(
          text = "سجل بيانات منشأتك لتظهر تلقائياً في الترويسة والتقارير والسندات الرسمية",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Type selector
        Text("نوع المنشأة:", style = MaterialTheme.typography.labelMedium)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("مركز طبي", "عيادة تخصصية", "مجمع عيادات").forEach { type ->
            FilterChip(
              selected = facilityType == type,
              onClick = { facilityType = type },
              label = { Text(type) }
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = facilityName,
          onValueChange = { facilityName = it },
          label = { Text("اسم العيادة / المركز الطبي *") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = doctorInCharge,
          onValueChange = { doctorInCharge = it },
          label = { Text("المدير الطبي / الطبيب المسؤول") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = address,
          onValueChange = { address = it },
          label = { Text("العنوان والموقع الجغرافي") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = phone1,
            onValueChange = { phone1 = it },
            label = { Text("هاتف 1 / واتساب *") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          OutlinedTextField(
            value = phone2,
            onValueChange = { phone2 = it },
            label = { Text("هاتف 2 / أرضي") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = commercialRecord,
          onValueChange = { commercialRecord = it },
          label = { Text("رقم الترخيص / السجل التجاري") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = headerNotes,
          onValueChange = { headerNotes = it },
          label = { Text("الترويسة والشعار النصي في التقارير") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Fixed Developer Signature
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "تطوير: وسيم الفرح | هاتف: 774486588",
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(8.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (facilityName.isNotBlank()) {
                onSave(
                  (currentProfile ?: CenterProfile()).copy(
                    facilityName = facilityName,
                    facilityType = facilityType,
                    address = address,
                    phone1 = phone1,
                    phone2 = phone2,
                    doctorInCharge = doctorInCharge,
                    commercialRecord = commercialRecord,
                    headerNotes = headerNotes,
                    isConfigured = true
                  )
                )
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الإعدادات")
          }
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

/**
 * Conflict Alert Dialog for Appointments
 */
@Composable
fun ConflictAlertDialog(
  conflicts: List<Appointment>,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
        Spacer(modifier = Modifier.width(8.dp))
        Text("نظام منع التعارض الذكي (Conflict Alert)", color = MaterialTheme.colorScheme.error)
      }
    },
    text = {
      Column {
        Text(
          text = "تنبيه! لا يمكن حجز الموعد لوجود تعارض زمني مباشر في نفس الفترة المحددة:",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
        )
        Spacer(modifier = Modifier.height(8.dp))
        conflicts.forEach { c ->
          Surface(
            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp)
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(
                text = "الموعد: ${c.appointmentCode} - الوقت: ${c.startTime} إلى ${c.endTime}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodySmall
              )
              Text(
                text = "المريض: ${c.patientName} | الطبيب: ${c.doctorName}",
                style = MaterialTheme.typography.bodySmall
              )
            }
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "يرجى اختيار وقت بداية أو نهاية مختلف أو تغيير الطبيب المعالج.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    },
    confirmButton = {
      Button(onClick = onDismiss) {
        Text("حسناً، سأعدل الوقت")
      }
    }
  )
}
