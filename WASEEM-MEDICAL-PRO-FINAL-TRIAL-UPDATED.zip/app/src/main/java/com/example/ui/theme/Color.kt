package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Medical Center Palette
val MedicalTealPrimary = Color(0xFF006A6F)
val MedicalTealOnPrimary = Color(0xFFFFFFFF)
val MedicalTealContainer = Color(0xFF9EF2F6)
val MedicalTealOnContainer = Color(0xFF002022)

val MedicalSlateSecondary = Color(0xFF4A6267)
val MedicalSlateContainer = Color(0xFFCCE8ED)
val MedicalSlateOnContainer = Color(0xFF051F23)

val MedicalBlueTertiary = Color(0xFF006494)
val MedicalBlueContainer = Color(0xFFCBE6FF)
val MedicalBlueOnContainer = Color(0xFF001E30)

val MedicalBackground = Color(0xFFF6FBFB)
val MedicalSurface = Color(0xFFFFFFFF)
val MedicalSurfaceVariant = Color(0xFFE5EEF0)
val MedicalOutline = Color(0xFF70797A)
val MedicalOutlineVariant = Color(0xFFBEC8C9)

val MedicalDarkBackground = Color(0xFF0E1516)
val MedicalDarkSurface = Color(0xFF131D1E)
val MedicalDarkSurfaceVariant = Color(0xFF223033)
val MedicalDarkPrimary = Color(0xFF82D5DA)
val MedicalDarkSecondary = Color(0xFFB0CCCB)

// Status colors
val StatusWaiting = Color(0xFFD97706)
val StatusWaitingBg = Color(0xFFFEF3C7)
val StatusAttended = Color(0xFF059669)
val StatusAttendedBg = Color(0xFFD1FAE5)
val StatusConfirmed = Color(0xFF2563EB)
val StatusConfirmedBg = Color(0xFFDBEAFE)
val StatusNoShow = Color(0xFFDC2626)
val StatusNoShowBg = Color(0xFFFEE2E2)
val StatusCancelled = Color(0xFF64748B)
val StatusCancelledBg = Color(0xFFF1F5F9)
val StatusCompleted = Color(0xFF0D9488)
val StatusCompletedBg = Color(0xFFCCFBF1)
