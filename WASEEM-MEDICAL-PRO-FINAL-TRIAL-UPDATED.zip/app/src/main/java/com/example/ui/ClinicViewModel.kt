package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ClinicScreen(val titleAr: String) {
  QUICK_SEARCH("البحث السريع الفوري"),
  NEW_PATIENT("إدخال حالة جديدة"),
  APPOINTMENTS("إدارة المواعيد"),
  PACKAGES("إدارة الجلسات والباقات"),
  PATIENTS("إدارة المرضى"),
  STAFF("إدارة العاملين"),
  MEDICAL_STAFF("دليل الكوادر الطبية"),
  REPORTS("التقارير والإحصائيات"),
  FINANCE("الإدارة المالية"),
  DEPARTMENTS("الأقسام والخدمات"),
  SETTINGS("إعدادات المركز"),
  BACKUP("النسخ الاحتياطي"),
  TEMPLATES("مركز قوالب الرسائل"),
  SUPPORT("الدعم الفني والتواصل"),
  PATIENT_DETAILS("ملف المريض والسجل الطبي")
}

data class ConflictResult(
  val hasConflict: Boolean,
  val conflictingAppointments: List<Appointment> = emptyList()
)

data class PrintPayload(
  val type: String, // "THERMAL_RECEIPT", "A4_INVOICE", "A4_REPORT", "THERMAL_APPOINTMENTS", "PATIENT_ADMISSION"
  val title: String,
  val contentLines: List<String>,
  val patientName: String = "",
  val docNumber: String = "",
  val totalAmount: Double = 0.0,
  val date: String = "",
  val footerNotes: String = ""
)

class ClinicViewModel(application: Application) : AndroidViewModel(application) {

  private val repository: ClinicRepository

  init {
    val database = ClinicDatabase.getDatabase(application, viewModelScope)
    repository = ClinicRepository(database.clinicDao())
  }

  // Navigation state
  private val _currentScreen = MutableStateFlow(ClinicScreen.QUICK_SEARCH)
  val currentScreen: StateFlow<ClinicScreen> = _currentScreen.asStateFlow()

  // Selected patient for details view
  private val _selectedPatientId = MutableStateFlow<Long?>(null)
  val selectedPatientId: StateFlow<Long?> = _selectedPatientId.asStateFlow()

  // Quick Search
  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  // Global alert/snackbar message
  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  // Setup Wizard dialog visibility
  private val _showSetupWizard = MutableStateFlow(false)
  val showSetupWizard: StateFlow<Boolean> = _showSetupWizard.asStateFlow()

  // Print Dialog Payload
  private val _printPayload = MutableStateFlow<PrintPayload?>(null)
  val printPayload: StateFlow<PrintPayload?> = _printPayload.asStateFlow()

  // Quick Share / Notification Modal for New Patient
  private val _savedPatientShareModal = MutableStateFlow<Patient?>(null)
  val savedPatientShareModal: StateFlow<Patient?> = _savedPatientShareModal.asStateFlow()

  // Reactive Data Streams
  val centerProfile = repository.centerProfile.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), null
  )

  val departments = repository.allDepartments.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val services = repository.allServices.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val medicalStaff = repository.allMedicalStaff.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val generalStaff = repository.allGeneralStaff.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val patients = repository.allPatients.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val appointments = repository.allAppointments.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val packageDefinitions = repository.allPackageDefinitions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val patientPackages = repository.allPatientPackages.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val financeTransactions = repository.allFinanceTransactions.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  val templates = repository.allTemplates.stateIn(
    viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
  )

  // Selected Patient details
  val selectedPatient = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(null)
    else repository.allPatients.map { list -> list.find { it.id == id } }
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

  val selectedPatientTimeline = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getTimeline(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientPackages = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getPatientPackages(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientAppointments = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getAppointmentsByPatient(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val selectedPatientFinance = _selectedPatientId.flatMapLatest { id ->
    if (id == null) flowOf(emptyList())
    else repository.getFinanceByPatient(id)
  }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Navigation actions
  fun navigateTo(screen: ClinicScreen) {
    _currentScreen.value = screen
  }

  fun openPatientDetails(patientId: Long) {
    _selectedPatientId.value = patientId
    _currentScreen.value = ClinicScreen.PATIENT_DETAILS
  }

  fun setSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun clearSnackbar() {
    _snackbarMessage.value = null
  }

  fun showMessage(msg: String) {
    _snackbarMessage.value = msg
  }

  fun toggleSetupWizard(show: Boolean) {
    _showSetupWizard.value = show
  }

  fun closePrintDialog() {
    _printPayload.value = null
  }

  fun openPrintDialog(payload: PrintPayload) {
    _printPayload.value = payload
  }

  fun closeSavedPatientShareModal() {
    _savedPatientShareModal.value = null
  }

  // Next patient code
  suspend fun getNextPatientCode(): String {
    return repository.generateNextPatientCode()
  }

  // Facility Setup Save
  fun saveFacilitySettings(profile: CenterProfile) {
    viewModelScope.launch {
      repository.saveCenterProfile(profile)
      _showSetupWizard.value = false
      showMessage("تم حفظ إعدادات المنشأة بنجاح")
    }
  }

  // Save new patient
  fun saveNewPatient(
    fullName: String,
    phone: String,
    address: String,
    gender: String,
    birthDate: String,
    age: Int,
    emergencyRelation: String,
    emergencyPhone: String,
    deptId: Long,
    serviceId: Long,
    doctorId: Long,
    notes: String,
    andOpenShareModal: Boolean
  ) {
    viewModelScope.launch {
      val patientCode = repository.generateNextPatientCode()
      val patient = Patient(
        patientCode = patientCode,
        fullName = fullName.trim(),
        phone = phone.trim(),
        address = address.trim(),
        gender = gender,
        birthDate = birthDate,
        age = age,
        emergencyRelation = emergencyRelation.trim(),
        emergencyPhone = emergencyPhone.trim(),
        departmentId = deptId,
        serviceId = serviceId,
        doctorId = doctorId,
        notes = notes.trim()
      )
      val newId = repository.insertPatient(patient)
      val createdPatient = patient.copy(id = newId)

      // Also create an initial admission finance record / initial visit timeline if service was selected
      if (serviceId > 0) {
        val srv = services.value.find { it.id == serviceId }
        val doc = medicalStaff.value.find { it.id == doctorId }
        val dept = departments.value.find { it.id == deptId }
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        repository.insertTimeline(
          PatientTimeline(
            patientId = newId,
            visitDate = today,
            doctorName = doc?.name ?: "الاستقبال",
            serviceName = srv?.name ?: "فتح ملف وإدخال حالة",
            diagnosis = "تسجيل ملف طبي وإحالة للقسم",
            prescription = "-",
            notes = "القسم: ${dept?.name ?: "عام"} - السعر الافتراضي: ${srv?.defaultPrice ?: 0.0}"
          )
        )
      }

      if (andOpenShareModal) {
        _savedPatientShareModal.value = createdPatient
      } else {
        showMessage("تم حفظ بيانات المريض بنجاح برقم: $patientCode")
        navigateTo(ClinicScreen.PATIENTS)
      }
    }
  }

  // Appointment operations with Conflict Prevention
  fun bookAppointment(
    patientId: Long,
    patientName: String,
    patientPhone: String,
    departmentId: Long,
    departmentName: String,
    serviceId: Long,
    serviceName: String,
    doctorId: Long,
    doctorName: String,
    date: String,
    startTime: String,
    endTime: String,
    notes: String,
    onConflictDetected: (List<Appointment>) -> Unit,
    onSuccess: () -> Unit
  ) {
    viewModelScope.launch {
      // Check conflict
      val conflicts = repository.checkConflict(
        doctorId = doctorId,
        patientId = patientId,
        date = date,
        startTime = startTime,
        endTime = endTime
      )
      if (conflicts.isNotEmpty()) {
        onConflictDetected(conflicts)
        return@launch
      }

      val count = appointments.value.size
      val code = String.format(Locale.US, "APT-%03d", count + 101)
      val appt = Appointment(
        appointmentCode = code,
        patientId = patientId,
        patientName = patientName,
        patientPhone = patientPhone,
        departmentId = departmentId,
        departmentName = departmentName,
        serviceId = serviceId,
        serviceName = serviceName,
        doctorId = doctorId,
        doctorName = doctorName,
        appointmentDate = date,
        startTime = startTime,
        endTime = endTime,
        status = "في الانتظار",
        notes = notes
      )
      repository.insertAppointment(appt)
      showMessage("تم حجز الموعد بنجاح برقم: $code")
      onSuccess()
    }
  }

  fun updateAppointmentStatus(appointment: Appointment, newStatus: String) {
    viewModelScope.launch {
      val message = repository.updateAppointmentStatus(appointment, newStatus)
      if (message != null) {
        showMessage(message)
      } else {
        showMessage("تم تحديث حالة الموعد إلى: $newStatus")
      }
    }
  }

  fun deleteAppointment(appointment: Appointment) {
    viewModelScope.launch {
      repository.deleteAppointment(appointment)
      showMessage("تم حذف الموعد")
    }
  }

  // Package Operations
  fun createPackageDefinition(
    name: String,
    departmentId: Long,
    departmentName: String,
    totalSessions: Int,
    price: Double,
    validityDays: Int
  ) {
    viewModelScope.launch {
      repository.insertPackageDefinition(
        PackageDefinition(
          name = name.trim(),
          departmentId = departmentId,
          departmentName = departmentName,
          totalSessions = totalSessions,
          price = price,
          validityDays = validityDays
        )
      )
      showMessage("تمت إضافة الباقة العلاجية بنجاح")
    }
  }

  fun assignPackageToPatient(patientId: Long, packageDef: PackageDefinition) {
    viewModelScope.launch {
      val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
      val now = Date()
      val purchaseDate = sdf.format(now)
      val expiryMillis = now.time + (packageDef.validityDays.toLong() * 24 * 60 * 60 * 1000)
      val expiryDate = sdf.format(Date(expiryMillis))

      val patientPkg = PatientPackage(
        patientId = patientId,
        packageDefId = packageDef.id,
        packageName = packageDef.name,
        totalSessions = packageDef.totalSessions,
        usedSessions = 0,
        remainingSessions = packageDef.totalSessions,
        purchaseDate = purchaseDate,
        expiryDate = expiryDate,
        price = packageDef.price,
        status = "نشطة"
      )
      repository.insertPatientPackage(patientPkg)

      // Double-entry finance transaction
      val count = financeTransactions.value.size
      val docNumber = String.format(Locale.US, "REC-%04d", count + 1001)
      val patient = patients.value.find { it.id == patientId }

      repository.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = docNumber,
          docType = "سند قبض",
          date = purchaseDate,
          amount = packageDef.price,
          paymentMethod = "نقداً",
          payerOrBeneficiary = patient?.fullName ?: "مريض",
          patientId = patientId,
          debitAccount = "الصندوق الرئيسي (نقدية)",
          creditAccount = "إيرادات باقات طبية مقدمة",
          notes = "شراء ${packageDef.name} - عدد ${packageDef.totalSessions} جلسات"
        )
      )

      showMessage("تم ربط الباقة بالمريض وإصدار سند القبض $docNumber بنجاح")
    }
  }

  // Finance Transactions
  fun addFinanceTransaction(
    docType: String,
    amount: Double,
    paymentMethod: String,
    payerOrBeneficiary: String,
    patientId: Long?,
    doctorId: Long?,
    staffId: Long?,
    debitAccount: String,
    creditAccount: String,
    notes: String
  ) {
    viewModelScope.launch {
      val count = financeTransactions.value.size
      val prefix = if (docType == "سند قبض") "REC" else if (docType == "سند صرف") "PAY" else "INV"
      val docNumber = String.format(Locale.US, "%s-%04d", prefix, count + 1001)
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

      repository.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = docNumber,
          docType = docType,
          date = today,
          amount = amount,
          paymentMethod = paymentMethod,
          payerOrBeneficiary = payerOrBeneficiary.trim(),
          patientId = patientId,
          doctorId = doctorId,
          staffId = staffId,
          debitAccount = debitAccount,
          creditAccount = creditAccount,
          notes = notes.trim()
        )
      )

      // If doctor payment voucher, update doctor balance dues
      if (docType == "سند صرف" && doctorId != null) {
        repository.updateStaffBalance(doctorId, -amount)
      }

      showMessage("تم حفظ المستند المالي بنجاح برقم: $docNumber")
    }
  }

  // Staff operations
  fun addGeneralStaff(
    fullName: String,
    jobTitle: String,
    department: String,
    phone: String,
    nationalId: String,
    address: String,
    salary: Double
  ) {
    viewModelScope.launch {
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
      repository.insertGeneralStaff(
        GeneralStaff(
          fullName = fullName.trim(),
          jobTitle = jobTitle.trim(),
          department = department.trim(),
          phone = phone.trim(),
          nationalId = nationalId.trim(),
          address = address.trim(),
          hireDate = today,
          monthlySalary = salary
        )
      )
      showMessage("تمت إضافة الموظف بنجاح")
    }
  }

  fun updateGeneralStaff(staff: GeneralStaff) {
    viewModelScope.launch {
      repository.updateGeneralStaff(staff)
      showMessage("تم تحديث بيانات الموظف")
    }
  }

  // Medical Staff operations
  fun addMedicalStaff(
    name: String,
    role: String,
    specialty: String,
    departmentId: Long,
    phone: String,
    qualification: String,
    contractType: String,
    sharePercent: Double,
    monthlySalary: Double
  ) {
    viewModelScope.launch {
      repository.insertMedicalStaff(
        MedicalStaff(
          name = name.trim(),
          role = role,
          specialty = specialty.trim(),
          departmentId = departmentId,
          phone = phone.trim(),
          qualification = qualification.trim(),
          contractType = contractType,
          sharePercent = sharePercent,
          monthlySalary = monthlySalary
        )
      )
      showMessage("تمت إضافة الكادر الطبي بنجاح")
    }
  }

  fun updateMedicalStaff(staff: MedicalStaff) {
    viewModelScope.launch {
      repository.updateMedicalStaff(staff)
      showMessage("تم تحديث بيانات الكادر الطبي")
    }
  }

  // Department & Service Operations
  fun addDepartment(name: String) {
    viewModelScope.launch {
      val count = departments.value.size
      repository.insertDepartment(Department(name = name.trim(), sortOrder = count + 1))
      showMessage("تمت إضافة القسم الطبي بنجاح")
    }
  }

  fun toggleDepartmentStatus(dept: Department) {
    viewModelScope.launch {
      repository.updateDepartment(dept.copy(isActive = !dept.isActive))
      showMessage("تم تعديل حالة القسم")
    }
  }

  fun addService(name: String, deptId: Long, price: Double, sharePercent: Double) {
    viewModelScope.launch {
      repository.insertService(
        MedicalService(
          name = name.trim(),
          departmentId = deptId,
          defaultPrice = price,
          doctorSharePercent = sharePercent
        )
      )
      showMessage("تمت إضافة الخدمة الطبية بنجاح")
    }
  }

  fun toggleServiceStatus(srv: MedicalService) {
    viewModelScope.launch {
      repository.updateService(srv.copy(isActive = !srv.isActive))
      showMessage("تم تعديل حالة الخدمة")
    }
  }

  // Message Template customization
  fun saveTemplate(key: String, title: String, body: String) {
    viewModelScope.launch {
      repository.saveTemplate(MessageTemplate(key = key, title = title, templateBody = body))
      showMessage("تم حفظ وتحديث قالب الرسالة بنجاح")
    }
  }

  // Patient timeline addition
  fun addPatientTimelineEntry(
    patientId: Long,
    doctorName: String,
    serviceName: String,
    diagnosis: String,
    prescription: String,
    attachmentTitle: String,
    notes: String
  ) {
    viewModelScope.launch {
      val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
      repository.insertTimeline(
        PatientTimeline(
          patientId = patientId,
          visitDate = today,
          doctorName = doctorName.trim(),
          serviceName = serviceName.trim(),
          diagnosis = diagnosis.trim(),
          prescription = prescription.trim(),
          attachmentTitle = attachmentTitle.trim(),
          notes = notes.trim()
        )
      )
      showMessage("تمت إضافة الزيارة والتشخيص إلى ملف المريض")
    }
  }

  // Communication Handlers: WhatsApp & SMS
  fun sendWhatsApp(context: Context, phoneNumber: String, message: String) {
    try {
      val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
      val uri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}")
      val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      // Fallback intent
      try {
        val sendIntent = Intent(Intent.ACTION_VIEW).apply {
          data = Uri.parse("sms:${phoneNumber}")
          putExtra("sms_body", message)
          flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(sendIntent)
      } catch (ex: Exception) {
        showMessage("تعذر فتح تطبيق المراسلة: ${ex.localizedMessage}")
      }
    }
  }

  fun sendSMS(context: Context, phoneNumber: String, message: String) {
    try {
      val intent = Intent(Intent.ACTION_VIEW).apply {
        data = Uri.parse("sms:${phoneNumber}")
        putExtra("sms_body", message)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      showMessage("تعذر فتح تطبيق الرسائل القصيرة")
    }
  }

  fun callPhone(context: Context, phoneNumber: String) {
    try {
      val intent = Intent(Intent.ACTION_DIAL).apply {
        data = Uri.parse("tel:${phoneNumber}")
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      context.startActivity(intent)
    } catch (e: Exception) {
      showMessage("تعذر فتح جهات الاتصال")
    }
  }
}
