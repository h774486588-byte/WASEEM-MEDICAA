package com.example.security

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class LocalBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val db = applicationContext.getDatabasePath("clinic_database")
            if (!db.exists()) return Result.failure()
            val outDir = File(applicationContext.filesDir, "backups").apply { mkdirs() }
            val out = File(outDir, "waseem-medical-${System.currentTimeMillis()}.zip")
            ZipOutputStream(FileOutputStream(out)).use { zos ->
                FileInputStream(db).use { input ->
                    zos.putNextEntry(ZipEntry(db.name))
                    input.copyTo(zos)
                    zos.closeEntry()
                }
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
