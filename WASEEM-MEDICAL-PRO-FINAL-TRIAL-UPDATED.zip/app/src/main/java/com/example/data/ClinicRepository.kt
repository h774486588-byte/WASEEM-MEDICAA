package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClinicRepository(private val dao: ClinicDao) {

  // Center Profile
  val centerProfile: Flow<CenterProfile?> = dao.getCenterProfileFlow()
  suspend fun getCenterProfile(): CenterProfile? = dao.getCenterProfile()
  suspend fun saveCenterProfile(profile: CenterProfile) = dao.saveCenterProfile(profile)

  // Departments
  val allDepartments: Flow<List<Department>> = dao.getAllDepartments()
  suspend fun insertDepartment(dept: Department) = dao.insertDepartment(dept)
  suspend fun updateDepartment(dept: Department) = dao.updateDepartment(dept)
  suspend fun deleteDepartment(dept: Department) = dao.deleteDepartment(dept)

  // Services
  val allServices: Flow<List<MedicalService>> = dao.getAllServices()
  fun getServicesByDept(deptId: Long): Flow<List<MedicalService>> = dao.getServicesByDepartment(deptId)
  suspend fun insertService(service: MedicalService) = dao.insertService(service)
  suspend fun updateService(service: MedicalService) = dao.updateService(service)
  suspend fun deleteService(service: MedicalService) = dao.deleteService(service)

  // Medical Staff
  val allMedicalStaff: Flow<List<MedicalStaff>> = dao.getAllMedicalStaff()
  fun getMedicalStaffByDept(deptId: Long): Flow<List<MedicalStaff>> = dao.getMedicalStaffByDept(deptId)
  suspend fun insertMedicalStaff(staff: MedicalStaff) = dao.insertMedicalStaff(staff)
  suspend fun updateMedicalStaff(staff: MedicalStaff) = dao.updateMedicalStaff(staff)
  suspend fun deleteMedicalStaff(staff: MedicalStaff) = dao.deleteMedicalStaff(staff)
  suspend fun updateStaffBalance(id: Long, delta: Double) = dao.updateStaffBalance(id, delta)

  // General Staff
  val allGeneralStaff: Flow<List<GeneralStaff>> = dao.getAllGeneralStaff()
  suspend fun insertGeneralStaff(staff: GeneralStaff) = dao.insertGeneralStaff(staff)
  suspend fun updateGeneralStaff(staff: GeneralStaff) = dao.updateGeneralStaff(staff)
  suspend fun deleteGeneralStaff(staff: GeneralStaff) = dao.deleteGeneralStaff(staff)

  // Patients
  val allPatients: Flow<List<Patient>> = dao.getAllPatients()
  val patientsCount: Flow<Int> = dao.getPatientsCount()
  fun searchPatients(query: String): Flow<List<Patient>> = dao.searchPatients(query)
  suspend fun getPatientById(id: Long): Patient? = dao.getPatientById(id)
  suspend fun insertPatient(patient: Patient): Long = dao.insertPatient(patient)
  suspend fun updatePatient(patient: Patient) = dao.updatePatient(patient)
  suspend fun deletePatient(patient: Patient) = dao.deletePatient(patient)

  suspend fun generateNextPatientCode(): String {
    val count = dao.getPatientsCountNow()
    return String.format(Locale.US, "P-%04d", count + 1001)
  }

  // Appointments
  val allAppointments: Flow<List<Appointment>> = dao.getAllAppointments()
  fun getAppointmentsByDate(date: String): Flow<List<Appointment>> = dao.getAppointmentsByDate(date)
  fun getAppointmentsByPatient(patientId: Long): Flow<List<Appointment>> = dao.getAppointmentsByPatient(patientId)

  suspend fun checkConflict(
    doctorId: Long,
    patientId: Long,
    date: String,
    startTime: String,
    endTime: String
  ): List<Appointment> {
    return dao.findConflictingAppointments(doctorId, patientId, date, startTime, endTime)
  }

  suspend fun insertAppointment(appointment: Appointment): Long {
    return dao.insertAppointment(appointment)
  }

  suspend fun updateAppointment(appointment: Appointment) = dao.updateAppointment(appointment)
  suspend fun deleteAppointment(appointment: Appointment) = dao.deleteAppointment(appointment)

  /**
   * Smart Deductive Logic:
   * When appointment status transitions to 'مكتمل', automatically deducts 1 session from patient's active package.
   * Prevents double deduction with sessionTransactionId.
   * If appointment is cancelled or marked no-show after having been completed, refunds 1 session.
   */
  suspend fun updateAppointmentStatus(appointment: Appointment, newStatus: String): String? {
    val prevStatus = appointment.status
    dao.updateAppointmentStatus(appointment.id, newStatus)

    val txId = "APT_TX_${appointment.id}"

    if (newStatus == "مكتمل" && prevStatus != "مكتمل") {
      // Check if session has already been deducted
      val existingLog = dao.getTimelineByTxId(txId)
      if (existingLog == null) {
        val activePkg = dao.getActivePackageForPatient(appointment.patientId)
        if (activePkg != null && activePkg.remainingSessions > 0) {
          val updatedUsed = activePkg.usedSessions + 1
          val updatedRemaining = (activePkg.remainingSessions - 1).coerceAtLeast(0)
          val pkgStatus = if (updatedRemaining == 0) "منتهية" else "نشطة"
          dao.updatePatientPackage(
            activePkg.copy(
              usedSessions = updatedUsed,
              remainingSessions = updatedRemaining,
              status = pkgStatus
            )
          )

          // Add to patient timeline
          val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
          dao.insertTimeline(
            PatientTimeline(
              patientId = appointment.patientId,
              visitDate = currentDate,
              doctorName = appointment.doctorName,
              serviceName = appointment.serviceName,
              diagnosis = "إتمام جلسة علاجية بموجب الحجز ${appointment.appointmentCode}",
              prescription = "متابعة الخطة العلاجية المقررة",
              notes = "تم خصم جلسة 1 آلياً من باقة [${activePkg.packageName}] - الرصيد المتبقي: $updatedRemaining جلسة",
              sessionTransactionId = txId
            )
          )
          return "تم إكمال الموعد وخصم جلسة واحدة تلقائياً من باقة [${activePkg.packageName}]. الرصيد المتبقي: $updatedRemaining جلسة."
        }
      }
    } else if ((newStatus == "ملغي" || newStatus == "لم يحضر") && prevStatus == "مكتمل") {
      // Smart Refund logic: Return session to active package if it was previously deducted
      val existingLog = dao.getTimelineByTxId(txId)
      if (existingLog != null) {
        val activePkg = dao.getActivePackageForPatient(appointment.patientId)
        if (activePkg != null) {
          val updatedUsed = (activePkg.usedSessions - 1).coerceAtLeast(0)
          val updatedRemaining = activePkg.remainingSessions + 1
          dao.updatePatientPackage(
            activePkg.copy(
              usedSessions = updatedUsed,
              remainingSessions = updatedRemaining,
              status = "نشطة"
            )
          )
          dao.deleteTimeline(existingLog)
          return "تم تعديل الموعد إلى ($newStatus) وإعادة الجلسة بنجاح إلى رصيد باقة المريض. الرصيد الحالي: $updatedRemaining جلسة."
        }
      }
    }
    return null
  }

  // Packages
  val allPackageDefinitions: Flow<List<PackageDefinition>> = dao.getAllPackageDefinitions()
  suspend fun insertPackageDefinition(pkg: PackageDefinition) = dao.insertPackageDefinition(pkg)
  suspend fun updatePackageDefinition(pkg: PackageDefinition) = dao.updatePackageDefinition(pkg)
  suspend fun deletePackageDefinition(pkg: PackageDefinition) = dao.deletePackageDefinition(pkg)

  val allPatientPackages: Flow<List<PatientPackage>> = dao.getAllPatientPackages()
  fun getPatientPackages(patientId: Long): Flow<List<PatientPackage>> = dao.getPatientPackages(patientId)
  suspend fun insertPatientPackage(pkg: PatientPackage) = dao.insertPatientPackage(pkg)
  suspend fun updatePatientPackage(pkg: PatientPackage) = dao.updatePatientPackage(pkg)

  // Timeline
  fun getTimeline(patientId: Long): Flow<List<PatientTimeline>> = dao.getTimelineByPatient(patientId)
  suspend fun insertTimeline(item: PatientTimeline) = dao.insertTimeline(item)
  suspend fun deleteTimeline(item: PatientTimeline) = dao.deleteTimeline(item)

  // Finance Transactions
  val allFinanceTransactions: Flow<List<FinanceTransaction>> = dao.getAllFinanceTransactions()
  fun getFinanceByPatient(patientId: Long): Flow<List<FinanceTransaction>> = dao.getFinanceByPatient(patientId)
  suspend fun insertFinanceTransaction(tx: FinanceTransaction) = dao.insertFinanceTransaction(tx)

  // Templates
  val allTemplates: Flow<List<MessageTemplate>> = dao.getAllTemplates()
  suspend fun getTemplateByKey(key: String): MessageTemplate? = dao.getTemplateByKey(key)
  suspend fun saveTemplate(template: MessageTemplate) = dao.insertTemplate(template)
}
