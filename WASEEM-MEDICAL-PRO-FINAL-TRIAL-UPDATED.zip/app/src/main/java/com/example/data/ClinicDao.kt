package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ClinicDao {

  // Center Profile
  @Query("SELECT * FROM center_profile WHERE id = 1 LIMIT 1")
  fun getCenterProfileFlow(): Flow<CenterProfile?>

  @Query("SELECT * FROM center_profile WHERE id = 1 LIMIT 1")
  suspend fun getCenterProfile(): CenterProfile?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveCenterProfile(profile: CenterProfile)

  // Departments
  @Query("SELECT * FROM departments ORDER BY sortOrder ASC, id ASC")
  fun getAllDepartments(): Flow<List<Department>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDepartment(dept: Department): Long

  @Update
  suspend fun updateDepartment(dept: Department)

  @Delete
  suspend fun deleteDepartment(dept: Department)

  // Medical Services
  @Query("SELECT * FROM medical_services ORDER BY id ASC")
  fun getAllServices(): Flow<List<MedicalService>>

  @Query("SELECT * FROM medical_services WHERE departmentId = :deptId AND isActive = 1 ORDER BY id ASC")
  fun getServicesByDepartment(deptId: Long): Flow<List<MedicalService>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertService(service: MedicalService): Long

  @Update
  suspend fun updateService(service: MedicalService)

  @Delete
  suspend fun deleteService(service: MedicalService)

  // Medical Staff (Doctors, Nurses, Specialists)
  @Query("SELECT * FROM medical_staff ORDER BY id ASC")
  fun getAllMedicalStaff(): Flow<List<MedicalStaff>>

  @Query("SELECT * FROM medical_staff WHERE departmentId = :deptId AND isActive = 1")
  fun getMedicalStaffByDept(deptId: Long): Flow<List<MedicalStaff>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMedicalStaff(staff: MedicalStaff): Long

  @Update
  suspend fun updateMedicalStaff(staff: MedicalStaff)

  @Delete
  suspend fun deleteMedicalStaff(staff: MedicalStaff)

  @Query("UPDATE medical_staff SET balanceDues = balanceDues + :delta WHERE id = :id")
  suspend fun updateStaffBalance(id: Long, delta: Double)

  // General Staff
  @Query("SELECT * FROM general_staff ORDER BY id ASC")
  fun getAllGeneralStaff(): Flow<List<GeneralStaff>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertGeneralStaff(staff: GeneralStaff): Long

  @Update
  suspend fun updateGeneralStaff(staff: GeneralStaff)

  @Delete
  suspend fun deleteGeneralStaff(staff: GeneralStaff)

  // Patients
  @Query("SELECT * FROM patients ORDER BY id DESC")
  fun getAllPatients(): Flow<List<Patient>>

  @Query("SELECT * FROM patients WHERE id = :id LIMIT 1")
  suspend fun getPatientById(id: Long): Patient?

  @Query("SELECT * FROM patients WHERE fullName LIKE '%' || :query || '%' OR phone LIKE '%' || :query || '%' OR patientCode LIKE '%' || :query || '%' ORDER BY id DESC")
  fun searchPatients(query: String): Flow<List<Patient>>

  @Query("SELECT COUNT(*) FROM patients")
  fun getPatientsCount(): Flow<Int>

  @Query("SELECT COUNT(*) FROM patients")
  suspend fun getPatientsCountNow(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPatient(patient: Patient): Long

  @Update
  suspend fun updatePatient(patient: Patient)

  @Delete
  suspend fun deletePatient(patient: Patient)

  // Appointments
  @Query("SELECT * FROM appointments ORDER BY appointmentDate DESC, startTime ASC")
  fun getAllAppointments(): Flow<List<Appointment>>

  @Query("SELECT * FROM appointments WHERE appointmentDate = :date ORDER BY startTime ASC")
  fun getAppointmentsByDate(date: String): Flow<List<Appointment>>

  @Query("SELECT * FROM appointments WHERE patientId = :patientId ORDER BY appointmentDate DESC")
  fun getAppointmentsByPatient(patientId: Long): Flow<List<Appointment>>

  @Query("""
    SELECT * FROM appointments 
    WHERE appointmentDate = :date 
      AND status NOT IN ('ملغي', 'مكتمل')
      AND (doctorId = :doctorId OR patientId = :patientId)
      AND ((startTime < :endTime AND endTime > :startTime))
  """)
  suspend fun findConflictingAppointments(
    doctorId: Long,
    patientId: Long,
    date: String,
    startTime: String,
    endTime: String
  ): List<Appointment>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAppointment(appointment: Appointment): Long

  @Update
  suspend fun updateAppointment(appointment: Appointment)

  @Query("UPDATE appointments SET status = :status WHERE id = :id")
  suspend fun updateAppointmentStatus(id: Long, status: String)

  @Delete
  suspend fun deleteAppointment(appointment: Appointment)

  // Package Definitions
  @Query("SELECT * FROM package_definitions ORDER BY id ASC")
  fun getAllPackageDefinitions(): Flow<List<PackageDefinition>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPackageDefinition(pkg: PackageDefinition): Long

  @Update
  suspend fun updatePackageDefinition(pkg: PackageDefinition)

  @Delete
  suspend fun deletePackageDefinition(pkg: PackageDefinition)

  // Patient Packages
  @Query("SELECT * FROM patient_packages ORDER BY id DESC")
  fun getAllPatientPackages(): Flow<List<PatientPackage>>

  @Query("SELECT * FROM patient_packages WHERE patientId = :patientId ORDER BY id DESC")
  fun getPatientPackages(patientId: Long): Flow<List<PatientPackage>>

  @Query("SELECT * FROM patient_packages WHERE patientId = :patientId AND status = 'نشطة' AND remainingSessions > 0 LIMIT 1")
  suspend fun getActivePackageForPatient(patientId: Long): PatientPackage?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPatientPackage(pkg: PatientPackage): Long

  @Update
  suspend fun updatePatientPackage(pkg: PatientPackage)

  // Timeline / Medical Visits
  @Query("SELECT * FROM patient_timeline WHERE patientId = :patientId ORDER BY timestamp DESC")
  fun getTimelineByPatient(patientId: Long): Flow<List<PatientTimeline>>

  @Query("SELECT * FROM patient_timeline WHERE sessionTransactionId = :txId LIMIT 1")
  suspend fun getTimelineByTxId(txId: String): PatientTimeline?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTimeline(item: PatientTimeline): Long

  @Delete
  suspend fun deleteTimeline(item: PatientTimeline)

  // Finance Transactions & Bookkeeping
  @Query("SELECT * FROM finance_transactions ORDER BY id DESC")
  fun getAllFinanceTransactions(): Flow<List<FinanceTransaction>>

  @Query("SELECT * FROM finance_transactions WHERE patientId = :patientId ORDER BY id DESC")
  fun getFinanceByPatient(patientId: Long): Flow<List<FinanceTransaction>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertFinanceTransaction(tx: FinanceTransaction): Long

  // Message Templates
  @Query("SELECT * FROM message_templates")
  fun getAllTemplates(): Flow<List<MessageTemplate>>

  @Query("SELECT * FROM message_templates WHERE `key` = :key LIMIT 1")
  suspend fun getTemplateByKey(key: String): MessageTemplate?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTemplate(template: MessageTemplate)
}
