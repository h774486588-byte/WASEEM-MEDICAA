package com.example.security

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class TrialLicenseManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("waseem_license", Context.MODE_PRIVATE)

    private fun installDate(): Long {
        val existing = prefs.getLong("install_date", 0L)
        if (existing != 0L) return existing
        val now = System.currentTimeMillis()
        prefs.edit().putLong("install_date", now).apply()
        return now
    }

    fun daysRemaining(): Long {
        if (isLicensed()) return Long.MAX_VALUE
        val elapsed = System.currentTimeMillis() - installDate()
        val days = TimeUnit.MILLISECONDS.toDays(elapsed)
        return (30L - days).coerceAtLeast(0L)
    }

    fun isTrialActive(): Boolean = !isLicensed() && daysRemaining() > 0

    fun isLicensed(): Boolean = prefs.getBoolean("licensed", false)

    private fun deviceId(): String {
        return Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID).orEmpty()
    }

    /**
     * Offline activation: the developer can issue a code for a specific device.
     * The fixed owner code is retained for the developer's own unrestricted copy.
     */
    fun activationRequestId(): String = deviceId().ifBlank { "UNKNOWN-DEVICE" }

    fun expectedDeviceCode(): String {
        val raw = "WASEEM-MEDICAL-PRO|774486588|${deviceId()}|2026"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        return "WM-${digest.joinToString("") { "%02X".format(it) }.take(12)}"
    }

    fun activate(licenseCode: String): Boolean {
        val normalized = licenseCode.trim().uppercase(Locale.ROOT)
        val ownerCode = "WASEEM-774486588-PRO"
        val valid = normalized == ownerCode || normalized == expectedDeviceCode()
        if (!valid) return false
        prefs.edit()
            .putBoolean("licensed", true)
            .putString("license_code", normalized)
            .putLong("activated_at", System.currentTimeMillis())
            .apply()
        return true
    }

    fun statusText(): String {
        if (isLicensed()) return "مرخّص"
        return if (isTrialActive()) "تجريبي — متبقّي ${daysRemaining()} يومًا"
        else "انتهت الفترة التجريبية"
    }

    fun activatedDate(): String {
        val ts = prefs.getLong("activated_at", 0L)
        if (ts == 0L) return "-"
        return SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date(ts))
    }
}
