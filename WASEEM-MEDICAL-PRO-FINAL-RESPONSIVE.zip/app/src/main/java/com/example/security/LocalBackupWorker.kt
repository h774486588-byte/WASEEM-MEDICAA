package com.example.security

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class LocalBackupWorker(
  appContext: Context,
  workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

  override suspend fun doWork(): Result {
    return try {
      val db = applicationContext.getDatabasePath("waseem_clinic_database.db")
      if (!db.exists()) return Result.failure()

      val backupDir = File(applicationContext.filesDir, "backups").apply { mkdirs() }
      val zipFile = File(backupDir, "waseem-medical-${System.currentTimeMillis()}.zip")

      // Include the main DB plus SQLite WAL/SHM companions when present so the
      // backup remains recoverable even while Room is using WAL journaling.
      val candidates = listOf(
        db,
        File(db.parentFile, db.name + "-wal"),
        File(db.parentFile, db.name + "-shm")
      ).filter { it.exists() }

      ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
        candidates.forEach { source ->
          FileInputStream(source).use { input ->
            zos.putNextEntry(ZipEntry(source.name))
            input.copyTo(zos)
            zos.closeEntry()
          }
        }
      }

      val prefs = applicationContext.getSharedPreferences("waseem_backup", Context.MODE_PRIVATE)
      prefs.getString("tree_uri", null)?.let { raw ->
        copyToSelectedFolder(Uri.parse(raw), zipFile)
      }

      prefs.edit()
        .putLong("last_backup_at", System.currentTimeMillis())
        .putString("last_backup_file", zipFile.name)
        .apply()

      Result.success()
    } catch (_: Exception) {
      Result.retry()
    }
  }

  private fun copyToSelectedFolder(treeUri: Uri, zipFile: File) {
    val target = DocumentsContract.createDocument(
      applicationContext.contentResolver,
      treeUri,
      "application/zip",
      zipFile.name
    ) ?: return

    applicationContext.contentResolver.openOutputStream(target)?.use { output ->
      FileInputStream(zipFile).use { input -> input.copyTo(output) }
    }
  }
}
