package com.example

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.Patient
import com.example.ui.*
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.security.TrialLicenseManager

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    if (android.os.Build.VERSION.SDK_INT >= 33 &&
      checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
    ) {
      ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7001)
    }
    setContent {
      MyApplicationTheme {
        // Enforce Arabic Right-to-Left (RTL) Layout Direction
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          AppEntry()
        }
      }
    }
  }
}


@Composable
fun AppEntry() {
  val context = LocalContext.current
  val license = remember { TrialLicenseManager(context) }
  var splash by remember { mutableStateOf(true) }
  var licenseChanged by remember { mutableIntStateOf(0) }

  LaunchedEffect(Unit) {
    delay(1500)
    splash = false
  }

  if (splash) {
    WaseemSplashScreen()
  } else {
    if (licenseChanged >= 0 && !license.isLicensed() && !license.isTrialActive()) {
      LicenseExpiredScreen(
        onActivate = { code ->
          if (license.activate(code)) {
            licenseChanged++
            true
          } else false
        }
      )
    } else {
      MedicalClinicApp()
    }
  }
}

@Composable
fun WaseemSplashScreen() {
  Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
      ) {
        Surface(
          modifier = Modifier.size(112.dp),
          shape = RoundedCornerShape(30.dp),
          color = MaterialTheme.colorScheme.primaryContainer,
          shadowElevation = 10.dp
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(Icons.Default.LocalHospital, null, Modifier.size(66.dp), tint = MaterialTheme.colorScheme.primary)
          }
        }
        Text("نظام وسيم الطبي", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
        Text("WASEEM MEDICAL PRO", style = MaterialTheme.typography.titleSmall)
        Text("إدارة المراكز والعيادات • المرضى • الجلسات • المالية", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LinearProgressIndicator(Modifier.width(180.dp))
        Text("تطوير: وسيم الفرح | هاتف: 774486588", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
      }
    }
  }
}

@Composable
fun LicenseExpiredScreen(onActivate: (String) -> Boolean) {
  var code by remember { mutableStateOf("") }
  var error by remember { mutableStateOf(false) }

  Surface(Modifier.fillMaxSize()) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
      Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
        Column(
          Modifier.padding(22.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Icon(Icons.Default.VerifiedUser, null, Modifier.size(58.dp), tint = MaterialTheme.colorScheme.primary)
          Text("تفعيل نظام وسيم الطبي", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
          Text("انتهت الفترة التجريبية المجانية لمدة 30 يوماً. أدخل رمز الترخيص الصادر من المطوّر لتفعيل النسخة الكاملة.")
          Text(
            "معرّف الجهاز للتفعيل: ${TrialLicenseManager(LocalContext.current).activationRequestId()}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OutlinedTextField(
            value = code,
            onValueChange = { code = it; error = false },
            label = { Text("رمز الترخيص") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            isError = error
          )
          if (error) Text("رمز الترخيص غير صالح.", color = MaterialTheme.colorScheme.error)
          Button(
            onClick = { error = !onActivate(code) },
            modifier = Modifier.fillMaxWidth()
          ) { Text("تفعيل النسخة") }
          Text("تطوير: وسيم الفرح | هاتف: 774486588", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicalClinicApp(viewModel: ClinicViewModel = viewModel()) {
  val context = LocalContext.current
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()

  val currentScreen by viewModel.currentScreen.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()
  val snackbarMessage by viewModel.snackbarMessage.collectAsState()
  val showSetupWizard by viewModel.showSetupWizard.collectAsState()
  val printPayload by viewModel.printPayload.collectAsState()
  val savedPatientShareModal by viewModel.savedPatientShareModal.collectAsState()
  val unreadNotifications by viewModel.unreadNotificationsCount.collectAsState()

  val snackbarHostState = remember { SnackbarHostState() }

  // Reactive Snackbar handler
  LaunchedEffect(snackbarMessage) {
    snackbarMessage?.let { msg ->
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  // Setup Wizard Dialog
  if (showSetupWizard) {
    SetupWizardDialog(
      currentProfile = centerProfile,
      onSave = { updated ->
        viewModel.saveFacilitySettings(updated)
      },
      onDismiss = { viewModel.toggleSetupWizard(false) }
    )
  }

  // Dual Save Share Modal
  savedPatientShareModal?.let { patient ->
    PatientShareModal(
      patient = patient,
      centerProfile = centerProfile,
      onDismiss = { viewModel.closeSavedPatientShareModal() },
      onSendWhatsApp = { phone, msg ->
        viewModel.sendWhatsApp(context, phone, msg)
      },
      onSendSMS = { phone, msg ->
        viewModel.sendSMS(context, phone, msg)
      },
      onOpenThermalPrint = { p ->
        val lines = listOf(
          "بطاقة مريض - ملف طبي",
          "--------------------------------",
          "رقم الملف: ${p.patientCode}",
          "الاسم: ${p.fullName}",
          "الهاتف: ${p.phone}",
          "العنوان: ${p.address.ifEmpty { "المدينة" }}",
          "العمر: ${p.age} سنة | الجنس: ${p.gender}",
          "طوارئ: ${p.emergencyRelation} (${p.emergencyPhone})",
          "--------------------------------",
          "تاريخ التسجيل: 2026-09-20"
        )
        viewModel.openPrintDialog(
          PrintPayload(
            type = "THERMAL_RECEIPT",
            title = "بطاقة تسجيل مريض جديد",
            contentLines = lines,
            docNumber = p.patientCode,
            patientName = p.fullName
          )
        )
      },
      onOpenA4Print = { p ->
        val lines = listOf(
          "استمارة فتح ملف واستقبال حالة طبية",
          "رقم السجل الطبي الموحد: ${p.patientCode}",
          "الاسم الرباعي: ${p.fullName}",
          "رقم الهاتف المحمول: ${p.phone}",
          "العنوان ومحل الإقامة: ${p.address.ifEmpty { "غير محدد" }}",
          "الجنس: ${p.gender} | تاريخ الميلاد / العمر: ${p.birthDate} (${p.age} سنة)",
          "بيانات الاتصال في حالات الطوارئ: ${p.emergencyRelation} - ${p.emergencyPhone}",
          "القسم الطبي المحال إليه: عام",
          "الملاحظات والتحسس الدوائي: ${p.notes.ifEmpty { "لا يوجد" }}",
          "--------------------------------------------------",
          "توقيع المريض / ولي الأمر: ......................",
          "ختم وتوقيع موظف الاستقبال: ......................"
        )
        viewModel.openPrintDialog(
          PrintPayload(
            type = "A4_INVOICE",
            title = "استمارة فتح ملف طبي رسمي",
            contentLines = lines,
            docNumber = p.patientCode,
            patientName = p.fullName
          )
        )
      }
    )
  }

  // Print Preview Dialog (Thermal or A4)
  printPayload?.let { payload ->
    PrintPreviewDialog(
      payload = payload,
      centerProfile = centerProfile,
      onDismiss = { viewModel.closePrintDialog() }
    )
  }

  ModalNavigationDrawer(
    drawerState = drawerState,
    drawerContent = {
      ClinicDrawerContent(
        currentScreen = currentScreen,
        centerProfile = centerProfile,
        onNavigate = { screen ->
          viewModel.navigateTo(screen)
        },
        onCloseDrawer = {
          scope.launch { drawerState.close() }
        }
      )
    }
  ) {
    Scaffold(
      modifier = Modifier.fillMaxSize(),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        ClinicTopBar(
          currentScreen = currentScreen,
          centerProfile = centerProfile,
          onOpenDrawer = { scope.launch { drawerState.open() } },
          onQuickSearchClick = { viewModel.navigateTo(ClinicScreen.QUICK_SEARCH) },
          onSettingsClick = { viewModel.navigateTo(ClinicScreen.SETTINGS) },
          unreadNotifications = unreadNotifications,
          onNotificationsClick = { viewModel.navigateTo(ClinicScreen.NOTIFICATIONS) }
        )
      },
      bottomBar = {
        ClinicBottomBar(
          currentScreen = currentScreen,
          onNavigate = { screen -> viewModel.navigateTo(screen) }
        )
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
          when (screen) {
            ClinicScreen.QUICK_SEARCH -> QuickSearchScreen(
              viewModel = viewModel,
              onNavigate = { viewModel.navigateTo(it) },
              onOpenPatient = { pId -> viewModel.openPatientDetails(pId) }
            )
            ClinicScreen.NEW_PATIENT -> NewPatientScreen(
              viewModel = viewModel,
              onOpenThermalPrint = { p ->
                val lines = listOf(
                  "بطاقة مريض - ملف طبي",
                  "رقم الملف: ${p.patientCode}",
                  "الاسم: ${p.fullName}",
                  "الهاتف: ${p.phone}",
                  "العمر: ${p.age} سنة"
                )
                viewModel.openPrintDialog(
                  PrintPayload(
                    type = "THERMAL_RECEIPT",
                    title = "بطاقة تسجيل مريض",
                    contentLines = lines,
                    docNumber = p.patientCode
                  )
                )
              },
              onOpenA4Print = { p ->
                val lines = listOf(
                  "استمارة استقبال وتسجيل حالة جديدة",
                  "رقم الملف الطبي: ${p.patientCode}",
                  "اسم المريض: ${p.fullName}",
                  "الهاتف: ${p.phone} | العنوان: ${p.address}",
                  "العمر: ${p.age} سنة | الجنس: ${p.gender}"
                )
                viewModel.openPrintDialog(
                  PrintPayload(
                    type = "A4_INVOICE",
                    title = "استمارة فتح ملف طبي رسمي",
                    contentLines = lines,
                    docNumber = p.patientCode
                  )
                )
              }
            )
            ClinicScreen.APPOINTMENTS -> AppointmentsScreen(viewModel = viewModel)
            ClinicScreen.PACKAGES -> PackagesScreen(viewModel = viewModel)
            ClinicScreen.PATIENTS -> PatientsScreen(
              viewModel = viewModel,
              onNavigate = { viewModel.navigateTo(it) },
              onOpenPatient = { pId -> viewModel.openPatientDetails(pId) }
            )
            ClinicScreen.STAFF -> StaffScreen(viewModel = viewModel)
            ClinicScreen.MEDICAL_STAFF -> MedicalStaffScreen(viewModel = viewModel)
            ClinicScreen.REPORTS -> ReportsScreen(viewModel = viewModel)
            ClinicScreen.FINANCE -> FinanceScreen(viewModel = viewModel)
            ClinicScreen.DEPARTMENTS -> DepartmentsScreen(viewModel = viewModel)
            ClinicScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
            ClinicScreen.BACKUP -> BackupScreen(viewModel = viewModel)
            ClinicScreen.TEMPLATES -> TemplatesScreen(viewModel = viewModel)
            ClinicScreen.NOTIFICATIONS -> NotificationsScreen(viewModel = viewModel)
            ClinicScreen.SUPPORT -> SupportScreen(viewModel = viewModel)
            ClinicScreen.PATIENT_DETAILS -> PatientDetailsScreen(
              viewModel = viewModel,
              onBack = { viewModel.navigateTo(ClinicScreen.PATIENTS) }
            )
          }
        }
      }
    }
  }
}
