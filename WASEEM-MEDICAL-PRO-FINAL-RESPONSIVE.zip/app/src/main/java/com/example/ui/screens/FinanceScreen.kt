package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter
import com.example.ui.PrintPayload

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val transactions by viewModel.financeTransactions.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val generalStaff by viewModel.generalStaff.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var showNewVoucherDialog by remember { mutableStateOf(false) }
  var voucherType by remember { mutableStateOf("سند قبض") } // "سند قبض" or "سند صرف"

  // Financial Balances (Double entry summation)
  val totalReceipts = transactions.filter { it.docType == "سند قبض" }.sumOf { it.amount }
  val totalPayments = transactions.filter { it.docType == "سند صرف" }.sumOf { it.amount }
  val cashInHand = transactions.filter { it.paymentMethod == "نقداً" }
    .sumOf { if (it.docType == "سند قبض") it.amount else -it.amount }
  val bankBalance = transactions.filter { it.paymentMethod != "نقداً" }
    .sumOf { if (it.docType == "سند قبض") it.amount else -it.amount }

  // Dialog to issue new voucher
  if (showNewVoucherDialog) {
    NewVoucherDialog(
      initialType = voucherType,
      patients = patients,
      medicalStaff = medicalStaff,
      generalStaff = generalStaff,
      transactions = transactions,
      onDismiss = { showNewVoucherDialog = false },
      onSave = { docType, amt, method, payer, pId, dId, sId, debit, credit, notes ->
        viewModel.addFinanceTransaction(
          docType = docType,
          amount = amt,
          paymentMethod = method,
          payerOrBeneficiary = payer,
          patientId = pId,
          doctorId = dId,
          staffId = sId,
          debitAccount = debit,
          creditAccount = credit,
          notes = notes
        )
        showNewVoucherDialog = false
      }
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header & Quick Voucher Buttons
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "الإدارة المالية والمحاسبة",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "نظام القيد المزدوج، سندات القبض والصرف",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Button(
            onClick = {
              voucherType = "سند قبض"
              showNewVoucherDialog = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("سند قبض")
          }

          Button(
            onClick = {
              voucherType = "سند صرف"
              showNewVoucherDialog = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("سند صرف")
          }
        }
      }
    }

    // Cash and Bank Summary Cards
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("الصندوق النقدي (الكاش)", style = MaterialTheme.typography.labelSmall)
            Text(
              text = "$cashInHand ر.ي",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
              )
            )
          }
        }

        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
          modifier = Modifier.weight(1f)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text("الحسابات البنكية / شبكة", style = MaterialTheme.typography.labelSmall)
            Text(
              text = "$bankBalance ر.ي",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
              )
            )
          }
        }
      }
    }

    // Income vs Expense Summary
    item {
      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("إجمالي المقبوضات: $totalReceipts ر.ي", fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
            Text("إجمالي المصروفات: $totalPayments ر.ي", fontWeight = FontWeight.Bold, color = Color(0xFFDC2626))
          }
          Text(
            text = "الصافي: ${totalReceipts - totalPayments} ر.ي",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }
    }

    // Transactions list
    item {
      Text(
        text = "سجل المعاملات والسندات المالية الأخيرة (${transactions.size}):",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary
      )
    }

    items(transactions.reversed()) { tx ->
      val isReceipt = tx.docType == "سند قبض"
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                color = if (isReceipt) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = tx.docType,
                  color = if (isReceipt) Color(0xFF166534) else Color(0xFF991B1B),
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${tx.docNumber} - ${tx.payerOrBeneficiary}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
            }

            Text(
              text = "${tx.amount} ر.ي",
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                color = if (isReceipt) Color(0xFF166534) else Color(0xFF991B1B)
              )
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "البيان: ${tx.notes}",
            style = MaterialTheme.typography.bodySmall
          )

          Text(
            text = "مدين: ${tx.debitAccount} | دائن: ${tx.creditAccount}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline
          )

          Divider(modifier = Modifier.padding(vertical = 6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "📅 ${tx.date} | طريقة الدفع: ${tx.paymentMethod}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.outline
            )

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              // Thermal Print Receipt
              IconButton(
                onClick = {
                  val lines = listOf(
                    "رقم السند: ${tx.docNumber}",
                    "نوع المستند: ${tx.docType}",
                    "التاريخ: ${tx.date}",
                    "المستلم / المنصرف له: ${tx.payerOrBeneficiary}",
                    "المبلغ: ${tx.amount} ر.ي",
                    "طريقة الدفع: ${tx.paymentMethod}",
                    "البيان: ${tx.notes}",
                    "حساب المدين: ${tx.debitAccount}",
                    "حساب الدائن: ${tx.creditAccount}"
                  )
                  viewModel.openPrintDialog(
                    PrintPayload(
                      type = "THERMAL_RECEIPT",
                      title = tx.docType,
                      contentLines = lines,
                      docNumber = tx.docNumber,
                      totalAmount = tx.amount,
                      date = tx.date
                    )
                  )
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Print, contentDescription = "طباعة حرارية", modifier = Modifier.size(18.dp))
              }

              // A4 Print Voucher
              IconButton(
                onClick = {
                  val lines = listOf(
                    "رقم المستند المالي: ${tx.docNumber}",
                    "نوع القيد: ${tx.docType}",
                    "التاريخ والوقت: ${tx.date}",
                    "المستفيد / الدافع: ${tx.payerOrBeneficiary}",
                    "المبلغ الإجمالي: ${tx.amount} ريال يمني",
                    "طريقة التحصيل: ${tx.paymentMethod}",
                    "شرح القيد المحاسبي: ${tx.notes}",
                    "الطرف المدين (Debit): ${tx.debitAccount}",
                    "الطرف الدائن (Credit): ${tx.creditAccount}",
                    "المحاسب المسؤول: الإدارة المالية"
                  )
                  viewModel.openPrintDialog(
                    PrintPayload(
                      type = "A4_INVOICE",
                      title = "سند قيد محاسبي رسمي (${tx.docType})",
                      contentLines = lines,
                      docNumber = tx.docNumber,
                      totalAmount = tx.amount,
                      date = tx.date
                    )
                  )
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Description, contentDescription = "طباعة رسمية A4", modifier = Modifier.size(18.dp))
              }

              // WhatsApp Share
              IconButton(
                onClick = {
                  val msg = "إشعار مالي من ${centerProfile?.facilityName}:\nسند رقم: ${tx.docNumber} (${tx.docType})\nالمبلغ: ${tx.amount} ر.ي\nالمستفيد: ${tx.payerOrBeneficiary}\nالبيان: ${tx.notes}\nشكراً لتعاملكم معنا.\nتطوير: وسيم الفرح | هاتف: 774486588"
                  viewModel.sendWhatsApp(context, centerProfile?.phone1 ?: "774486588", msg)
                },
                modifier = Modifier.size(32.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = Color(0xFF25D366), modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

/**
 * Voucher Dialog (Receipt or Payment)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewVoucherDialog(
  initialType: String,
  patients: List<Patient>,
  medicalStaff: List<MedicalStaff>,
  generalStaff: List<GeneralStaff>,
  transactions: List<FinanceTransaction>,
  onDismiss: () -> Unit,
  onSave: (String, Double, String, String, Long?, Long?, Long?, String, String, String) -> Unit
) {
  var docType by remember { mutableStateOf(initialType) }
  var amountText by remember { mutableStateOf("") }
  var paymentMethod by remember { mutableStateOf("نقداً") }
  var beneficiary by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }
  var selectedPatientId by remember { mutableStateOf<Long?>(null) }
  var selectedDoctorId by remember { mutableStateOf<Long?>(null) }
  var selectedStaffId by remember { mutableStateOf<Long?>(null) }
  var expanded by remember { mutableStateOf(false) }

  val patientMatches = remember(beneficiary, patients) {
    val q = beneficiary.trim()
    (if (q.isBlank()) patients else patients.filter {
      it.fullName.startsWith(q, true) || it.phone.contains(q) || it.patientCode.contains(q, true)
    }).take(12)
  }
  val doctorMatches = remember(beneficiary, medicalStaff) {
    val q = beneficiary.trim()
    (if (q.isBlank()) medicalStaff else medicalStaff.filter {
      it.name.startsWith(q, true) || it.phone.contains(q) || it.specialty.contains(q, true)
    }).take(12)
  }
  val staffMatches = remember(beneficiary, generalStaff) {
    val q = beneficiary.trim()
    (if (q.isBlank()) generalStaff else generalStaff.filter {
      it.fullName.startsWith(q, true) || it.phone.contains(q) || it.jobTitle.contains(q, true)
    }).take(12)
  }

  Dialog(onDismissRequest = onDismiss) {
    Surface(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)) {
      Column(
        Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text("إصدار مستند مالي جديد", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
        Text("البحث مرتبط بقاعدة البيانات: اكتب «أ» أو «أحمد» وستظهر الأسماء المطابقة فوراً.",
          style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(selected = docType == "سند قبض", onClick = {
            docType = "سند قبض"; selectedDoctorId = null; selectedStaffId = null
          }, label = { Text("سند قبض") })
          FilterChip(selected = docType == "سند صرف", onClick = {
            docType = "سند صرف"; selectedPatientId = null
          }, label = { Text("سند صرف") })
        }

        OutlinedTextField(
          value = amountText, onValueChange = { amountText = it },
          label = { Text("المبلغ (ر.ي) *") }, modifier = Modifier.fillMaxWidth(), singleLine = true
        )

        Text("طريقة الدفع:", style = MaterialTheme.typography.labelSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("نقداً", "شبكة / بنك", "حوالة").forEach { m ->
            FilterChip(selected = paymentMethod == m, onClick = { paymentMethod = m }, label = { Text(m) })
          }
        }

        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
          OutlinedTextField(
            value = beneficiary,
            onValueChange = {
              beneficiary = it
              expanded = true
              selectedPatientId = null; selectedDoctorId = null; selectedStaffId = null
            },
            label = { Text(if (docType == "سند قبض") "المريض / العميل — بحث ذكي" else "الطبيب / الموظف / العامل — بحث ذكي") },
            placeholder = { Text("مثال: أحمد") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth(), singleLine = true
          )
          ExposedDropdownMenu(
            expanded = expanded && (if (docType == "سند قبض") patientMatches.isNotEmpty() else doctorMatches.isNotEmpty() || staffMatches.isNotEmpty()),
            onDismissRequest = { expanded = false }
          ) {
            if (docType == "سند قبض") {
              patientMatches.forEach { p ->
                DropdownMenuItem(
                  text = { Column { Text(p.fullName, fontWeight = FontWeight.Bold); Text("${p.patientCode} • ${p.phone}", style = MaterialTheme.typography.labelSmall) } },
                  onClick = { beneficiary = p.fullName; selectedPatientId = p.id; expanded = false }
                )
              }
            } else {
              doctorMatches.forEach { d ->
                DropdownMenuItem(
                  text = { Column { Text(d.name, fontWeight = FontWeight.Bold); Text("طبيب/أخصائي • ${d.specialty}", style = MaterialTheme.typography.labelSmall) } },
                  onClick = { beneficiary = d.name; selectedDoctorId = d.id; selectedStaffId = null; expanded = false }
                )
              }
              staffMatches.forEach { st ->
                DropdownMenuItem(
                  text = { Column { Text(st.fullName, fontWeight = FontWeight.Bold); Text("${st.jobTitle} • ${st.phone}", style = MaterialTheme.typography.labelSmall) } },
                  onClick = { beneficiary = st.fullName; selectedStaffId = st.id; selectedDoctorId = null; expanded = false }
                )
              }
            }
          }
        }

        val linked = remember(selectedPatientId, selectedDoctorId, selectedStaffId, transactions) {
          transactions.filter {
            (selectedPatientId != null && it.patientId == selectedPatientId) ||
                (selectedDoctorId != null && it.doctorId == selectedDoctorId) ||
                (selectedStaffId != null && it.staffId == selectedStaffId)
          }
        }
        if (linked.isNotEmpty()) {
          val debit = linked.filter { it.debitAccount.contains(beneficiary, true) }.sumOf { it.amount }
          val credit = linked.filter { it.creditAccount.contains(beneficiary, true) }.sumOf { it.amount }
          Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp)) {
              Text("بطاقة الحساب المرتبط", fontWeight = FontWeight.Bold)
              Text("الحركات: ${linked.size}")
              Text("مدين: $debit ر.ي • دائن: $credit ر.ي")
            }
          }
        }

        if (docType == "سند صرف") {
          Text("يمكن كتابة اسم مورد غير مسجل، بينما الأطباء والموظفون المسجلون يظهرون تلقائياً ويرتبط الصرف بحسابهم.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        OutlinedTextField(
          value = notes, onValueChange = { notes = it },
          label = { Text("البيان وشرح المعاملة *") },
          modifier = Modifier.fillMaxWidth(), minLines = 2
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              val amt = amountText.toDoubleOrNull() ?: 0.0
              if (amt <= 0 || beneficiary.isBlank()) return@Button
              val cashOrBank = if (paymentMethod == "نقداً") "الصندوق الرئيسي (نقدية)" else "البنك / شبكة التحصيل"
              val debitAcc: String
              val creditAcc: String
              if (docType == "سند قبض") {
                debitAcc = cashOrBank
                creditAcc = if (selectedPatientId != null) "حساب المريض: ${beneficiary.trim()}" else "إيرادات خدمات المركز والعيادة"
              } else {
                debitAcc = when {
                  selectedDoctorId != null -> "مستحقات الطبيب: ${beneficiary.trim()}"
                  selectedStaffId != null -> "مستحقات الموظف: ${beneficiary.trim()}"
                  else -> "مصروفات تشغيلية وعلاجية"
                }
                creditAcc = cashOrBank
              }
              onSave(
                docType, amt, paymentMethod, beneficiary.trim(),
                selectedPatientId, selectedDoctorId, selectedStaffId,
                debitAcc, creditAcc, notes.trim().ifBlank { "معاملة مالية" }
              )
            },
            Modifier.weight(1f)
          ) { Text("حفظ القيد المتوازن") }
          OutlinedButton(onClick = onDismiss, Modifier.weight(1f)) { Text("إلغاء") }
        }
      }
    }
  }
}

