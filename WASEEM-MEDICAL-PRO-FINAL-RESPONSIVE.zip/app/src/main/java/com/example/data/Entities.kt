package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "center_profile")
data class CenterProfile(
  @PrimaryKey val id: Int = 1,
  val facilityName: String = "مركز الشفاء الطبي التخصصي",
  val facilityType: String = "مركز طبي", // عيادة أو مركز طبي
  val address: String = "الشارع العام - بجوار مجمع النخبة",
  val phone1: String = "774486588",
  val phone2: String = "01-445566",
  val doctorInCharge: String = "د. وسيم الفرح",
  val commercialRecord: String = "CR-998821",
  val headerNotes: String = "رعاية طبية متميزة بأحدث التقنيات وأفضل الكوادر",
  val footerNotes: String = "تطوير: وسيم الفرح | هاتف: 774486588",
  val isConfigured: Boolean = true
)

@Entity(tableName = "departments")
data class Department(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val iconName: String = "local_hospital",
  val isActive: Boolean = true,
  val sortOrder: Int = 0
)

@Entity(tableName = "medical_services")
data class MedicalService(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val departmentId: Long,
  val name: String,
  val defaultPrice: Double,
  val doctorSharePercent: Double = 30.0,
  val doctorShareFixed: Double = 0.0,
  val isActive: Boolean = true
)

@Entity(tableName = "medical_staff")
data class MedicalStaff(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val role: String, // طبيب أخصائي، طبيب استشاري، مقيم، ممرض، فني مختبر، فني أشعة
  val specialty: String,
  val departmentId: Long,
  val phone: String,
  val qualification: String,
  val contractType: String = "نسبة", // "نسبة", "راتب شهري", "مبلغ مقطوع"
  val sharePercent: Double = 35.0,
  val fixedRate: Double = 0.0,
  val monthlySalary: Double = 0.0,
  val balanceDues: Double = 0.0,
  val isActive: Boolean = true
)

@Entity(tableName = "general_staff")
data class GeneralStaff(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val fullName: String,
  val jobTitle: String, // موظف استقبال، محاسب، مسؤول مخزن، مشرف، خدمة عملاء
  val department: String,
  val phone: String,
  val nationalId: String,
  val address: String,
  val hireDate: String,
  val monthlySalary: Double,
  val advances: Double = 0.0,
  val deductions: Double = 0.0,
  val bonuses: Double = 0.0,
  val status: String = "نشط" // نشط، موقوف
)

@Entity(tableName = "patients")
data class Patient(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val patientCode: String, // e.g. P-1001
  val fullName: String,
  val phone: String,
  val address: String,
  val gender: String, // ذكر / أنثى
  val birthDate: String,
  val age: Int,
  val emergencyRelation: String = "",
  val emergencyPhone: String = "",
  val departmentId: Long = 0,
  val serviceId: Long = 0,
  val doctorId: Long = 0,
  val notes: String = "",
  val balance: Double = 0.0,
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "appointments")
data class Appointment(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val appointmentCode: String, // e.g. APT-201
  val patientId: Long,
  val patientName: String,
  val patientPhone: String,
  val departmentId: Long,
  val departmentName: String,
  val serviceId: Long,
  val serviceName: String,
  val doctorId: Long,
  val doctorName: String,
  val appointmentDate: String, // YYYY-MM-DD
  val startTime: String, // HH:mm
  val endTime: String, // HH:mm
  val status: String = "في الانتظار", // في الانتظار، تم الحضور، مؤكد، لم يحضر، ملغي، مكتمل
  val notes: String = "",
  val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "package_definitions")
data class PackageDefinition(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val name: String,
  val departmentId: Long,
  val departmentName: String,
  val totalSessions: Int,
  val price: Double,
  val validityDays: Int = 60,
  val isActive: Boolean = true
)

@Entity(tableName = "patient_packages")
data class PatientPackage(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val patientId: Long,
  val packageDefId: Long,
  val packageName: String,
  val totalSessions: Int,
  val usedSessions: Int = 0,
  val remainingSessions: Int,
  val purchaseDate: String,
  val expiryDate: String,
  val price: Double,
  val status: String = "نشطة" // نشطة، منتهية، ملغاة
)

@Entity(tableName = "patient_timeline")
data class PatientTimeline(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val patientId: Long,
  val visitDate: String,
  val doctorName: String,
  val serviceName: String,
  val diagnosis: String,
  val prescription: String,
  val attachmentTitle: String = "",
  val attachmentType: String = "", // أشعة، تقرير مختبر، وثيقة
  val notes: String = "",
  val sessionTransactionId: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "finance_transactions")
data class FinanceTransaction(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val docNumber: String, // REC-101, PAY-101, INV-101
  val docType: String, // "سند قبض", "سند صرف", "فاتورة خدمة", "صرف راتب"
  val date: String,
  val amount: Double,
  val paymentMethod: String = "نقداً", // "نقداً", "شبكة / بنك"
  val payerOrBeneficiary: String,
  val patientId: Long? = null,
  val doctorId: Long? = null,
  val staffId: Long? = null,
  val debitAccount: String,
  val creditAccount: String,
  val notes: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "message_templates")
data class MessageTemplate(
  @PrimaryKey val key: String, // welcome, appointment_reminder, package_alert, invoice
  val title: String,
  val templateBody: String
)

@Entity(tableName = "app_notifications")
data class AppNotification(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val title: String,
  val message: String,
  val type: String = "عام",
  val patientId: Long? = null,
  val isRead: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)
