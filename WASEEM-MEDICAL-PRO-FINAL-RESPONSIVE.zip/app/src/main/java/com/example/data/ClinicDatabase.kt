package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    CenterProfile::class,
    Department::class,
    MedicalService::class,
    MedicalStaff::class,
    GeneralStaff::class,
    Patient::class,
    Appointment::class,
    PackageDefinition::class,
    PatientPackage::class,
    PatientTimeline::class,
    FinanceTransaction::class,
    MessageTemplate::class,
    AppNotification::class
  ],
  version = 2,
  exportSchema = false
)
abstract class ClinicDatabase : RoomDatabase() {
  abstract fun clinicDao(): ClinicDao

  companion object {
    @Volatile
    private var INSTANCE: ClinicDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): ClinicDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          ClinicDatabase::class.java,
          "waseem_clinic_database.db"
        )
          .addMigrations(MIGRATION_1_2)
          .addCallback(ClinicDatabaseCallback(scope))
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }

    private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
      override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
          CREATE TABLE IF NOT EXISTS app_notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            type TEXT NOT NULL,
            patientId INTEGER,
            isRead INTEGER NOT NULL,
            createdAt INTEGER NOT NULL
          )
        """.trimIndent())
      }
    }

    private class ClinicDatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database.clinicDao())
          }
        }
      }
    }

    private suspend fun populateInitialData(dao: ClinicDao) {
      // Center Profile
      dao.saveCenterProfile(
        CenterProfile(
          id = 1,
          facilityName = "مجمع الشفاء الطبي التخصصي",
          facilityType = "مركز طبي",
          address = "الشارع العام - برج الأمل الطبي",
          phone1 = "774486588",
          phone2 = "01-445566",
          doctorInCharge = "د. وسيم الفرح",
          commercialRecord = "CR-2024-8891",
          headerNotes = "أحدث الأجهزة التشخيصية والعلاجية ونخبة من الأطباء الاستشاريين",
          footerNotes = "تطوير: وسيم الفرح | هاتف: 774486588",
          isConfigured = true
        )
      )

      // Departments
      val dentalId = dao.insertDepartment(Department(name = "قسم الأسنان وجراحة الفم", iconName = "dental", sortOrder = 1))
      val physioId = dao.insertDepartment(Department(name = "قسم العلاج الطبيعي والتأهيل", iconName = "physio", sortOrder = 2))
      val dermaId = dao.insertDepartment(Department(name = "قسم الجلدية والتجميل والليزر", iconName = "derma", sortOrder = 3))
      val eyeId = dao.insertDepartment(Department(name = "قسم العيون والبصريات", iconName = "eye", sortOrder = 4))
      val pediaId = dao.insertDepartment(Department(name = "قسم طب الأطفال", iconName = "pedia", sortOrder = 5))
      val internalId = dao.insertDepartment(Department(name = "قسم الباطنية والقلب", iconName = "internal", sortOrder = 6))
      val labId = dao.insertDepartment(Department(name = "قسم المختبر والتحاليل الطبية", iconName = "lab", sortOrder = 7))

      // Medical Services
      dao.insertService(MedicalService(departmentId = dentalId, name = "كشفية واستشارة أسنان", defaultPrice = 3000.0, doctorSharePercent = 50.0))
      dao.insertService(MedicalService(departmentId = dentalId, name = "تنظيف وتلميع أسنان شامل", defaultPrice = 12000.0, doctorSharePercent = 35.0))
      dao.insertService(MedicalService(departmentId = dentalId, name = "حشو تجميلي ليزري", defaultPrice = 18000.0, doctorSharePercent = 40.0))
      dao.insertService(MedicalService(departmentId = dentalId, name = "علاج عصب وسحب جذور", defaultPrice = 25000.0, doctorSharePercent = 40.0))

      dao.insertService(MedicalService(departmentId = physioId, name = "جلسة علاج طبيعي ظهر وفقرات", defaultPrice = 10000.0, doctorSharePercent = 30.0))
      dao.insertService(MedicalService(departmentId = physioId, name = "جلسة تأهيل وإعادة حركة", defaultPrice = 8000.0, doctorSharePercent = 30.0))
      dao.insertService(MedicalService(departmentId = physioId, name = "جلسة ليزر علاجي وأمواج تصادمية", defaultPrice = 15000.0, doctorSharePercent = 35.0))

      dao.insertService(MedicalService(departmentId = dermaId, name = "جلسة ليزر كربوني ونضارة", defaultPrice = 20000.0, doctorSharePercent = 35.0))
      dao.insertService(MedicalService(departmentId = dermaId, name = "جلسة تنظيف بشرة هيدرافيشل", defaultPrice = 15000.0, doctorSharePercent = 30.0))

      dao.insertService(MedicalService(departmentId = eyeId, name = "فحص النظر وقاع العين", defaultPrice = 7000.0, doctorSharePercent = 40.0))
      dao.insertService(MedicalService(departmentId = pediaId, name = "معاينة ومتابعة نمو أطفال", defaultPrice = 5000.0, doctorSharePercent = 50.0))
      dao.insertService(MedicalService(departmentId = internalId, name = "كشف باطنية مع تخطيط قلب ECG", defaultPrice = 9000.0, doctorSharePercent = 45.0))
      dao.insertService(MedicalService(departmentId = labId, name = "باقة تحاليل شاملة CBC + Lipid + Sugar", defaultPrice = 18000.0, doctorSharePercent = 20.0))

      // Medical Staff (Doctors & Specialists)
      val doc1 = dao.insertMedicalStaff(
        MedicalStaff(
          name = "د. وسيم الفرح",
          role = "طبيب استشاري",
          specialty = "جراحة وتجميل الأسنان",
          departmentId = dentalId,
          phone = "774486588",
          qualification = "بورد في جراحة وزراعة الأسنان",
          contractType = "نسبة",
          sharePercent = 40.0,
          balanceDues = 48000.0
        )
      )
      val doc2 = dao.insertMedicalStaff(
        MedicalStaff(
          name = "د. أحمد المنصوري",
          role = "طبيب أخصائي",
          specialty = "العلاج الطبيعي والتأهيل الحركي",
          departmentId = physioId,
          phone = "771234567",
          qualification = "ماجستير تأهيل عصبي وحركي",
          contractType = "نسبة",
          sharePercent = 35.0,
          balanceDues = 28000.0
        )
      )
      val doc3 = dao.insertMedicalStaff(
        MedicalStaff(
          name = "د. سارة الكندي",
          role = "طبيبة أخصائية",
          specialty = "الجلدية والتجميل والعلاج بالليزر",
          departmentId = dermaId,
          phone = "772345678",
          qualification = "زمالة الأمراض الجلدية والليزر",
          contractType = "نسبة",
          sharePercent = 35.0,
          balanceDues = 35000.0
        )
      )
      dao.insertMedicalStaff(
        MedicalStaff(
          name = "مروة العولقي",
          role = "ممرضة رئيسية",
          specialty = "تمريض عام ورعاية سريرية",
          departmentId = dentalId,
          phone = "773456789",
          qualification = "بكالوريوس علوم تمريض",
          contractType = "راتب شهري",
          monthlySalary = 180000.0,
          balanceDues = 0.0
        )
      )

      // General Staff
      dao.insertGeneralStaff(
        GeneralStaff(
          fullName = "ماجد القدسي",
          jobTitle = "موظف استقبال واستعلامات",
          department = "الاستقبال",
          phone = "770112233",
          nationalId = "109823441",
          address = "صنعاء - التحرير",
          hireDate = "2023-01-15",
          monthlySalary = 120000.0
        )
      )
      dao.insertGeneralStaff(
        GeneralStaff(
          fullName = "فاطمة الزهراء البعداني",
          jobTitle = "محاسب مالي رئيسي",
          department = "الإدارة والمالية",
          phone = "770223344",
          nationalId = "109832115",
          address = "صنعاء - حدة",
          hireDate = "2023-03-01",
          monthlySalary = 160000.0
        )
      )

      // Package Definitions
      val pkgDef1 = dao.insertPackageDefinition(
        PackageDefinition(
          name = "باقة علاج طبيعي مكثفة (10 جلسات)",
          departmentId = physioId,
          departmentName = "قسم العلاج الطبيعي والتأهيل",
          totalSessions = 10,
          price = 80000.0,
          validityDays = 60
        )
      )
      val pkgDef2 = dao.insertPackageDefinition(
        PackageDefinition(
          name = "باقة تجميل ونضارة البشرة (4 جلسات)",
          departmentId = dermaId,
          departmentName = "قسم الجلدية والتجميل والليزر",
          totalSessions = 4,
          price = 65000.0,
          validityDays = 90
        )
      )

      // Initial Patients
      val p1 = dao.insertPatient(
        Patient(
          patientCode = "P-1001",
          fullName = "محمد عبدالله الحميري",
          phone = "777123987",
          address = "حدة - شارع بيروت",
          gender = "ذكر",
          birthDate = "1988-05-14",
          age = 36,
          emergencyRelation = "أخ - علي",
          emergencyPhone = "777987654",
          departmentId = dentalId,
          notes = "يعاني من تحسس البنسلين"
        )
      )
      val p2 = dao.insertPatient(
        Patient(
          patientCode = "P-1002",
          fullName = "أميرة خالد السقاف",
          phone = "775667788",
          address = "شارع عمان",
          gender = "أنثى",
          birthDate = "1994-11-20",
          age = 30,
          emergencyRelation = "زوج - ياسر",
          emergencyPhone = "775990011",
          departmentId = physioId,
          notes = "إصابة انزلاق غضروفي قطني L4-L5"
        )
      )
      val p3 = dao.insertPatient(
        Patient(
          patientCode = "P-1003",
          fullName = "عمر صالح اليافعي",
          phone = "773322110",
          address = "حي الأصبحي",
          gender = "ذكر",
          birthDate = "1975-02-10",
          age = 49,
          emergencyRelation = "ابن - أسامة",
          emergencyPhone = "773344556",
          departmentId = dentalId,
          notes = "مريض سكري وضغط"
        )
      )

      // Initial Patient Package for P2
      dao.insertPatientPackage(
        PatientPackage(
          patientId = p2,
          packageDefId = pkgDef1,
          packageName = "باقة علاج طبيعي مكثفة (10 جلسات)",
          totalSessions = 10,
          usedSessions = 9,
          remainingSessions = 1, // Alert condition: 1 session remaining!
          purchaseDate = "2026-08-15",
          expiryDate = "2026-10-15",
          price = 80000.0,
          status = "نشطة"
        )
      )

      // Initial Appointments
      dao.insertAppointment(
        Appointment(
          appointmentCode = "APT-101",
          patientId = p1,
          patientName = "محمد عبدالله الحميري",
          patientPhone = "777123987",
          departmentId = dentalId,
          departmentName = "قسم الأسنان وجراحة الفم",
          serviceId = 2,
          serviceName = "تنظيف وتلميع أسنان شامل",
          doctorId = doc1,
          doctorName = "د. وسيم الفرح",
          appointmentDate = "2026-09-20",
          startTime = "10:00",
          endTime = "10:30",
          status = "تم الحضور",
          notes = "جلسة تنظيف وتلميع دورية"
        )
      )
      dao.insertAppointment(
        Appointment(
          appointmentCode = "APT-102",
          patientId = p2,
          patientName = "أميرة خالد السقاف",
          patientPhone = "775667788",
          departmentId = physioId,
          departmentName = "قسم العلاج الطبيعي والتأهيل",
          serviceId = 5,
          serviceName = "جلسة علاج طبيعي ظهر وفقرات",
          doctorId = doc2,
          doctorName = "د. أحمد المنصوري",
          appointmentDate = "2026-09-20",
          startTime = "11:00",
          endTime = "11:45",
          status = "في الانتظار",
          notes = "جلسة الباقة رقم 10"
        )
      )
      dao.insertAppointment(
        Appointment(
          appointmentCode = "APT-103",
          patientId = p3,
          patientName = "عمر صالح اليافعي",
          patientPhone = "773322110",
          departmentId = dentalId,
          departmentName = "قسم الأسنان وجراحة الفم",
          serviceId = 3,
          serviceName = "حشو تجميلي ليزري",
          doctorId = doc1,
          doctorName = "د. وسيم الفرح",
          appointmentDate = "2026-09-21",
          startTime = "16:00",
          endTime = "16:45",
          status = "مؤكد",
          notes = "الضرس العلوي الأيمن"
        )
      )

      // Initial Timeline
      dao.insertTimeline(
        PatientTimeline(
          patientId = p1,
          visitDate = "2026-08-10",
          doctorName = "د. وسيم الفرح",
          serviceName = "كشفية واستشارة أسنان",
          diagnosis = "التهاب لثة خفيف مع ترسبات جيرية",
          prescription = "غسول فم كلورهيكسيدين + مسكن بروفين 400",
          attachmentTitle = "بانوراما أسنان رقمية",
          attachmentType = "أشعة",
          notes = "تحتاج لتنظيف جير كامل في الزيارة القادمة"
        )
      )

      // Initial Finance Transactions (Double Entry Bookkeeping records)
      dao.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = "REC-1001",
          docType = "سند قبض",
          date = "2026-09-20",
          amount = 12000.0,
          paymentMethod = "نقداً",
          payerOrBeneficiary = "محمد عبدالله الحميري",
          patientId = p1,
          debitAccount = "الصندوق الرئيسي (نقدية)",
          creditAccount = "إيرادات خدمات الأسنان",
          notes = "رسوم تنظيف وتلميع أسنان"
        )
      )
      dao.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = "REC-1002",
          docType = "سند قبض",
          date = "2026-08-15",
          amount = 80000.0,
          paymentMethod = "شبكة / بنك",
          payerOrBeneficiary = "أميرة خالد السقاف",
          patientId = p2,
          debitAccount = "حساب بنك الكريمي",
          creditAccount = "إيرادات باقات العلاج الطبيعي",
          notes = "قيمة باقة علاج طبيعي 10 جلسات"
        )
      )
      dao.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = "PAY-1001",
          docType = "سند صرف",
          date = "2026-09-18",
          amount = 25000.0,
          paymentMethod = "نقداً",
          payerOrBeneficiary = "مؤسسة التجهيزات الطبية",
          debitAccount = "مصروفات مستلزمات طبية ومعقمات",
          creditAccount = "الصندوق الرئيسي (نقدية)",
          notes = "شراء كمامات ومطهرات وقفازات طبية"
        )
      )

      // Message Templates
      dao.insertTemplate(
        MessageTemplate(
          key = "welcome",
          title = "رسالة الترحيب وفتح الملف",
          templateBody = "مرحباً بكم أخي الكريم / أختي الفاضلة في {CENTER_NAME} 🏥.\nيسعدنا انضمامكم إلينا ونتشرف بخدمتكم دائماً.\nتم تسجيل ملفكم الطبي بنجاح برقم: {PATIENT_ID}.\nنتمنى لكم دوام الصحة والعافية.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "appointment_reminder",
          title = "تذكير بموعد الحضور",
          templateBody = "مرحباً {PATIENT_NAME} 🌸،\nنود تذكيركم بموعدكم القادم في {CENTER_NAME}:\n📅 التاريخ: {DATE}\n⏰ الوقت: {TIME}\n👨‍⚕️ الطبيب: {DOCTOR_NAME}\n🩺 الخدمة: {SERVICE_NAME}\nيرجى التكرم بالحضور قبل الموعد بـ 10 دقائق.\nللتواصل: {PHONE}\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "package_alert",
          title = "تنبيه رصيد الباقة العلاجية",
          templateBody = "عزيزنا المريض {PATIENT_NAME} 🩺،\nنود إحاطتكم بأن باقتكم العلاجية لدى {CENTER_NAME} ({PACKAGE_NAME}) أوشكت على الانتهاء.\nالجلسات المتبقية: {REMAINING} جلسة فقط.\nتاريخ الصلاحية: {EXPIRY_DATE}.\nيرجى مراجعة الاستقبال لتجديد الباقة أو تنظيم الجلسات القادمة.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "receipt",
          title = "إيصال سند قبض مالي",
          templateBody = "إيصال سداد - {CENTER_NAME}\nرقم السند: {DOC_NUM}\nالمريض: {PATIENT_NAME}\nالمبلغ المستلم: {AMOUNT}\nطريقة الدفع: {PAY_METHOD}\nالبيان: {NOTES}\nشكراً لزيارتكم ودمتم بصحة وعافية.\n{DEVELOPER_TAG}"
        )
      )
    }
  }
}
