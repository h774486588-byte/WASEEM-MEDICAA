package com.example.security

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

object BackupScheduler {
  private const val WORK_NAME = "waseem_medical_daily_backup"

  fun scheduleDaily(context: Context, hour: Int, minute: Int) {
    val now = Calendar.getInstance()
    val next = Calendar.getInstance().apply {
      set(Calendar.HOUR_OF_DAY, hour)
      set(Calendar.MINUTE, minute)
      set(Calendar.SECOND, 0)
      set(Calendar.MILLISECOND, 0)
      if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
    }
    val delay = (next.timeInMillis - now.timeInMillis).coerceAtLeast(0L)

    val request = PeriodicWorkRequestBuilder<LocalBackupWorker>(24, TimeUnit.HOURS)
      .setInitialDelay(delay, TimeUnit.MILLISECONDS)
      .build()

    WorkManager.getInstance(context).enqueueUniquePeriodicWork(
      WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request
    )

    context.getSharedPreferences("waseem_backup", Context.MODE_PRIVATE).edit()
      .putBoolean("enabled", true).putInt("hour", hour).putInt("minute", minute).apply()
  }

  fun cancel(context: Context) {
    WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    context.getSharedPreferences("waseem_backup", Context.MODE_PRIVATE).edit()
      .putBoolean("enabled", false).apply()
  }
}
