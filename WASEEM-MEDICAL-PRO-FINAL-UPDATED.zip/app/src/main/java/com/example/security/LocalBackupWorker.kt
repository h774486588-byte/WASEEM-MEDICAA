package com.example.security

import android.net.Uri
import android.provider.DocumentsContract
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class LocalBackupWorker(
  appContext: android.content.Context,
  workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
  override suspend fun doWork(): Result {
    return try {
      val db = applicationContext.getDatabasePath("waseem_clinic_database.db")
      if (!db.exists()) return Result.failure()

      val backupDir = File(applicationContext.filesDir, "backups").apply { mkdirs() }
      val zipFile = File(backupDir, "waseem-medical-${System.currentTimeMillis()}.zip")
      ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
        FileInputStream(db).use { input ->
          zos.putNextEntry(ZipEntry(db.name))
          input.copyTo(zos)
          zos.closeEntry()
        }
      }

      val prefs = applicationContext.getSharedPreferences("waseem_backup", android.content.Context.MODE_PRIVATE)
      prefs.getString("tree_uri", null)?.let { raw ->
        try {
          val target = DocumentsContract.createDocument(
            applicationContext.contentResolver,
            Uri.parse(raw),
            "application/zip",
            zipFile.name
          )
          if (target != null) {
            applicationContext.contentResolver.openOutputStream(target)?.use { output ->
              FileInputStream(zipFile).use { input -> input.copyTo(output) }
            }
          }
        } catch (_: Exception) {
          // Keep the local copy if the selected provider is temporarily unavailable.
        }
      }
      Result.success()
    } catch (_: Exception) {
      Result.retry()
    }
  }
}
