package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.ui.ClinicScreen
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
  viewModel: ClinicViewModel,
  onNavigate: (ClinicScreen) -> Unit
) {
  val patients by viewModel.patients.collectAsState()
  val appointments by viewModel.appointments.collectAsState()
  val sessions by viewModel.clinicalSessions.collectAsState()
  val packages by viewModel.patientPackages.collectAsState()
  val transactions by viewModel.financeTransactions.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val profile by viewModel.centerProfile.collectAsState()

  val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

  // Metrics calculations
  val totalPatients = patients.size
  val todayAppointments = appointments.count { it.appointmentDate == today }
  val todaySessions = sessions.count { it.sessionDate == today }
  val activePackagesCount = packages.count { it.status == "نشطة" }

  val validTx = transactions.filter { !it.isVoided }
  val todayRevenues = validTx.filter { it.docType == "سند قبض" && it.date == today }.sumOf { it.amount }
  val duesAmount = medicalStaff.sumOf { it.balanceDues }
  val currency = profile?.currencySymbol ?: "ر.ي"

  val latestPatients = patients.takeLast(3).reversed()
  val todayApptList = appointments.filter { it.appointmentDate == today }.take(3)

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(MedicalBackground)
      .padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // 1. Hero Banner matching WASEEM MEDICAL PRO
    item {
      WaseemHeroBanner(
        onCtaClick = { onNavigate(ClinicScreen.QUICK_SEARCH) }
      )
    }

    // 2. 8 KPI Metrics Cards (2 Rows of 4 Cards)
    item {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Row 1 of KPI cards
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          WaseemKpiMiniCard(
            title = "المستحقات",
            value = viewModel.formatMoney(duesAmount),
            subUnit = currency,
            icon = Icons.Default.AccountBalanceWallet,
            cardBg = KpiBlueBg,
            iconTint = KpiBlueIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.FINANCE) }
          )

          WaseemKpiMiniCard(
            title = "الإيرادات اليوم",
            value = viewModel.formatMoney(todayRevenues),
            subUnit = currency,
            icon = Icons.Default.Receipt,
            cardBg = KpiGreenBg,
            iconTint = KpiGreenIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.FINANCE) }
          )

          WaseemKpiMiniCard(
            title = "الجلسات اليوم",
            value = "$todaySessions",
            icon = Icons.Default.EventNote,
            cardBg = KpiPurpleBg,
            iconTint = KpiPurpleIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.SESSIONS) }
          )

          WaseemKpiMiniCard(
            title = "المواعيد اليوم",
            value = "$todayAppointments",
            icon = Icons.Default.Groups,
            cardBg = KpiPinkBg,
            iconTint = KpiPinkIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.APPOINTMENTS) }
          )
        }

        // Row 2 of KPI cards
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          WaseemKpiMiniCard(
            title = "إجمالي المرضى",
            value = "$totalPatients",
            icon = Icons.Default.People,
            cardBg = KpiBlueBg,
            iconTint = KpiBlueIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.PATIENTS) }
          )

          WaseemKpiMiniCard(
            title = "الأطباء والمعالجون",
            value = "${medicalStaff.size}",
            icon = Icons.Default.Person,
            cardBg = KpiOrangeBg,
            iconTint = KpiOrangeIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.MEDICAL_STAFF) }
          )

          WaseemKpiMiniCard(
            title = "الباقات النشطة",
            value = "$activePackagesCount",
            icon = Icons.Default.Layers,
            cardBg = KpiGreenBg,
            iconTint = KpiGreenIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.PACKAGES) }
          )

          WaseemKpiMiniCard(
            title = "الفواتير",
            value = "${validTx.size}",
            icon = Icons.Default.Description,
            cardBg = KpiPinkBg,
            iconTint = KpiPinkIcon,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.FINANCE) }
          )
        }
      }
    }

    // 3. Main Services Grid (10 Squircles in 2 Rows of 5)
    item {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Row 1 of Service Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          WaseemServiceButton(
            title = "الأطباء",
            subtitle = "إدارة الفريق الطبي",
            icon = Icons.Default.Person,
            color = ServiceDoctorColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.MEDICAL_STAFF) }
          )
          WaseemServiceButton(
            title = "الباقات",
            subtitle = "إدارة الباقات",
            icon = Icons.Default.AllInbox,
            color = ServicePackageColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.PACKAGES) }
          )
          WaseemServiceButton(
            title = "الجلسات",
            subtitle = "متابعة الجلسات",
            icon = Icons.Default.Hotel,
            color = ServiceSessionColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.SESSIONS) }
          )
          WaseemServiceButton(
            title = "المواعيد",
            subtitle = "حجز وإدارة المواعيد",
            icon = Icons.Default.CalendarMonth,
            color = ServiceAppointmentColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.APPOINTMENTS) }
          )
          WaseemServiceButton(
            title = "المرضى",
            subtitle = "إدارة ملفات المرضى",
            icon = Icons.Default.People,
            color = ServicePatientColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.PATIENTS) }
          )
        }

        // Row 2 of Service Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          WaseemServiceButton(
            title = "المزيد",
            subtitle = "أدوات إضافية",
            icon = Icons.Default.GridView,
            color = ServiceMoreColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.AUDIT_LOG) }
          )
          WaseemServiceButton(
            title = "الإعدادات",
            subtitle = "إعدادات النظام",
            icon = Icons.Default.Settings,
            color = ServiceSettingsColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.SETTINGS) }
          )
          WaseemServiceButton(
            title = "التقارير",
            subtitle = "إحصائيات وتقارير",
            icon = Icons.Default.BarChart,
            color = ServiceReportsColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.REPORTS) }
          )
          WaseemServiceButton(
            title = "المخزون",
            subtitle = "إدارة الأصناف",
            icon = Icons.Default.Category,
            color = ServiceInventoryColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.DEPARTMENTS) }
          )
          WaseemServiceButton(
            title = "الحسابات",
            subtitle = "الفواتير والمدفوعات",
            icon = Icons.Default.AccountBalanceWallet,
            color = ServiceAccountsColor,
            modifier = Modifier.weight(1f),
            onClick = { onNavigate(ClinicScreen.ACCOUNTS_LEDGER) }
          )
        }
      }
    }

    // 4. Recent Activity Split Cards (Latest Patients & Today's Appointments)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Today's Appointments Card (Right)
        WaseemActivityCard(
          title = "مواعيد اليوم",
          titleIcon = "📅",
          onViewAll = { onNavigate(ClinicScreen.APPOINTMENTS) },
          modifier = Modifier.weight(1f)
        ) {
          if (todayApptList.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "لا توجد مواعيد اليوم",
                style = MaterialTheme.typography.bodySmall.copy(
                  color = Color.Gray,
                  fontSize = 12.sp
                )
              )
            }
          } else {
            Column(
              verticalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              todayApptList.forEach { appt ->
                Surface(
                  color = Color(0xFFF8FAFC),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Column {
                      Text(
                        text = appt.patientName,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                      Text(
                        text = appt.startTime,
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 9.sp)
                      )
                    }
                    Surface(
                      color = Color(0xFFE0F2FE),
                      shape = RoundedCornerShape(4.dp)
                    ) {
                      Text(
                        text = appt.status,
                        style = MaterialTheme.typography.labelSmall.copy(
                          color = Color(0xFF0369A1),
                          fontSize = 8.sp,
                          fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
              }
            }
          }
        }

        // Latest Patients Card (Left)
        WaseemActivityCard(
          title = "أحدث المرضى",
          titleIcon = "👥",
          onViewAll = { onNavigate(ClinicScreen.PATIENTS) },
          modifier = Modifier.weight(1f)
        ) {
          if (latestPatients.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "لا توجد بيانات حالياً",
                style = MaterialTheme.typography.bodySmall.copy(
                  color = Color.Gray,
                  fontSize = 12.sp
                )
              )
            }
          } else {
            Column(
              verticalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              latestPatients.forEach { patient ->
                Surface(
                  color = Color(0xFFF8FAFC),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Column {
                      Text(
                        text = patient.fullName,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                      )
                      Text(
                        text = patient.patientCode,
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.Gray, fontSize = 9.sp)
                      )
                    }
                    Icon(
                      Icons.Default.ChevronLeft,
                      contentDescription = null,
                      tint = Color.Gray,
                      modifier = Modifier.size(14.dp)
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // Developer Signature
    item {
      DeveloperFooter()
    }
  }
}

/**
 * Hero Banner matched precisely to WASEEM MEDICAL PRO template
 */
@Composable
fun WaseemHeroBanner(onCtaClick: () -> Unit) {
  Surface(
    shape = RoundedCornerShape(18.dp),
    color = Color.White,
    shadowElevation = 2.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = Modifier
      .fillMaxWidth()
      .height(175.dp)
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      // Background Image of Modern Clinic Reception
      Image(
        painter = painterResource(id = R.drawable.img_waseem_clinic_banner),
        contentDescription = "استقبال المركز الطبي",
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop
      )

      // Light Gradient Overlay to make Arabic typography pop cleanly
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.horizontalGradient(
              colors = listOf(
                Color.White.copy(alpha = 0.95f),
                Color.White.copy(alpha = 0.85f),
                Color.Transparent
              )
            )
          )
      )

      // Foreground content: Slogan & CTA Button
      Column(
        modifier = Modifier
          .fillMaxHeight()
          .padding(start = 16.dp, top = 20.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(
            text = "نهتم بصحتك",
            style = MaterialTheme.typography.headlineSmall.copy(
              fontWeight = FontWeight.ExtraBold,
              color = Color(0xFF094685),
              fontSize = 24.sp
            )
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "لأنك تستحق حياة أفضل",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF1E3A8A),
              fontSize = 14.sp
            )
          )
        }

        // Pill button: "رعايتك ... هدفنا"
        Surface(
          shape = RoundedCornerShape(20.dp),
          color = Color(0xFF0D5CAB),
          onClick = onCtaClick,
          modifier = Modifier.padding(top = 8.dp)
        ) {
          Text(
            text = "رعايتك ... هدفنا",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color.White,
              fontSize = 11.sp
            ),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
          )
        }
      }
    }
  }
}

/**
 * Compact Stat Card for the 2x4 Grid
 */
@Composable
fun WaseemKpiMiniCard(
  title: String,
  value: String,
  icon: ImageVector,
  cardBg: Color,
  iconTint: Color,
  modifier: Modifier = Modifier,
  subUnit: String? = null,
  onClick: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = cardBg,
    onClick = onClick,
    modifier = modifier.height(64.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 6.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.Center
      ) {
        Row(verticalAlignment = Alignment.Bottom) {
          Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color(0xFF1E293B),
              fontSize = 14.sp
            ),
            maxLines = 1
          )
          if (subUnit != null) {
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = subUnit,
              style = MaterialTheme.typography.labelSmall.copy(
                color = iconTint,
                fontWeight = FontWeight.Bold,
                fontSize = 8.sp
              )
            )
          }
        }
        Text(
          text = title,
          style = MaterialTheme.typography.labelSmall.copy(
            color = Color(0xFF475569),
            fontSize = 9.sp
          ),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      // Icon Badge
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.White.copy(alpha = 0.85f),
        modifier = Modifier.size(28.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(16.dp)
          )
        }
      }
    }
  }
}

/**
 * 10 Main Service Buttons (Squircle shape, icon on colored background, title & subtitle)
 */
@Composable
fun WaseemServiceButton(
  title: String,
  subtitle: String,
  icon: ImageVector,
  color: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  Column(
    modifier = modifier
      .clickable(onClick = onClick)
      .padding(vertical = 2.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Squircle Button
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = color,
      shadowElevation = 2.dp,
      modifier = Modifier.size(54.dp)
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = Color.White,
          modifier = Modifier.size(28.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = title,
      style = MaterialTheme.typography.labelMedium.copy(
        fontWeight = FontWeight.Bold,
        color = Color(0xFF1E293B),
        fontSize = 11.sp
      ),
      textAlign = TextAlign.Center,
      maxLines = 1
    )

    Text(
      text = subtitle,
      style = MaterialTheme.typography.labelSmall.copy(
        color = Color(0xFF64748B),
        fontSize = 8.sp
      ),
      textAlign = TextAlign.Center,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
  }
}

/**
 * Activity Summary Card with Header & View All button
 */
@Composable
fun WaseemActivityCard(
  title: String,
  titleIcon: String,
  onViewAll: () -> Unit,
  modifier: Modifier = Modifier,
  content: @Composable () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = Color.White,
    shadowElevation = 1.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp)
    ) {
      // Header Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = titleIcon, fontSize = 12.sp)
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              color = Color(0xFF1E293B),
              fontSize = 11.sp
            )
          )
        }

        Surface(
          shape = RoundedCornerShape(10.dp),
          color = Color(0xFFEFF6FF),
          onClick = onViewAll
        ) {
          Text(
            text = "عرض الكل",
            style = MaterialTheme.typography.labelSmall.copy(
              color = Color(0xFF2563EB),
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      content()
    }
  }
}
