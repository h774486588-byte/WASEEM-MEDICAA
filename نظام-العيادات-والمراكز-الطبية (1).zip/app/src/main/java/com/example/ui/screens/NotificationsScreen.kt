package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter

@Composable
fun NotificationsScreen(viewModel: ClinicViewModel) {
  val notifications by viewModel.notifications.collectAsState()
  val unreadCount by viewModel.unreadNotificationsCount.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Actions header
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "مركز الإشعارات والتنبيهات الموحد",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
          text = "غير مقروء: $unreadCount إشعار",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary
        )
      }
      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(
          onClick = { viewModel.markAllNotificationsAsRead() },
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("تحديد الكل كمقروء", fontSize = 11.sp)
        }
        OutlinedButton(
          onClick = { viewModel.clearAllNotifications() },
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text("مسح الكل", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    if (notifications.isEmpty()) {
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth(),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(54.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("لا توجد إشعارات حالياً", color = Color.Gray)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(notifications) { note ->
          NotificationCard(
            note = note,
            onMarkRead = { viewModel.markNotificationAsRead(note.id) }
          )
        }
      }
    }

    DeveloperFooter()
  }
}

@Composable
private fun NotificationCard(
  note: AppNotification,
  onMarkRead: () -> Unit
) {
  val (badgeColor, icon) = when (note.type) {
    "موعد قريب" -> Color(0xFF1976D2) to Icons.Default.CalendarToday
    "باقة قاربت على الانتهاء" -> Color(0xFFE65100) to Icons.Default.Warning
    "حالة جديدة للطبيب" -> Color(0xFF7B1FA2) to Icons.Default.Sick
    "سند مالي جديد" -> Color(0xFF388E3C) to Icons.Default.Receipt
    "مريض جديد" -> Color(0xFF0097A7) to Icons.Default.PersonAdd
    else -> MaterialTheme.colorScheme.primary to Icons.Default.Notifications
  }

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = if (!note.isRead) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
    else MaterialTheme.colorScheme.surface,
    border = if (!note.isRead) androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)) else null,
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onMarkRead() }
  ) {
    Row(
      modifier = Modifier.padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(badgeColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(22.dp))
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = note.title,
            fontWeight = if (!note.isRead) FontWeight.Bold else FontWeight.SemiBold,
            style = MaterialTheme.typography.bodyMedium
          )
          Text(
            text = note.date,
            style = MaterialTheme.typography.labelSmall,
            color = Color.Gray
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = note.message,
          style = MaterialTheme.typography.bodySmall,
          color = if (!note.isRead) Color.Black else Color.DarkGray
        )
      }

      if (!note.isRead) {
        Spacer(modifier = Modifier.width(8.dp))
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary)
        )
      }
    }
  }
}
