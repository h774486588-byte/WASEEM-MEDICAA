package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter

/**
 * 1. DEPARTMENTS & SERVICES SCREEN
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DepartmentsScreen(viewModel: ClinicViewModel) {
  val departments by viewModel.departments.collectAsState()
  val services by viewModel.services.collectAsState()

  var showAddDeptDialog by remember { mutableStateOf(false) }
  var showAddSrvDialog by remember { mutableStateOf(false) }
  var selectedDeptForSrv by remember { mutableStateOf<Department?>(null) }

  if (showAddDeptDialog) {
    var deptName by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showAddDeptDialog = false },
      title = { Text("إضافة قسم طبي جديد") },
      text = {
        OutlinedTextField(
          value = deptName,
          onValueChange = { deptName = it },
          label = { Text("اسم القسم الطبي (مثال: قسم العظام)") },
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(onClick = {
          if (deptName.isNotBlank()) {
            viewModel.addDepartment(deptName)
            showAddDeptDialog = false
          }
        }) { Text("حفظ القسم") }
      },
      dismissButton = {
        OutlinedButton(onClick = { showAddDeptDialog = false }) { Text("إلغاء") }
      }
    )
  }

  if (showAddSrvDialog && selectedDeptForSrv != null) {
    val dept = selectedDeptForSrv!!
    var srvName by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("5000") }
    var shareText by remember { mutableStateOf("40") }

    AlertDialog(
      onDismissRequest = { showAddSrvDialog = false },
      title = { Text("إضافة خدمة في: ${dept.name}") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = srvName,
            onValueChange = { srvName = it },
            label = { Text("اسم الخدمة الطبية") },
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = priceText,
            onValueChange = { priceText = it },
            label = { Text("السعر الافتراضي (ر.ي)") },
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = shareText,
            onValueChange = { shareText = it },
            label = { Text("نسبة الطبيب الافتراضية (%)") },
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(onClick = {
          val price = priceText.toDoubleOrNull() ?: 5000.0
          val share = shareText.toDoubleOrNull() ?: 40.0
          if (srvName.isNotBlank()) {
            viewModel.addService(srvName, dept.id, price, share)
            showAddSrvDialog = false
          }
        }) { Text("حفظ الخدمة") }
      },
      dismissButton = {
        OutlinedButton(onClick = { showAddSrvDialog = false }) { Text("إلغاء") }
      }
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "إدارة الأقسام والخدمات الطبية",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "تنظيم الأقسام وتسعير الخدمات ونسب الأطباء",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(onClick = { showAddDeptDialog = true }, shape = RoundedCornerShape(10.dp)) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("قسم جديد")
        }
      }
    }

    items(departments) { dept ->
      val deptServices = services.filter { it.departmentId == dept.id }

      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.LocalHospital, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(8.dp))
              Text(dept.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              OutlinedButton(
                onClick = {
                  selectedDeptForSrv = dept
                  showAddSrvDialog = true
                },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text("إضافة خدمة")
              }

              Switch(
                checked = dept.isActive,
                onCheckedChange = { viewModel.toggleDepartmentStatus(dept) }
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // List services in this dept
          if (deptServices.isEmpty()) {
            Text(
              text = "لا توجد خدمات مضافة لهذا القسم بعد.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.outline
            )
          } else {
            deptServices.forEach { srv ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(srv.name, style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "${srv.defaultPrice} ر.ي (نسبة ${srv.doctorSharePercent}%)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Checkbox(
                    checked = srv.isActive,
                    onCheckedChange = { viewModel.toggleServiceStatus(srv) }
                  )
                }
              }
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

/**
 * 3. SETTINGS SCREEN
 */
@Composable
fun SettingsScreen(viewModel: ClinicViewModel) {
  val centerProfile by viewModel.centerProfile.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Text(
      text = "إعدادات المنشأة والعيادة (Setup Wizard)",
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
    )
    Text(
      text = "البيانات المسجلة هنا تظهر في ترويسات التقارير والروشتات والسندات الرسمية",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("البيانات الحالية للمنشأة:", fontWeight = FontWeight.Bold)
        Text("اسم المنشأة: ${centerProfile?.facilityName ?: "غير محدد"}", style = MaterialTheme.typography.bodyMedium)
        Text("النوع: ${centerProfile?.facilityType ?: "عيادة"}", style = MaterialTheme.typography.bodySmall)
        Text("المدير الطبي: ${centerProfile?.doctorInCharge ?: "د. وسيم الفرح"}", style = MaterialTheme.typography.bodySmall)
        Text("العنوان: ${centerProfile?.address ?: "الشارع العام"}", style = MaterialTheme.typography.bodySmall)
        Text("هواتف التواصل: ${centerProfile?.phone1 ?: ""} | ${centerProfile?.phone2 ?: ""}", style = MaterialTheme.typography.bodySmall)
        Text("السجل / الترخيص: ${centerProfile?.commercialRecord ?: ""}", style = MaterialTheme.typography.bodySmall)
        Text("الترويسة: ${centerProfile?.headerNotes ?: ""}", style = MaterialTheme.typography.labelSmall)

        Button(
          onClick = { viewModel.toggleSetupWizard(true) },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("تعديل بيانات المنشأة عبر معالج الإعداد")
        }
      }
    }

    // Developer Credentials Card
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(Icons.Default.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "نظام وسيم لإدارة المراكز الطبية والعيادات",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(
          text = "تطوير: وسيم الفرح | هاتف: 774486588",
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
        Text(
          text = "إصدار 2.5 - متوافق مع نظام أندرويد وقواعد بيانات SQLite/Room المحلية",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
        )
      }
    }

    DeveloperFooter()
  }
}

/**
 * 4. BACKUP & DATABASE SCREEN
 */
@Composable
fun BackupScreen(viewModel: ClinicViewModel) {
  val context = LocalContext.current
  val patients by viewModel.patients.collectAsState()
  val appointments by viewModel.appointments.collectAsState()
  val transactions by viewModel.financeTransactions.collectAsState()
  val packages by viewModel.patientPackages.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Text(
      text = "إدارة قاعدة البيانات والنسخ الاحتياطي",
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
    )
    Text(
      text = "حفظ واسترجاع بيانات المرضى والملفات والسندات محلياً بأمان",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
      elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("حالة السجلات في قاعدة البيانات المحلية (Room Database):", fontWeight = FontWeight.Bold)
        Text("• عدد سجلات المرضى: ${patients.size} ملف طبي", style = MaterialTheme.typography.bodySmall)
        Text("• عدد المواعيد المسجلة: ${appointments.size} موعد", style = MaterialTheme.typography.bodySmall)
        Text("• عدد باقات المرضى: ${packages.size} باقة علاجية", style = MaterialTheme.typography.bodySmall)
        Text("• عدد القيود والسندات المالية: ${transactions.size} سند قيد", style = MaterialTheme.typography.bodySmall)
      }
    }

    Button(
      onClick = {
        Toast.makeText(context, "تم حفظ النسخة الاحتياطية بنجاح في مجلد التطبيق الآمن", Toast.LENGTH_LONG).show()
      },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp)
    ) {
      Icon(Icons.Default.CloudUpload, contentDescription = null)
      Spacer(modifier = Modifier.width(8.dp))
      Text("إنشاء نسخة احتياطية فورية الآن (Backup)")
    }

    OutlinedButton(
      onClick = {
        Toast.makeText(context, "قاعدة البيانات سليمة ومحدثة تلقائياً بنجاح", Toast.LENGTH_SHORT).show()
      },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp)
    ) {
      Icon(Icons.Default.Sync, contentDescription = null)
      Spacer(modifier = Modifier.width(8.dp))
      Text("فحص تكامل الجداول والمزامنة المحلية")
    }

    DeveloperFooter()
  }
}

/**
 * 5. MESSAGE TEMPLATES SCREEN
 */
@Composable
fun TemplatesScreen(viewModel: ClinicViewModel) {
  val templates by viewModel.templates.collectAsState()
  var selectedTemplate by remember { mutableStateOf<MessageTemplate?>(null) }
  var bodyText by remember { mutableStateOf("") }

  LaunchedEffect(templates) {
    if (templates.isNotEmpty() && selectedTemplate == null) {
      selectedTemplate = templates.first()
      bodyText = templates.first().templateBody
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Text(
      text = "مركز الرسائل وإعادة الصياغة والتخصيص",
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
    )
    Text(
      text = "تخصيص قوالب الرسائل التلقائية للواتساب والرسائل النصية",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    // Template selector chips
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      templates.forEach { tmpl ->
        FilterChip(
          selected = selectedTemplate?.key == tmpl.key,
          onClick = {
            selectedTemplate = tmpl
            bodyText = tmpl.templateBody
          },
          label = { Text(tmpl.title) }
        )
      }
    }

    selectedTemplate?.let { tmpl ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(text = "نص القالب: ${tmpl.title}", fontWeight = FontWeight.Bold)
          Text(
            text = "المتغيرات المتاحة: {PATIENT_NAME}, {CENTER_NAME}, {DATE}, {TIME}, {DOCTOR_NAME}, {SERVICE_NAME}, {PACKAGE_NAME}, {REMAINING}, {AMOUNT}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
          )

          OutlinedTextField(
            value = bodyText,
            onValueChange = { bodyText = it },
            label = { Text("محتوى الرسالة") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 6
          )

          Button(
            onClick = {
              viewModel.saveTemplate(tmpl.key, tmpl.title, bodyText)
            },
            modifier = Modifier.fillMaxWidth()
          ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("حفظ تعديلات القالب")
          }
        }
      }
    }

    DeveloperFooter()
  }
}

/**
 * 6. SUPPORT & CONTACT SCREEN
 */
@Composable
fun SupportScreen(viewModel: ClinicViewModel) {
  val context = LocalContext.current

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState()),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    Text(
      text = "الدعم الفني والتواصل المباشر",
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
    )
    Text(
      text = "للمساعدة الفنية، الاستفسارات، أو طلب ميزات وتحديثات إضافية للنظام",
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Icon(
          Icons.Default.SupportAgent,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "وسيم الفرح",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(
          text = "مطور ومصمم أنظمة إدارة المراكز والعيادات الطبية",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Surface(
          color = MaterialTheme.colorScheme.primary,
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(
            text = "هاتف: 774486588",
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // WhatsApp direct contact
        Button(
          onClick = {
            viewModel.sendWhatsApp(context, "774486588", "السلام عليكم م. وسيم الفرح، أتواصل معك بخصوص نظام إدارة المراكز الطبية.")
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
        ) {
          Icon(Icons.Default.Share, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text("تواصل مباشر عبر واتساب (774486588)", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Phone call direct
        OutlinedButton(
          onClick = { viewModel.callPhone(context, "774486588") },
          modifier = Modifier.fillMaxWidth()
        ) {
          Icon(Icons.Default.Call, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("اتصال هاتفي مباشر")
        }
      }
    }

    DeveloperFooter()
  }
}
