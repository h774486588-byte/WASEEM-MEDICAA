package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientDetailsScreen(
  viewModel: ClinicViewModel,
  onBack: () -> Unit
) {
  val context = LocalContext.current
  val patient by viewModel.selectedPatient.collectAsState()
  val timeline by viewModel.selectedPatientTimeline.collectAsState()
  val patientPackages by viewModel.selectedPatientPackages.collectAsState()
  val appointments by viewModel.selectedPatientAppointments.collectAsState()
  val cases by viewModel.selectedPatientCases.collectAsState()
  val sessions by viewModel.selectedPatientSessions.collectAsState()
  val financeTransactions by viewModel.selectedPatientFinance.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()

  var selectedTab by remember { mutableStateOf(0) }
  var showAddVisitDialog by remember { mutableStateOf(false) }

  if (patient == null) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
      Text("لم يتم تحديد مريض لعرض ملفه.")
    }
    return
  }

  val p = patient!!

  // Add Visit Dialog
  if (showAddVisitDialog) {
    AddVisitDialog(
      medicalStaff = medicalStaff,
      onDismiss = { showAddVisitDialog = false },
      onSave = { docName, srvName, diagnosis, prescription, attachment, notes ->
        viewModel.addPatientTimelineEntry(
          patientId = p.id,
          doctorName = docName,
          serviceName = srvName,
          diagnosis = diagnosis,
          prescription = prescription,
          attachmentTitle = attachment,
          notes = notes
        )
        showAddVisitDialog = false
      }
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Top Bar Back & Actions
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
        }
        Column {
          Text(
            text = "الملف الطبي الشامل للمريض",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = p.fullName,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }

      Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        // Print Full Medical Report
        IconButton(onClick = {
          val lines = mutableListOf<String>()
          lines.add("اسم المريض: ${p.fullName}")
          lines.add("رقم الملف: ${p.patientCode} | العمر: ${p.age} سنة")
          lines.add("الهاتف: ${p.phone} | العنوان: ${p.address}")
          lines.add("طوارئ: ${p.emergencyRelation} (${p.emergencyPhone})")
          lines.add("--- السجل الزمني والتشخيصات ---")
          timeline.forEach { t ->
            lines.add("${t.visitDate}: ${t.serviceName} لدى ${t.doctorName}")
            lines.add("  التشخيص: ${t.diagnosis}")
            lines.add("  العلاج: ${t.prescription}")
          }
          lines.add("--- الرصيد والبيانات المالية ---")
          val totalPaid = financeTransactions.filter { it.docType == "سند قبض" && !it.isVoided }.sumOf { it.amount }
          lines.add("إجمالي المسدد: ${viewModel.formatMoney(totalPaid)} ر.ي")

          viewModel.openPrintDialog(
            PrintPayload(
              type = "A4_REPORT",
              title = "تقرير الملف الطبي الشامل",
              contentLines = lines,
              docNumber = p.patientCode,
              patientName = p.fullName
            )
          )
        }) {
          Icon(Icons.Default.Print, contentDescription = "طباعة الملف")
        }

        // Direct WhatsApp
        IconButton(onClick = {
          viewModel.sendWhatsApp(
            context,
            p.phone,
            "مرحباً ${p.fullName}، من ${centerProfile?.facilityName ?: "المركز الطبي"}."
          )
        }) {
          Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color(0xFF25D366))
        }

        // Direct Call
        IconButton(onClick = { viewModel.callPhone(context, p.phone) }) {
          Icon(Icons.Default.Call, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    // Patient Profile Header Card
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              color = MaterialTheme.colorScheme.primary,
              shape = RoundedCornerShape(8.dp)
            ) {
              Text(
                text = p.patientCode,
                color = Color.White,
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = p.fullName,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
          }

          Text(
            text = "${p.gender} | ${p.age} سنة",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "📱 ${p.phone} | 📍 ${p.address.ifEmpty { "غير محدد" }}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
        )

        if (p.emergencyRelation.isNotEmpty() || p.emergencyPhone.isNotEmpty()) {
          Text(
            text = "🚨 طوارئ: ${p.emergencyRelation} - ${p.emergencyPhone}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
          )
        }

        if (p.notes.isNotEmpty()) {
          Text(
            text = "⚠️ ملاحظات سريرية: ${p.notes}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.padding(top = 4.dp)
          )
        }
      }
    }

    // Tabs: 0:السجل الطبي, 1:الحالات, 2:الجلسات, 3:الباقات, 4:المواعيد, 5:كشف الحساب
    ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 0.dp) {
      Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("الزيارات (${timeline.size})") })
      Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("الحالات (${cases.size})") })
      Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("الجلسات (${sessions.size})") })
      Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("الباقات (${patientPackages.size})") })
      Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("المواعيد (${appointments.size})") })
      Tab(selected = selectedTab == 5, onClick = { selectedTab = 5 }, text = { Text("كشف الحساب") })
    }

    // Content of selected tab
    when (selectedTab) {
      0 -> {
        // Tab 0: Timeline & Diagnosis History
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "سجل الزيارات والتشخيصات (${timeline.size}):",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
          )

          Button(
            onClick = { showAddVisitDialog = true },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("إضافة زيارة / تشخيص")
          }
        }

        if (timeline.isEmpty()) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("لا توجد زيارات مسجلة للمريض بعد.", color = MaterialTheme.colorScheme.outline)
          }
        } else {
          LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(timeline) { t ->
              Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(text = "📅 ${t.visitDate} | 🩺 ${t.serviceName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text(text = "👨‍⚕️ ${t.doctorName}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                  }
                  if (t.diagnosis.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "التشخيص: ${t.diagnosis}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                  }
                  if (t.prescription.isNotEmpty()) {
                    Text(text = "الوصفة / العلاج: ${t.prescription}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                  }
                  if (t.notes.isNotEmpty()) {
                    Text(text = "ملاحظات: ${t.notes}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline, modifier = Modifier.padding(top = 4.dp))
                  }
                }
              }
            }
          }
        }
      }

      1 -> {
        // Tab 1: Cases
        if (cases.isEmpty()) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("لا توجد حالات مرضية مسجلة.", color = MaterialTheme.colorScheme.outline)
          }
        } else {
          LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cases) { c ->
              Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${c.caseCode} - ${c.title}", fontWeight = FontWeight.Bold)
                    StatusBadge(status = c.status)
                  }
                  Text("الطبيب: ${c.doctorName} | القسم: ${c.departmentName}", style = MaterialTheme.typography.bodySmall)
                  Text("الملاحظات: ${c.notes}", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
                }
              }
            }
          }
        }
      }

      2 -> {
        // Tab 2: Sessions
        if (sessions.isEmpty()) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("لا توجد جلسات مسجلة للمريض بعد.", color = MaterialTheme.colorScheme.outline)
          }
        } else {
          LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sessions) { s ->
              Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("الجلسة رقم ${s.sessionNumber} (${s.sessionCode})", fontWeight = FontWeight.Bold)
                    StatusBadge(status = s.status)
                  }
                  Text("الباقة: ${s.packageName} | الطبيب: ${s.doctorName}", style = MaterialTheme.typography.bodySmall)
                  Text("التاريخ: ${s.sessionDate} (${s.checkInTime} - ${s.checkOutTime})", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                  if (s.notes.isNotBlank()) {
                    Text("ملاحظات: ${s.notes}", style = MaterialTheme.typography.bodySmall)
                  }
                }
              }
            }
          }
        }
      }

      3 -> {
        // Tab 3: Packages
        if (patientPackages.isEmpty()) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("لا توجد باقات مفعلة لهذا المريض.", color = MaterialTheme.colorScheme.outline)
          }
        } else {
          LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(patientPackages) { pkg ->
              Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(pkg.packageName, fontWeight = FontWeight.Bold)
                    StatusBadge(status = pkg.status)
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "الجلسات: ${pkg.usedSessions} مستهلكة / ${pkg.remainingSessions} متبقية (إجمالي: ${pkg.totalSessions})",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (pkg.remainingSessions <= 2) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "صلاحية الباقة: من ${pkg.purchaseDate} حتى ${pkg.expiryDate}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                  )
                }
              }
            }
          }
        }
      }

      4 -> {
        // Tab 4: Appointments
        if (appointments.isEmpty()) {
          Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("لا توجد مواعيد سابقة أو قادمة للمريض.", color = MaterialTheme.colorScheme.outline)
          }
        } else {
          LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(appointments) { appt ->
              Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                  modifier = Modifier.fillMaxWidth().padding(12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Text("${appt.appointmentCode} - ${appt.serviceName}", fontWeight = FontWeight.Bold)
                    Text("👨‍⚕️ ${appt.doctorName} | 📅 ${appt.appointmentDate} (${appt.startTime})", style = MaterialTheme.typography.bodySmall)
                  }
                  StatusBadge(status = appt.status)
                }
              }
            }
          }
        }
      }

      5 -> {
        // Tab 5: Finance Ledger
        val totalReceipts = financeTransactions.filter { it.docType == "سند قبض" && !it.isVoided }.sumOf { it.amount }

        Column(modifier = Modifier.weight(1f)) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text("إجمالي المبالغ المسددة من المريض:", fontWeight = FontWeight.Bold)
              Text("${viewModel.formatMoney(totalReceipts)} ر.ي", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
          }

          if (financeTransactions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
              Text("لا توجد سندات مالية مقيدة للمريض.", color = MaterialTheme.colorScheme.outline)
            }
          } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
              items(financeTransactions) { tx ->
                Card(shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Column {
                      Text("${tx.docNumber} (${tx.docType})", fontWeight = FontWeight.Bold)
                      Text("البيان: ${tx.notes}", style = MaterialTheme.typography.bodySmall)
                      Text("التاريخ: ${tx.date} | طريقة الدفع: ${tx.paymentMethod}", style = MaterialTheme.typography.labelSmall)
                    }
                    Text(
                      text = "${viewModel.formatMoney(tx.amount)} ر.ي",
                      fontWeight = FontWeight.Bold,
                      color = if (tx.isVoided) Color.Gray else if (tx.docType == "سند قبض") Color(0xFF166534) else MaterialTheme.colorScheme.error
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    DeveloperFooter()
  }
}

/**
 * Add Medical Visit / Diagnosis Dialog
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddVisitDialog(
  medicalStaff: List<MedicalStaff>,
  onDismiss: () -> Unit,
  onSave: (String, String, String, String, String, String) -> Unit
) {
  var doctorName by remember { mutableStateOf(medicalStaff.firstOrNull()?.name ?: "د. وسيم الفرح") }
  var serviceName by remember { mutableStateOf("استشارة ومعاينة دورية") }
  var diagnosis by remember { mutableStateOf("") }
  var prescription by remember { mutableStateOf("") }
  var attachment by remember { mutableStateOf("") }
  var notes by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier
          .padding(16.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = "إضافة زيارة وتشخيص سريري للملف",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        OutlinedTextField(
          value = doctorName,
          onValueChange = { doctorName = it },
          label = { Text("الطبيب المعالج") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = serviceName,
          onValueChange = { serviceName = it },
          label = { Text("الخدمة الطبية / الجلسة") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = diagnosis,
          onValueChange = { diagnosis = it },
          label = { Text("التشخيص الطبي والحالة السريرية *") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 2
        )

        OutlinedTextField(
          value = prescription,
          onValueChange = { prescription = it },
          label = { Text("الوصفة الدوائية والخطة العلاجية") },
          modifier = Modifier.fillMaxWidth(),
          minLines = 2
        )

        OutlinedTextField(
          value = attachment,
          onValueChange = { attachment = it },
          label = { Text("عنوان المرفق (أشعة سينية، فحص دم...)") },
          modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات إضافية") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (diagnosis.isNotBlank() || serviceName.isNotBlank()) {
                onSave(doctorName, serviceName, diagnosis, prescription, attachment, notes)
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ بالملف")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
