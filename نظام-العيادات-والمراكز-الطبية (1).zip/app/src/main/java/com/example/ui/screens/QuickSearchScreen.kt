package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ClinicScreen
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter
import com.example.ui.StatusBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickSearchScreen(
  viewModel: ClinicViewModel,
  onNavigate: (ClinicScreen) -> Unit,
  onOpenPatient: (Long) -> Unit
) {
  val context = LocalContext.current
  val searchQuery by viewModel.searchQuery.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val appointments by viewModel.appointments.collectAsState()
  val medicalStaff by viewModel.medicalStaff.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  // Filtered lists based on search query
  val trimmed = searchQuery.trim()
  val filteredPatients = remember(trimmed, patients) {
    if (trimmed.isEmpty()) emptyList()
    else patients.filter {
      it.fullName.contains(trimmed, ignoreCase = true) ||
          it.phone.contains(trimmed) ||
          it.patientCode.contains(trimmed, ignoreCase = true) ||
          it.address.contains(trimmed, ignoreCase = true)
    }
  }

  val filteredAppointments = remember(trimmed, appointments) {
    if (trimmed.isEmpty()) emptyList()
    else appointments.filter {
      it.patientName.contains(trimmed, ignoreCase = true) ||
          it.doctorName.contains(trimmed, ignoreCase = true) ||
          it.appointmentCode.contains(trimmed, ignoreCase = true) ||
          it.serviceName.contains(trimmed, ignoreCase = true)
    }
  }

  val filteredStaff = remember(trimmed, medicalStaff) {
    if (trimmed.isEmpty()) emptyList()
    else medicalStaff.filter {
      it.name.contains(trimmed, ignoreCase = true) ||
          it.specialty.contains(trimmed, ignoreCase = true) ||
          it.phone.contains(trimmed)
    }
  }

  val isSearching = trimmed.isNotEmpty()

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Spacer(modifier = Modifier.height(8.dp))
      // Center Welcome Header
      Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(52.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              Icons.Default.LocalHospital,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(30.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = centerProfile?.facilityName ?: "مجمع الشفاء الطبي التخصصي",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
              text = "واجهة البحث السريعة الفورية والوصول المباشر",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
          }
        }
      }
    }

    // Smart Instant Search Bar
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { viewModel.setSearchQuery(it) },
        placeholder = { Text("بحث فوري بالاسم، الهاتف، رقم الملف P-1001، أو الموعد...") },
        leadingIcon = {
          Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(onClick = { viewModel.setSearchQuery("") }) {
              Icon(Icons.Default.Close, contentDescription = "مسح")
            }
          }
        },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = MaterialTheme.colorScheme.surface,
          unfocusedContainerColor = MaterialTheme.colorScheme.surface
        )
      )
    }

    if (!isSearching) {
      // Fast Action Buttons Grid
      item {
        Text(
          text = "الوصول السريع إلى الأقسام:",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            QuickActionButton(
              title = "1- حالة جديدة",
              subtitle = "تسجيل ملف مريض",
              icon = Icons.Default.PersonAdd,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.NEW_PATIENT) }

            QuickActionButton(
              title = "2- المواعيد",
              subtitle = "جدول وحجوزات اليوم",
              icon = Icons.Default.Event,
              color = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.APPOINTMENTS) }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            QuickActionButton(
              title = "3- الجلسات والباقات",
              subtitle = "متابعة وخصم الرصيد",
              icon = Icons.Default.MedicalServices,
              color = MaterialTheme.colorScheme.tertiary,
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.PACKAGES) }

            QuickActionButton(
              title = "4- إدارة المرضى",
              subtitle = "الملفات والتقارير",
              icon = Icons.Default.People,
              color = Color(0xFF0284C7),
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.PATIENTS) }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            QuickActionButton(
              title = "5- العاملين",
              subtitle = "الرواتب والعهد",
              icon = Icons.Default.Badge,
              color = Color(0xFF0D9488),
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.STAFF) }

            QuickActionButton(
              title = "6- الكوادر الطبية",
              subtitle = "الأطباء والنسب",
              icon = Icons.Default.HealthAndSafety,
              color = Color(0xFF7C3AED),
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.MEDICAL_STAFF) }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            QuickActionButton(
              title = "7- التقارير",
              subtitle = "التشغيلية والمالية",
              icon = Icons.Default.Assessment,
              color = Color(0xFFD97706),
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.REPORTS) }

            QuickActionButton(
              title = "8- الإدارة المالية",
              subtitle = "سندات وقيد مزدوج",
              icon = Icons.Default.AccountBalanceWallet,
              color = Color(0xFF16A34A),
              modifier = Modifier.weight(1f)
            ) { onNavigate(ClinicScreen.FINANCE) }
          }
        }
      }

      // Today's summary stats
      item {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "إحصائيات سريعة للعيادة:",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          StatChip(
            label = "إجمالي المرضى",
            value = "${patients.size}",
            icon = Icons.Default.People,
            modifier = Modifier.weight(1f)
          )
          StatChip(
            label = "المواعيد المسجلة",
            value = "${appointments.size}",
            icon = Icons.Default.CalendarToday,
            modifier = Modifier.weight(1f)
          )
          StatChip(
            label = "الأطباء والكوادر",
            value = "${medicalStaff.size}",
            icon = Icons.Default.MedicalServices,
            modifier = Modifier.weight(1f)
          )
        }
      }

      // Recent Appointments preview
      item {
        Text(
          text = "آخر الحجوزات والمواعيد:",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
        )
      }

      items(appointments.take(4)) { appt ->
        ElevatedCard(
          onClick = { onNavigate(ClinicScreen.APPOINTMENTS) },
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "${appt.appointmentCode} - ${appt.patientName}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "${appt.serviceName} | ${appt.doctorName}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Text(
                text = "📅 ${appt.appointmentDate} | ⏰ ${appt.startTime} - ${appt.endTime}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
              )
            }
            StatusBadge(status = appt.status)
          }
        }
      }
    } else {
      // SEARCH RESULTS VIEW
      // Patients Results
      item {
        Text(
          text = "نتائج البحث في المرضى (${filteredPatients.size}):",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }

      if (filteredPatients.isEmpty()) {
        item {
          Text(
            text = "لا يوجد مريض مطابق لنص البحث.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline
          )
        }
      } else {
        items(filteredPatients) { p ->
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    color = MaterialTheme.colorScheme.primary,
                    shape = RoundedCornerShape(6.dp)
                  ) {
                    Text(
                      text = p.patientCode,
                      color = Color.White,
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = p.fullName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                  )
                }
                Text(
                  text = "📱 ${p.phone} | العمر: ${p.age} سنة | ${p.address}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              IconButton(onClick = {
                viewModel.sendWhatsApp(
                  context,
                  p.phone,
                  "مرحباً ${p.fullName}، من ${centerProfile?.facilityName ?: "المركز الطبي"}."
                )
              }) {
                Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color(0xFF25D366))
              }

              Button(
                onClick = { onOpenPatient(p.id) },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
              ) {
                Text("فتح الملف")
              }
            }
          }
        }
      }

      // Appointments Results
      item {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "نتائج البحث في المواعيد (${filteredAppointments.size}):",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.primary
        )
      }

      items(filteredAppointments) { appt ->
        Card(
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "${appt.appointmentCode} - ${appt.patientName}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "د. ${appt.doctorName} - ${appt.serviceName}",
                style = MaterialTheme.typography.bodySmall
              )
              Text(
                text = "${appt.appointmentDate} (${appt.startTime} - ${appt.endTime})",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
              )
            }
            StatusBadge(status = appt.status)
          }
        }
      }

      // Doctors / Staff results
      if (filteredStaff.isNotEmpty()) {
        item {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "نتائج البحث في الكوادر الطبية (${filteredStaff.size}):",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
          )
        }

        items(filteredStaff) { doc ->
          Card(
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(text = doc.name, fontWeight = FontWeight.Bold)
                Text(text = "${doc.role} - ${doc.specialty}", style = MaterialTheme.typography.bodySmall)
                Text(text = "هاتف: ${doc.phone}", style = MaterialTheme.typography.labelSmall)
              }
              IconButton(onClick = { viewModel.callPhone(context, doc.phone) }) {
                Icon(Icons.Default.Call, contentDescription = "اتصال", tint = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun QuickActionButton(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  color: Color,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  ElevatedCard(
    onClick = onClick,
    shape = RoundedCornerShape(14.dp),
    modifier = modifier.height(82.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
      }
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

@Composable
private fun StatChip(
  label: String,
  value: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.surfaceVariant,
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
      Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}
