package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter

@Composable
fun AccountsLedgerScreen(viewModel: ClinicViewModel) {
  val accounts by viewModel.chartOfAccounts.collectAsState()
  val transactions by viewModel.financeTransactions.collectAsState()
  val profile by viewModel.centerProfile.collectAsState()

  var selectedTab by remember { mutableStateOf(0) } // 0: شجرة الحسابات, 1: دفتر اليومية, 2: ميزان المراجعة
  val tabs = listOf("شجرة الحسابات", "دفتر اليومية العامة", "ميزان المراجعة")

  // Calculations for Trial Balance
  val totalDebit = accounts.filter { it.category == "أصول" || it.category == "مصروفات" }.sumOf { it.currentBalance }
  val totalCredit = accounts.filter { it.category == "التزامات" || it.category == "حقوق ملكية" || it.category == "إيرادات" }.sumOf { it.currentBalance }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Header with Period Lock status
    Surface(
      color = if (profile?.accountingPeriodLocked == true) Color(0xFFFFEBEE) else Color(0xFFE8F5E9),
      shape = RoundedCornerShape(12.dp),
      border = androidx.compose.foundation.BorderStroke(
        1.dp,
        if (profile?.accountingPeriodLocked == true) Color(0xFFE57373) else Color(0xFF81C784)
      ),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            if (profile?.accountingPeriodLocked == true) Icons.Default.Lock else Icons.Default.LockOpen,
            contentDescription = null,
            tint = if (profile?.accountingPeriodLocked == true) Color(0xFFC62828) else Color(0xFF2E7D32)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = if (profile?.accountingPeriodLocked == true) "الفترة المحاسبية مقفلة حالياً" else "الفترة المحاسبية مفتوحة للقيود",
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.bodyMedium,
              color = if (profile?.accountingPeriodLocked == true) Color(0xFFC62828) else Color(0xFF2E7D32)
            )
            Text(
              text = "نظام القيد المزدوج المحكم (Double-Entry Ledger)",
              style = MaterialTheme.typography.labelSmall,
              color = Color.DarkGray
            )
          }
        }
        FilledTonalButton(
          onClick = { viewModel.toggleAccountingPeriodLock() },
          colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = if (profile?.accountingPeriodLocked == true) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color(0xFFC62828).copy(alpha = 0.15f)
          )
        ) {
          Text(
            text = if (profile?.accountingPeriodLocked == true) "إلغاء القفل" else "قفل الفترة",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (profile?.accountingPeriodLocked == true) Color(0xFF2E7D32) else Color(0xFFC62828)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    TabRow(selectedTabIndex = selectedTab) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    when (selectedTab) {
      0 -> ChartOfAccountsView(accounts = accounts, viewModel = viewModel)
      1 -> GeneralJournalView(transactions = transactions, viewModel = viewModel)
      2 -> TrialBalanceView(accounts = accounts, totalDebit = totalDebit, totalCredit = totalCredit, viewModel = viewModel)
    }

    DeveloperFooter()
  }
}

@Composable
private fun ChartOfAccountsView(
  accounts: List<ChartOfAccount>,
  viewModel: ClinicViewModel
) {
  val grouped = accounts.groupBy { it.category }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    grouped.forEach { (cat, accList) ->
      item {
        Surface(
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "تصنيف: $cat (${accList.size} حسابات)",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }
      items(accList) { acc ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                  color = MaterialTheme.colorScheme.secondaryContainer,
                  shape = RoundedCornerShape(4.dp)
                ) {
                  Text(
                    text = acc.accountCode,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = acc.accountName,
                  fontWeight = FontWeight.Bold,
                  style = MaterialTheme.typography.bodyMedium
                )
              }
              Text(
                text = "طبيعة الحساب: ${acc.category}",
                style = MaterialTheme.typography.labelSmall,
                color = Color.Gray
              )
            }
            Text(
              text = "${viewModel.formatMoney(acc.currentBalance)} ر.ي",
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }
    }
  }
}

@Composable
private fun GeneralJournalView(
  transactions: List<FinanceTransaction>,
  viewModel: ClinicViewModel
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    items(transactions) { tx ->
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
          containerColor = if (tx.isVoided) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
          else MaterialTheme.colorScheme.surface
        )
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = tx.docNumber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = "(${tx.docType})", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
            if (tx.isVoided) {
              Text(text = "ملغي / معكوس", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
            } else {
              Text(text = "${viewModel.formatMoney(tx.amount)} ر.ي", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(8.dp)) {
              Text(
                text = "من حـ/ (مدين Debit): ${tx.debitAccount}",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
              )
              Text(
                text = "إلى حـ/ (دائن Credit): ${tx.creditAccount}",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "البيان: ${tx.notes}", style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
            Text(text = tx.date, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
          }
        }
      }
    }
  }
}

@Composable
private fun TrialBalanceView(
  accounts: List<ChartOfAccount>,
  totalDebit: Double,
  totalCredit: Double,
  viewModel: ClinicViewModel
) {
  val isBalanced = kotlin.math.abs(totalDebit - totalCredit) < 1.0

  Column(modifier = Modifier.fillMaxSize()) {
    // Balance status header
    Surface(
      color = if (isBalanced) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
      shape = RoundedCornerShape(10.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, if (isBalanced) Color(0xFF81C784) else Color(0xFFE57373)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = if (isBalanced) "ميزان المراجعة متزن تماماً ✓" else "تنبيه: ميزان المراجعة غير متزن!",
            fontWeight = FontWeight.Bold,
            color = if (isBalanced) Color(0xFF2E7D32) else Color(0xFFC62828)
          )
          Text(
            text = "المدين = الدائن",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (isBalanced) Color(0xFF2E7D32) else Color(0xFFC62828)
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(text = "إجمالي الجانب المدين: ${viewModel.formatMoney(totalDebit)} ر.ي", style = MaterialTheme.typography.bodySmall)
          Text(text = "إجمالي الجانب الدائن: ${viewModel.formatMoney(totalCredit)} ر.ي", style = MaterialTheme.typography.bodySmall)
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(accounts) { acc ->
        val isDebit = acc.category == "أصول" || acc.category == "مصروفات"
        Surface(
          color = MaterialTheme.colorScheme.surface,
          shape = RoundedCornerShape(8.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(text = "${acc.accountCode} - ${acc.accountName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
              Text(text = "النوع: ${acc.category} (${acc.accountType})", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
              Text(
                text = if (isDebit) "${viewModel.formatMoney(acc.currentBalance)} (مدين)" else "-",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = if (isDebit) Color(0xFF2E7D32) else Color.Gray
              )
              Text(
                text = if (!isDebit) "${viewModel.formatMoney(acc.currentBalance)} (دائن)" else "-",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = if (!isDebit) Color(0xFF1565C0) else Color.Gray
              )
            }
          }
        }
      }
    }
  }
}
