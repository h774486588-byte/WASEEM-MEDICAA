package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter

@Composable
fun AuditLogScreen(viewModel: ClinicViewModel) {
  val logs by viewModel.auditLogs.collectAsState()
  var searchQuery by remember { mutableStateOf("") }

  val filteredLogs = logs.filter { log ->
    searchQuery.isEmpty() ||
      log.username.contains(searchQuery, ignoreCase = true) ||
      log.action.contains(searchQuery, ignoreCase = true) ||
      log.targetEntity.contains(searchQuery, ignoreCase = true) ||
      log.entityId.contains(searchQuery, ignoreCase = true)
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
  ) {
    // Header
    Surface(
      color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "سجل العمليات والتدقيق غير القابل للتعديل (Audit Log)",
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
          )
          Text(
            text = "يوثق النظام آلياً هوية المستخدم والتوقيت والقيمة السابقة والجديدة لأي عملية حساسة.",
            style = MaterialTheme.typography.labelSmall,
            color = Color.DarkGray
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    OutlinedTextField(
      value = searchQuery,
      onValueChange = { searchQuery = it },
      label = { Text("بحث في سجل التدقيق (المستخدم، الإجراء، الكيان)") },
      leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
      modifier = Modifier.fillMaxWidth(),
      singleLine = true
    )

    Spacer(modifier = Modifier.height(12.dp))

    if (filteredLogs.isEmpty()) {
      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth(),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("لا توجد سجلات تدقيق مسجلة حتى الآن", color = Color.Gray)
        }
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(filteredLogs) { log ->
          AuditLogItemCard(log = log)
        }
      }
    }

    DeveloperFooter()
  }
}

@Composable
private fun AuditLogItemCard(log: AuditLog) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = log.userRole,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary),
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = log.username,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodyMedium
          )
        }
        Text(
          text = log.dateFormatted.ifEmpty { "اليوم" },
          style = MaterialTheme.typography.labelSmall,
          color = Color.Gray
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Security, contentDescription = null, tint = Color.DarkGray, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "${log.action} | الهدف: ${log.targetEntity} [${log.entityId}]",
          fontWeight = FontWeight.SemiBold,
          style = MaterialTheme.typography.bodySmall
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(8.dp)) {
          Text(
            text = "القيمة السابقة: ${log.oldValue}",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFFC62828)
          )
          Text(
            text = "القيمة الجديدة: ${log.newValue}",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF2E7D32)
          )
        }
      }
    }
  }
}
