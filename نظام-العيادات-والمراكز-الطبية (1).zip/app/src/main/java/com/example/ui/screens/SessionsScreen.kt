package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter
import com.example.ui.StatusBadge
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionsScreen(
  viewModel: ClinicViewModel,
  onOpenPatient: (Long) -> Unit
) {
  val sessions by viewModel.clinicalSessions.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val doctors by viewModel.medicalStaff.collectAsState()
  val packages by viewModel.patientPackages.collectAsState()

  var showAddDialog by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedStatusFilter by remember { mutableStateOf("الكل") }

  val filteredSessions = sessions.filter { s ->
    val matchQuery = searchQuery.isEmpty() ||
      s.patientName.contains(searchQuery, ignoreCase = true) ||
      s.doctorName.contains(searchQuery, ignoreCase = true) ||
      s.packageName.contains(searchQuery, ignoreCase = true)
    val matchStatus = selectedStatusFilter == "الكل" || s.status == selectedStatusFilter
    matchQuery && matchStatus
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = MaterialTheme.colorScheme.primary
      ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Add, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text("تسجيل جلسة علاجية")
        }
      }
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(16.dp)
    ) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        label = { Text("بحث في الجلسات (المريض، الطبيب، الباقة)") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("الكل", "مكتملة", "جارية", "مجدولة").forEach { st ->
          FilterChip(
            selected = selectedStatusFilter == st,
            onClick = { selectedStatusFilter = st },
            label = { Text(st) }
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (filteredSessions.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("لا توجد جلسات مسجلة مطابقة للبحث", color = Color.Gray)
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(filteredSessions) { session ->
            SessionItemCard(
              session = session,
              onOpenPatient = { onOpenPatient(session.patientId) }
            )
          }
        }
      }

      DeveloperFooter()
    }
  }

  if (showAddDialog) {
    AddClinicalSessionDialog(
      patients = patients,
      doctors = doctors,
      packages = packages,
      onDismiss = { showAddDialog = false },
      onSave = { pid, pname, docId, docName, pkgId, pkgName, sNum, date, inTime, outTime, status, notes ->
        viewModel.registerClinicalSession(
          patientId = pid,
          patientName = pname,
          doctorId = docId,
          doctorName = docName,
          packageId = pkgId,
          packageName = pkgName,
          caseId = null,
          sessionNumber = sNum,
          date = date,
          checkInTime = inTime,
          checkOutTime = outTime,
          status = status,
          notes = notes
        )
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun SessionItemCard(
  session: ClinicalSession,
  onOpenPatient: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = session.sessionCode,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "الجلسة رقم: ${session.sessionNumber}",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
        StatusBadge(status = session.status)
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "المريض: ${session.patientName}",
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "الأخصائي / الطبيب: ${session.doctorName}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "الباقة: ${session.packageName}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "التاريخ: ${session.sessionDate}",
          style = MaterialTheme.typography.labelSmall,
          color = Color.Gray
        )
        Text(
          text = "الوقت: ${session.checkInTime} إلى ${session.checkOutTime}",
          style = MaterialTheme.typography.labelSmall,
          color = Color.Gray
        )
      }

      if (session.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "ملاحظات وتطور الحالة: ${session.notes}",
          style = MaterialTheme.typography.bodySmall,
          color = Color.DarkGray
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        TextButton(onClick = onOpenPatient) {
          Icon(Icons.Default.AccountBox, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("ملف المريض")
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddClinicalSessionDialog(
  patients: List<Patient>,
  doctors: List<MedicalStaff>,
  packages: List<PatientPackage>,
  onDismiss: () -> Unit,
  onSave: (Long, String, Long, String, Long?, String, Int, String, String, String, String, String) -> Unit
) {
  var selectedPatient by remember { mutableStateOf<Patient?>(patients.firstOrNull()) }
  var selectedDoctor by remember { mutableStateOf(doctors.firstOrNull()) }

  val patientPackages = remember(selectedPatient, packages) {
    packages.filter { it.patientId == selectedPatient?.id && it.status == "نشطة" }
  }
  var selectedPackage by remember { mutableStateOf<PatientPackage?>(patientPackages.firstOrNull()) }

  val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
  val currentTime = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }

  var sessionDate by remember { mutableStateOf(today) }
  var checkInTime by remember { mutableStateOf(currentTime) }
  var checkOutTime by remember { mutableStateOf("10:00") }
  var sessionNumber by remember { mutableStateOf((selectedPackage?.usedSessions ?: 0) + 1) }
  var status by remember { mutableStateOf("مكتملة") }
  var notes by remember { mutableStateOf("") }

  var expandedPatient by remember { mutableStateOf(false) }
  var expandedDoc by remember { mutableStateOf(false) }
  var expandedPkg by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Text(
          text = "تسجيل جلسة علاجية وخصم الباقة",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Patient
        ExposedDropdownMenuBox(
          expanded = expandedPatient,
          onExpandedChange = { expandedPatient = !expandedPatient }
        ) {
          OutlinedTextField(
            value = selectedPatient?.fullName ?: "اختر المريض",
            onValueChange = {},
            readOnly = true,
            label = { Text("المريض *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPatient) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expandedPatient,
            onDismissRequest = { expandedPatient = false }
          ) {
            patients.forEach { p ->
              DropdownMenuItem(
                text = { Text("${p.fullName} (${p.patientCode})") },
                onClick = {
                  selectedPatient = p
                  expandedPatient = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Package selection
        ExposedDropdownMenuBox(
          expanded = expandedPkg,
          onExpandedChange = { expandedPkg = !expandedPkg }
        ) {
          OutlinedTextField(
            value = selectedPackage?.let { "${it.packageName} (متبقي: ${it.remainingSessions})" } ?: "جلسة فردية (بدون باقة)",
            onValueChange = {},
            readOnly = true,
            label = { Text("الباقة العلاجية للخصم") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPkg) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expandedPkg,
            onDismissRequest = { expandedPkg = false }
          ) {
            DropdownMenuItem(
              text = { Text("جلسة فردية (بدون باقة)") },
              onClick = {
                selectedPackage = null
                expandedPkg = false
              }
            )
            patientPackages.forEach { pkg ->
              DropdownMenuItem(
                text = { Text("${pkg.packageName} (المتبقي: ${pkg.remainingSessions} جلسة)") },
                onClick = {
                  selectedPackage = pkg
                  sessionNumber = pkg.usedSessions + 1
                  expandedPkg = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Doctor
        ExposedDropdownMenuBox(
          expanded = expandedDoc,
          onExpandedChange = { expandedDoc = !expandedDoc }
        ) {
          OutlinedTextField(
            value = selectedDoctor?.name ?: "اختر الطبيب / الأخصائي",
            onValueChange = {},
            readOnly = true,
            label = { Text("الطبيب / الأخصائي *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDoc) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expandedDoc,
            onDismissRequest = { expandedDoc = false }
          ) {
            doctors.forEach { d ->
              DropdownMenuItem(
                text = { Text(d.name) },
                onClick = {
                  selectedDoctor = d
                  expandedDoc = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Status
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("مكتملة", "جارية", "مجدولة").forEach { st ->
            FilterChip(
              selected = status == st,
              onClick = { status = st },
              label = { Text(st) }
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات الجلسة وتطور الاستجابة") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (selectedPatient != null && selectedDoctor != null) {
                onSave(
                  selectedPatient!!.id,
                  selectedPatient!!.fullName,
                  selectedDoctor!!.id,
                  selectedDoctor!!.name,
                  selectedPackage?.id,
                  selectedPackage?.packageName ?: "جلسة فردية",
                  sessionNumber,
                  sessionDate,
                  checkInTime,
                  checkOutTime,
                  status,
                  notes
                )
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("تأكيد وحفظ الجلسة")
          }
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
