package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.ui.ClinicScreen
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PatientsScreen(
  viewModel: ClinicViewModel,
  onNavigate: (ClinicScreen) -> Unit,
  onOpenPatient: (Long) -> Unit
) {
  val context = LocalContext.current
  val patients by viewModel.patients.collectAsState()
  val patientPackages by viewModel.patientPackages.collectAsState()
  val appointments by viewModel.appointments.collectAsState()
  val departments by viewModel.departments.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var query by remember { mutableStateOf("") }
  var selectedDeptFilter by remember { mutableStateOf<Long?>(null) }
  var filterActivePackagesOnly by remember { mutableStateOf(false) }

  // Filtered patients
  val filteredPatients = remember(query, selectedDeptFilter, filterActivePackagesOnly, patients, patientPackages) {
    patients.filter { p ->
      val matchesQuery = query.isBlank() ||
          p.fullName.contains(query, ignoreCase = true) ||
          p.phone.contains(query) ||
          p.patientCode.contains(query, ignoreCase = true)

      val matchesDept = selectedDeptFilter == null || p.departmentId == selectedDeptFilter

      val matchesActivePkg = !filterActivePackagesOnly || patientPackages.any {
        it.patientId == p.id && it.remainingSessions > 0 && it.status == "نشطة"
      }

      matchesQuery && matchesDept && matchesActivePkg
    }
  }

  // Dashboard Stats
  val totalPatients = patients.size
  val activePatientsWithPackages = patients.count { p ->
    patientPackages.any { it.patientId == p.id && it.status == "نشطة" }
  }
  val patientsWithUpcomingAppointments = patients.count { p ->
    appointments.any { it.patientId == p.id && (it.status == "في الانتظار" || it.status == "مؤكد") }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header & Add Patient Button
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "إدارة وسجلات المرضى",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "متابعة الملفات الطبية، كشوف الحساب، والمراسلات",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(
          onClick = { onNavigate(ClinicScreen.NEW_PATIENT) },
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("حالة جديدة")
        }
      }
    }

    // Dashboard Stats Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        PatientStatCard(
          title = "إجمالي المرضى",
          value = "$totalPatients",
          color = MaterialTheme.colorScheme.primary,
          modifier = Modifier.weight(1f)
        )
        PatientStatCard(
          title = "باقات جارية",
          value = "$activePatientsWithPackages",
          color = Color(0xFF0284C7),
          modifier = Modifier.weight(1f)
        )
        PatientStatCard(
          title = "مواعيد نشطة",
          value = "$patientsWithUpcomingAppointments",
          color = Color(0xFF16A34A),
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Search Bar
    item {
      OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        placeholder = { Text("بحث بالاسم، رقم الملف (P-1001)، أو الجوال...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
          if (query.isNotEmpty()) {
            IconButton(onClick = { query = "" }) {
              Icon(Icons.Default.Close, contentDescription = "مسح")
            }
          }
        },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
      )
    }

    // Filter Chips: All, Active Packages, and by Department
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        FilterChip(
          selected = selectedDeptFilter == null && !filterActivePackagesOnly,
          onClick = {
            selectedDeptFilter = null
            filterActivePackagesOnly = false
          },
          label = { Text("الكل") }
        )
        FilterChip(
          selected = filterActivePackagesOnly,
          onClick = { filterActivePackagesOnly = !filterActivePackagesOnly },
          label = { Text("باقات نشطة فقط") }
        )
        departments.take(3).forEach { d ->
          FilterChip(
            selected = selectedDeptFilter == d.id,
            onClick = {
              selectedDeptFilter = if (selectedDeptFilter == d.id) null else d.id
            },
            label = { Text(d.name) }
          )
        }
      }
    }

    // Patients List
    items(filteredPatients) { p ->
      val pActivePkg = patientPackages.find { it.patientId == p.id && it.status == "نشطة" }
      val pDept = departments.find { it.id == p.departmentId }

      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = p.patientCode,
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = p.fullName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
            }

            // Gender badge
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "${p.gender} | ${p.age} سنة",
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "📱 ${p.phone} | 📍 ${p.address.ifEmpty { "المدينة" }}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          if (pDept != null) {
            Text(
              text = "🏥 القسم المسجل: ${pDept.name}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary
            )
          }

          if (pActivePkg != null) {
            Surface(
              color = Color(0xFFDCFCE7),
              shape = RoundedCornerShape(6.dp),
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
            ) {
              Text(
                text = "✨ باقة جارية: ${pActivePkg.packageName} (متبقي: ${pActivePkg.remainingSessions} جلسة)",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = Color(0xFF166534)
                ),
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
              )
            }
          }

          Divider(modifier = Modifier.padding(vertical = 8.dp))

          // Action Buttons Bar
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            // Open File
            Button(
              onClick = { onOpenPatient(p.id) },
              modifier = Modifier.weight(1.2f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("فتح الملف")
            }

            // Quick Book
            OutlinedButton(
              onClick = { onNavigate(ClinicScreen.APPOINTMENTS) },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(2.dp))
              Text("موعد")
            }

            // Quick Receipt
            OutlinedButton(
              onClick = { onNavigate(ClinicScreen.FINANCE) },
              modifier = Modifier.weight(1f),
              shape = RoundedCornerShape(8.dp),
              contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
            ) {
              Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(2.dp))
              Text("سند")
            }

            // WhatsApp button
            IconButton(
              onClick = {
                val msg = "مرحباً ${p.fullName} 🌸، نود التواصل معكم من ${centerProfile?.facilityName ?: "المركز الطبي"}. هل هناك أي استفسار نساعدكم به؟"
                viewModel.sendWhatsApp(context, p.phone, msg)
              },
              modifier = Modifier.size(36.dp)
            ) {
              Icon(Icons.Default.Share, contentDescription = "واتساب", tint = Color(0xFF25D366))
            }
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

@Composable
private fun PatientStatCard(
  title: String,
  value: String,
  color: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = color.copy(alpha = 0.12f),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = color)
      )
      Text(
        text = title,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold, color = color)
      )
    }
  }
}
