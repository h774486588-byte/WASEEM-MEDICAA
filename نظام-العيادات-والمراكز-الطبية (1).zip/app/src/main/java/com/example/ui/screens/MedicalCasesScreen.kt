package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.ClinicViewModel
import com.example.ui.DeveloperFooter
import com.example.ui.StatusBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicalCasesScreen(
  viewModel: ClinicViewModel,
  onOpenPatient: (Long) -> Unit
) {
  val cases by viewModel.medicalCases.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val doctors by viewModel.medicalStaff.collectAsState()
  val departments by viewModel.departments.collectAsState()
  val services by viewModel.services.collectAsState()

  var showAddDialog by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedStatusFilter by remember { mutableStateOf("الكل") }

  val filteredCases = cases.filter { case ->
    val matchQuery = searchQuery.isEmpty() ||
      case.patientName.contains(searchQuery, ignoreCase = true) ||
      case.title.contains(searchQuery, ignoreCase = true) ||
      case.doctorName.contains(searchQuery, ignoreCase = true)
    val matchStatus = selectedStatusFilter == "الكل" || case.status == selectedStatusFilter
    matchQuery && matchStatus
  }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showAddDialog = true },
        containerColor = MaterialTheme.colorScheme.primary
      ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Add, contentDescription = null)
          Spacer(modifier = Modifier.width(6.dp))
          Text("تسجيل حالة مرضية جديدة")
        }
      }
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .padding(16.dp)
    ) {
      // Search and Filter Header
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        label = { Text("بحث عن حالة (اسم المريض، التشخيص، الطبيب)") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Status Filter Chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("الكل", "نشطة", "مكتملة", "سابقة").forEach { st ->
          FilterChip(
            selected = selectedStatusFilter == st,
            onClick = { selectedStatusFilter = st },
            label = { Text(st) }
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (filteredCases.isEmpty()) {
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Sick, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("لا توجد حالات مرضية مسجلة مطابقة للبحث", color = Color.Gray)
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          items(filteredCases) { c ->
            MedicalCaseCard(
              case = c,
              onOpenPatient = { onOpenPatient(c.patientId) }
            )
          }
        }
      }

      DeveloperFooter()
    }
  }

  if (showAddDialog) {
    AddMedicalCaseDialog(
      patients = patients,
      doctors = doctors,
      departments = departments,
      services = services,
      onDismiss = { showAddDialog = false },
      onSave = { pid, pname, title, docId, docName, deptId, deptName, srvId, srvName, status, notes, attach ->
        viewModel.addMedicalCase(
          patientId = pid,
          patientName = pname,
          title = title,
          doctorId = docId,
          doctorName = docName,
          departmentId = deptId,
          departmentName = deptName,
          serviceId = srvId,
          serviceName = srvName,
          status = status,
          notes = notes,
          attachments = attach
        )
        showAddDialog = false
      }
    )
  }
}

@Composable
private fun MedicalCaseCard(
  case: MedicalCase,
  onOpenPatient: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = case.caseCode,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = case.title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
        }
        StatusBadge(status = case.status)
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "المريض: ${case.patientName}",
        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "الطبيب: ${case.doctorName}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
          text = "القسم: ${case.departmentName}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      if (case.serviceName.isNotBlank()) {
        Text(
          text = "الخدمة الطبية: ${case.serviceName}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary
        )
      }

      if (case.notes.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "الملاحظات والتشخيص: ${case.notes}",
          style = MaterialTheme.typography.bodySmall,
          color = Color.DarkGray
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "تاريخ التسجيل: ${case.registrationDate}",
          style = MaterialTheme.typography.labelSmall,
          color = Color.Gray
        )
        TextButton(onClick = onOpenPatient) {
          Icon(Icons.Default.AccountBox, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("فتح ملف المريض")
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddMedicalCaseDialog(
  patients: List<Patient>,
  doctors: List<MedicalStaff>,
  departments: List<Department>,
  services: List<MedicalService>,
  onDismiss: () -> Unit,
  onSave: (Long, String, String, Long, String, Long, String, Long, String, String, String, String) -> Unit
) {
  var selectedPatient by remember { mutableStateOf<Patient?>(patients.firstOrNull()) }
  var title by remember { mutableStateOf("") }
  var selectedDept by remember { mutableStateOf(departments.firstOrNull()) }
  var selectedDoctor by remember { mutableStateOf(doctors.firstOrNull()) }
  var selectedService by remember { mutableStateOf(services.firstOrNull()) }
  var status by remember { mutableStateOf("نشطة") }
  var notes by remember { mutableStateOf("") }
  var attachments by remember { mutableStateOf("لا توجد مرفقات") }

  var expandedPatient by remember { mutableStateOf(false) }
  var expandedDept by remember { mutableStateOf(false) }
  var expandedDoc by remember { mutableStateOf(false) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Text(
          text = "تسجيل حالة مرضية جديدة",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Patient Picker
        ExposedDropdownMenuBox(
          expanded = expandedPatient,
          onExpandedChange = { expandedPatient = !expandedPatient }
        ) {
          OutlinedTextField(
            value = selectedPatient?.fullName ?: "اختر المريض",
            onValueChange = {},
            readOnly = true,
            label = { Text("المريض *") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedPatient) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = expandedPatient,
            onDismissRequest = { expandedPatient = false }
          ) {
            patients.forEach { p ->
              DropdownMenuItem(
                text = { Text("${p.fullName} (${p.patientCode})") },
                onClick = {
                  selectedPatient = p
                  expandedPatient = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("التشخيص / عنوان الحالة *") },
          placeholder = { Text("مثال: انزلاق غضروفي قطني، تمزق رباط...") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Department & Doctor
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          ExposedDropdownMenuBox(
            expanded = expandedDept,
            onExpandedChange = { expandedDept = !expandedDept },
            modifier = Modifier.weight(1f)
          ) {
            OutlinedTextField(
              value = selectedDept?.name ?: "القسم",
              onValueChange = {},
              readOnly = true,
              label = { Text("القسم") },
              modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = expandedDept,
              onDismissRequest = { expandedDept = false }
            ) {
              departments.forEach { d ->
                DropdownMenuItem(
                  text = { Text(d.name) },
                  onClick = {
                    selectedDept = d
                    expandedDept = false
                  }
                )
              }
            }
          }

          ExposedDropdownMenuBox(
            expanded = expandedDoc,
            onExpandedChange = { expandedDoc = !expandedDoc },
            modifier = Modifier.weight(1f)
          ) {
            OutlinedTextField(
              value = selectedDoctor?.name ?: "الطبيب",
              onValueChange = {},
              readOnly = true,
              label = { Text("الطبيب") },
              modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(
              expanded = expandedDoc,
              onDismissRequest = { expandedDoc = false }
            ) {
              doctors.forEach { doc ->
                DropdownMenuItem(
                  text = { Text(doc.name) },
                  onClick = {
                    selectedDoctor = doc
                    expandedDoc = false
                  }
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Status
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("نشطة", "مكتملة", "سابقة").forEach { st ->
            FilterChip(
              selected = status == st,
              onClick = { status = st },
              label = { Text(st) }
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("ملاحظات الفحص والتشخيص") },
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              if (selectedPatient != null && title.isNotBlank()) {
                onSave(
                  selectedPatient!!.id,
                  selectedPatient!!.fullName,
                  title,
                  selectedDoctor?.id ?: 0L,
                  selectedDoctor?.name ?: "عام",
                  selectedDept?.id ?: 0L,
                  selectedDept?.name ?: "عام",
                  selectedService?.id ?: 0L,
                  selectedService?.name ?: "كشف ومعاينة",
                  status,
                  notes,
                  attachments
                )
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الحالة")
          }
          OutlinedButton(
            onClick = onDismiss,
            modifier = Modifier.weight(1f)
          ) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
