package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PackagesScreen(
  viewModel: ClinicViewModel
) {
  val context = LocalContext.current
  val packageDefinitions by viewModel.packageDefinitions.collectAsState()
  val patientPackages by viewModel.patientPackages.collectAsState()
  val patients by viewModel.patients.collectAsState()
  val departments by viewModel.departments.collectAsState()
  val centerProfile by viewModel.centerProfile.collectAsState()

  var showCreatePkgDialog by remember { mutableStateOf(false) }
  var showAssignPkgDialog by remember { mutableStateOf(false) }

  // Low balance packages (remaining <= 2)
  val alertPackages = remember(patientPackages) {
    patientPackages.filter { it.remainingSessions in 1..2 && it.status == "نشطة" }
  }

  // Dialog to define new package
  if (showCreatePkgDialog) {
    CreatePackageDefDialog(
      departments = departments,
      onDismiss = { showCreatePkgDialog = false },
      onSave = { name, deptId, deptName, total, price, validity ->
        viewModel.createPackageDefinition(name, deptId, deptName, total, price, validity)
        showCreatePkgDialog = false
      }
    )
  }

  // Dialog to assign package to patient
  if (showAssignPkgDialog) {
    AssignPackageDialog(
      patients = patients,
      packageDefinitions = packageDefinitions,
      onDismiss = { showAssignPkgDialog = false },
      onAssign = { patientId, pkgDef ->
        viewModel.assignPackageToPatient(patientId, pkgDef)
        showAssignPkgDialog = false
      }
    )
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header & Actions
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "إدارة الجلسات والباقات العلاجية",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
          )
          Text(
            text = "خصم ذكي تلقائي مع تنبيهات نفاد الجلسات",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          OutlinedButton(
            onClick = { showCreatePkgDialog = true },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("تعريف باقة")
          }
          Button(
            onClick = { showAssignPkgDialog = true },
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("صرف باقة لمريض")
          }
        }
      }
    }

    // LOW SESSIONS ALERT BANNER
    if (alertPackages.isNotEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.NotificationImportant, contentDescription = null, tint = MaterialTheme.colorScheme.error)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "تنبيه اقتراب نفاد الجلسات (${alertPackages.size} باقة متبقي لها جلسة أو جلستان):",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onErrorContainer
                )
              )
            }
            Spacer(modifier = Modifier.height(8.dp))

            alertPackages.forEach { ap ->
              val patient = patients.find { it.id == ap.patientId }
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "${patient?.fullName ?: "مريض"} - ${ap.packageName}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onErrorContainer
                  )
                  Text(
                    text = "المتبقي: ${ap.remainingSessions} جلسة فقط (المستهلك: ${ap.usedSessions} من ${ap.totalSessions})",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f)
                  )
                }

                Button(
                  onClick = {
                    patient?.let { p ->
                      val msg = "عزيزنا المريض ${p.fullName} 🩺، نود إحاطتكم بأن باقتكم العلاجية لدى ${centerProfile?.facilityName} (${ap.packageName}) أوشكت على الانتهاء. الجلسات المتبقية: ${ap.remainingSessions} جلسة فقط. يرجى مراجعة الاستقبال لتجديد الباقة أو حجز المواعيد."
                      viewModel.sendWhatsApp(context, p.phone, msg)
                    }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                  contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                  Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("تنبيه واتساب", fontSize = 11.sp, color = Color.White)
                }
              }
            }
          }
        }
      }
    }

    // Active Patient Packages Header
    item {
      Text(
        text = "باقات المرضى المسجلة والنشطة:",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary
      )
    }

    if (patientPackages.isEmpty()) {
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "لا توجد باقات مفعلة للمرضى حالياً. اضغط على 'صرف باقة لمريض' لبدء باقة علاجية.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.outline
            )
          }
        }
      }
    } else {
      items(patientPackages) { pkg ->
        val patient = patients.find { it.id == pkg.patientId }
        val progress = if (pkg.totalSessions > 0) pkg.usedSessions.toFloat() / pkg.totalSessions.toFloat() else 0f

        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = pkg.packageName,
                  style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                  text = "المريض: ${patient?.fullName ?: "غير محدد"} (${patient?.patientCode ?: ""})",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary
                )
              }

              Surface(
                color = if (pkg.status == "نشطة") Color(0xFFDCFCE7) else Color(0xFFF3F4F6),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = pkg.status,
                  color = if (pkg.status == "نشطة") Color(0xFF166534) else Color(0xFF374151),
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress Bar of Sessions
            LinearProgressIndicator(
              progress = { progress },
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp),
              color = if (pkg.remainingSessions <= 2) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Stats row
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "الإجمالي: ${pkg.totalSessions} جلسات",
                style = MaterialTheme.typography.labelSmall
              )
              Text(
                text = "المستهلك: ${pkg.usedSessions}",
                style = MaterialTheme.typography.labelSmall,
                color = Color.DarkGray
              )
              Text(
                text = "المتبقي: ${pkg.remainingSessions}",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = if (pkg.remainingSessions <= 2) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
              )
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "📅 الشراء: ${pkg.purchaseDate} | الانتهاء: ${pkg.expiryDate}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
              )

              IconButton(
                onClick = {
                  patient?.let { p ->
                    val msg = "عزيزي ${p.fullName}، رصيدك في (${pkg.packageName}): المستهلك ${pkg.usedSessions}، المتبقي ${pkg.remainingSessions} جلسات. شكراً لثقتكم بـ ${centerProfile?.facilityName}."
                    viewModel.sendWhatsApp(context, p.phone, msg)
                  }
                },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(Icons.Default.Share, contentDescription = "مشاركة واتساب", tint = Color(0xFF25D366), modifier = Modifier.size(16.dp))
              }
            }
          }
        }
      }
    }

    // Available Package Templates Catalog
    item {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = "قائمة الباقات والخدمات المعرفة في المركز (${packageDefinitions.size}):",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.primary
      )
    }

    items(packageDefinitions) { pDef ->
      ElevatedCard(
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(pDef.name, fontWeight = FontWeight.Bold)
            Text(
              text = "القسم: ${pDef.departmentName} | الصلاحية: ${pDef.validityDays} يوم",
              style = MaterialTheme.typography.bodySmall
            )
            Text(
              text = "${pDef.totalSessions} جلسات بسعر: ${pDef.price} ر.ي",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary
            )
          }

          Button(
            onClick = {
              showAssignPkgDialog = true
            },
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Text("صرف للمريض")
          }
        }
      }
    }

    item {
      DeveloperFooter()
    }
  }
}

/**
 * Dialog to Define a new package type
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreatePackageDefDialog(
  departments: List<Department>,
  onDismiss: () -> Unit,
  onSave: (String, Long, String, Int, Double, Int) -> Unit
) {
  var name by remember { mutableStateOf("") }
  var selectedDeptId by remember { mutableStateOf(departments.firstOrNull()?.id ?: 1L) }
  var totalSessionsText by remember { mutableStateOf("10") }
  var priceText by remember { mutableStateOf("50000") }
  var validityDaysText by remember { mutableStateOf("60") }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = "إضافة باقة علاجية جديدة للعيادة",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم الباقة (مثال: باقة علاج طبيعي 10 جلسات)") },
          modifier = Modifier.fillMaxWidth()
        )

        // Department
        var deptExpanded by remember { mutableStateOf(false) }
        val selDept = departments.find { it.id == selectedDeptId }

        ExposedDropdownMenuBox(
          expanded = deptExpanded,
          onExpandedChange = { deptExpanded = !deptExpanded }
        ) {
          OutlinedTextField(
            value = selDept?.name ?: "اختر القسم",
            onValueChange = {},
            readOnly = true,
            label = { Text("القسم الطبي التابعة له") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = deptExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = deptExpanded,
            onDismissRequest = { deptExpanded = false }
          ) {
            departments.forEach { d ->
              DropdownMenuItem(
                text = { Text(d.name) },
                onClick = {
                  selectedDeptId = d.id
                  deptExpanded = false
                }
              )
            }
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = totalSessionsText,
            onValueChange = { totalSessionsText = it },
            label = { Text("عدد الجلسات") },
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = validityDaysText,
            onValueChange = { validityDaysText = it },
            label = { Text("الصلاحية (يوم)") },
            modifier = Modifier.weight(1f)
          )
        }

        OutlinedTextField(
          value = priceText,
          onValueChange = { priceText = it },
          label = { Text("السعر الإجمالي للباقة (ر.ي)") },
          modifier = Modifier.fillMaxWidth()
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val deptName = selDept?.name ?: "عام"
              val sessions = totalSessionsText.toIntOrNull() ?: 10
              val price = priceText.toDoubleOrNull() ?: 50000.0
              val validity = validityDaysText.toIntOrNull() ?: 60
              if (name.isNotBlank()) {
                onSave(name, selectedDeptId, deptName, sessions, price, validity)
              }
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("حفظ الباقة")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}

/**
 * Dialog to assign package to a patient
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssignPackageDialog(
  patients: List<Patient>,
  packageDefinitions: List<PackageDefinition>,
  onDismiss: () -> Unit,
  onAssign: (Long, PackageDefinition) -> Unit
) {
  var selectedPatientId by remember { mutableStateOf(patients.firstOrNull()?.id) }
  var selectedPkgDefId by remember { mutableStateOf(packageDefinitions.firstOrNull()?.id) }

  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surface,
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Text(
          text = "صرف باقة علاجية لمريض وإصدار سند قبض",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        // Patient Selector
        var pExpanded by remember { mutableStateOf(false) }
        val selPatient = patients.find { it.id == selectedPatientId }

        ExposedDropdownMenuBox(
          expanded = pExpanded,
          onExpandedChange = { pExpanded = !pExpanded }
        ) {
          OutlinedTextField(
            value = selPatient?.let { "${it.patientCode} - ${it.fullName}" } ?: "اختر المريض",
            onValueChange = {},
            readOnly = true,
            label = { Text("المريض المستفيد") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = pExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = pExpanded,
            onDismissRequest = { pExpanded = false }
          ) {
            patients.forEach { p ->
              DropdownMenuItem(
                text = { Text("${p.patientCode} - ${p.fullName}") },
                onClick = {
                  selectedPatientId = p.id
                  pExpanded = false
                }
              )
            }
          }
        }

        // Package Selector
        var pkgExpanded by remember { mutableStateOf(false) }
        val selPkg = packageDefinitions.find { it.id == selectedPkgDefId }

        ExposedDropdownMenuBox(
          expanded = pkgExpanded,
          onExpandedChange = { pkgExpanded = !pkgExpanded }
        ) {
          OutlinedTextField(
            value = selPkg?.let { "${it.name} (${it.price} ر.ي)" } ?: "اختر الباقة",
            onValueChange = {},
            readOnly = true,
            label = { Text("الباقة العلاجية") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = pkgExpanded) },
            modifier = Modifier
              .menuAnchor()
              .fillMaxWidth()
          )
          ExposedDropdownMenu(
            expanded = pkgExpanded,
            onDismissRequest = { pkgExpanded = false }
          ) {
            packageDefinitions.forEach { pd ->
              DropdownMenuItem(
                text = { Text("${pd.name} - ${pd.totalSessions} جلسات (${pd.price} ر.ي)") },
                onClick = {
                  selectedPkgDefId = pd.id
                  pkgExpanded = false
                }
              )
            }
          }
        }

        selPkg?.let { pd ->
          Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text("تفاصيل السداد وسند القبض:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
              Text("المبلغ المطلوب: ${pd.price} ر.ي", style = MaterialTheme.typography.bodySmall)
              Text("عدد الجلسات: ${pd.totalSessions} جلسات | الصلاحية: ${pd.validityDays} يوم", style = MaterialTheme.typography.bodySmall)
              Text("سيتم تقييد سند قبض آلي بالصندوق وتغذية رصيد المريض", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Button(
            onClick = {
              val pId = selectedPatientId ?: return@Button
              val pkg = selPkg ?: return@Button
              onAssign(pId, pkg)
            },
            modifier = Modifier.weight(1f)
          ) {
            Text("تأكيد وصرف الباقة")
          }
          OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
            Text("إلغاء")
          }
        }
      }
    }
  }
}
