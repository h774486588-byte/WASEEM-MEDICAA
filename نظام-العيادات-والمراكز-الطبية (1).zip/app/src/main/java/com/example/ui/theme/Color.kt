package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// WASEEM MEDICAL PRO Official Palette
val WaseemBluePrimary = Color(0xFF0D5CAB)
val WaseemBlueDark = Color(0xFF094685)
val WaseemBlueLight = Color(0xFF1976D2)
val WaseemBlueContainer = Color(0xFFD6E4FF)
val WaseemOnBlueContainer = Color(0xFF001A41)

val WaseemGreenAccent = Color(0xFF10B981)
val WaseemGreenRing = Color(0xFF059669)

val MedicalBackground = Color(0xFFF4F7FC)
val MedicalSurface = Color(0xFFFFFFFF)
val MedicalSurfaceVariant = Color(0xFFEAEFF8)
val MedicalOutline = Color(0xFF70797A)
val MedicalOutlineVariant = Color(0xFFD2DCE8)

// Legacy alias for compatibility
val MedicalTealPrimary = WaseemBluePrimary
val MedicalTealOnPrimary = Color.White
val MedicalTealContainer = WaseemBlueContainer
val MedicalTealOnContainer = WaseemOnBlueContainer

val MedicalSlateSecondary = Color(0xFF3B5266)
val MedicalSlateContainer = Color(0xFFD7E3EC)
val MedicalSlateOnContainer = Color(0xFF0A1E2B)

val MedicalBlueTertiary = Color(0xFF0284C7)
val MedicalBlueContainer = Color(0xFFBAE6FD)
val MedicalBlueOnContainer = Color(0xFF001E30)

val MedicalDarkBackground = Color(0xFF0A1118)
val MedicalDarkSurface = Color(0xFF121B24)
val MedicalDarkSurfaceVariant = Color(0xFF1E293B)
val MedicalDarkPrimary = Color(0xFF60A5FA)
val MedicalDarkSecondary = Color(0xFF94A3B8)

// Status colors
val StatusWaiting = Color(0xFFD97706)
val StatusWaitingBg = Color(0xFFFEF3C7)
val StatusAttended = Color(0xFF059669)
val StatusAttendedBg = Color(0xFFD1FAE5)
val StatusConfirmed = Color(0xFF2563EB)
val StatusConfirmedBg = Color(0xFFDBEAFE)
val StatusNoShow = Color(0xFFDC2626)
val StatusNoShowBg = Color(0xFFFEE2E2)
val StatusCancelled = Color(0xFF64748B)
val StatusCancelledBg = Color(0xFFF1F5F9)
val StatusCompleted = Color(0xFF0D9488)
val StatusCompletedBg = Color(0xFFCCFBF1)

// KPI Card Color Schemes
val KpiPinkBg = Color(0xFFFDE8E8)
val KpiPinkIcon = Color(0xFFEF4444)
val KpiPurpleBg = Color(0xFFF3E8FF)
val KpiPurpleIcon = Color(0xFF8B5CF6)
val KpiGreenBg = Color(0xFFE6F9F0)
val KpiGreenIcon = Color(0xFF10B981)
val KpiBlueBg = Color(0xFFE1F0FE)
val KpiBlueIcon = Color(0xFF2563EB)
val KpiOrangeBg = Color(0xFFFFF4E5)
val KpiOrangeIcon = Color(0xFFF59E0B)

// Service Squircles (Waseem Medical Pro Grid)
val ServiceDoctorColor = Color(0xFFEF4444)
val ServicePackageColor = Color(0xFFF97316)
val ServiceSessionColor = Color(0xFF10B981)
val ServiceAppointmentColor = Color(0xFF2563EB)
val ServicePatientColor = Color(0xFF6366F1)
val ServiceMoreColor = Color(0xFFEC4899)
val ServiceSettingsColor = Color(0xFF64748B)
val ServiceReportsColor = Color(0xFF7C3AED)
val ServiceInventoryColor = Color(0xFF06B6D4)
val ServiceAccountsColor = Color(0xFF0EA5E9)
