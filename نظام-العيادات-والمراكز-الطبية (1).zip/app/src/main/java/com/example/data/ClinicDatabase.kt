package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
  entities = [
    CenterProfile::class,
    Department::class,
    MedicalService::class,
    MedicalStaff::class,
    GeneralStaff::class,
    Patient::class,
    MedicalCase::class,
    Appointment::class,
    PackageDefinition::class,
    PatientPackage::class,
    ClinicalSession::class,
    PatientTimeline::class,
    FinanceTransaction::class,
    ChartOfAccount::class,
    AppNotification::class,
    AppUser::class,
    AuditLog::class,
    MessageTemplate::class
  ],
  version = 2,
  exportSchema = false
)
abstract class ClinicDatabase : RoomDatabase() {
  abstract fun clinicDao(): ClinicDao

  companion object {
    @Volatile
    private var INSTANCE: ClinicDatabase? = null

    fun getDatabase(context: Context, scope: CoroutineScope): ClinicDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          ClinicDatabase::class.java,
          "waseem_clinic_database.db"
        )
          .addCallback(ClinicDatabaseCallback(scope))
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }

    suspend fun checkAndPopulateIfEmpty(dao: ClinicDao) {
      try {
        if (dao.getCenterProfile() == null) {
          populateInitialData(dao)
        }
      } catch (e: Exception) {
        android.util.Log.e("ClinicDatabase", "Database initialization note", e)
      }
    }

    private class ClinicDatabaseCallback(
      private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
      override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        INSTANCE?.let { database ->
          scope.launch(Dispatchers.IO) {
            populateInitialData(database.clinicDao())
          }
        }
      }
    }

    private suspend fun populateInitialData(dao: ClinicDao) {
      // Center Profile
      dao.saveCenterProfile(
        CenterProfile(
          id = 1,
          facilityName = "مجمع الشفاء الطبي التخصصي",
          facilityType = "مركز طبي",
          address = "الشارع العام - برج الأمل الطبي",
          phone1 = "774486588",
          phone2 = "01-445566",
          doctorInCharge = "د. وسيم الفرح",
          commercialRecord = "CR-2024-8891",
          headerNotes = "أحدث الأجهزة التشخيصية والعلاجية ونخبة من الأطباء الاستشاريين",
          footerNotes = "تطوير: وسيم الفرح | هاتف: 774486588",
          isConfigured = true,
          currencySymbol = "ر.ي",
          trialDaysRemaining = 28,
          isLicenseActive = false
        )
      )

      // App Users & Permissions (المستخدمون والصلاحيات)
      dao.insertUser(AppUser(username = "admin", fullName = "المدير العام (وسيم الفرح)", role = "المدير", pinCode = "1234"))
      dao.insertUser(AppUser(username = "reception", fullName = "ماجد القدسي", role = "الاستقبال", pinCode = "1111"))
      dao.insertUser(AppUser(username = "accountant", fullName = "فاطمة البعداني", role = "المحاسب", pinCode = "2222"))
      dao.insertUser(AppUser(username = "doctor_waseem", fullName = "د. وسيم الفرح", role = "الطبيب", pinCode = "3333"))
      dao.insertUser(AppUser(username = "sessions_clerk", fullName = "عادل العديني", role = "موظف الجلسات", pinCode = "4444"))

      // Chart of Accounts (دليل الحسابات - القيد المزدوج)
      dao.insertAccount(ChartOfAccount(accountCode = "10101", accountName = "الصندوق الرئيسي (نقدية)", category = "أصول", accountType = "صندوق", currentBalance = 150000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "10102", accountName = "حساب بنك الكريمي للتمويل", category = "أصول", accountType = "بنك", currentBalance = 450000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "10103", accountName = "شبكة نقاط البيع الإلكترونية", category = "أصول", accountType = "بنك", currentBalance = 85000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "10201", accountName = "حسابات ذمم المرضى والعملاء", category = "أصول", accountType = "مرضى", currentBalance = 30000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "20101", accountName = "مستحقات وأمانات الأطباء", category = "التزامات", accountType = "أطباء", currentBalance = 111000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "20102", accountName = "مستحقات الموظفين والرواتب المعلقة", category = "التزامات", accountType = "موظفون", currentBalance = 0.0))
      dao.insertAccount(ChartOfAccount(accountCode = "20103", accountName = "مستحقات الموردين ومستلزمات العيادة", category = "التزامات", accountType = "موردون", currentBalance = 25000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "30101", accountName = "رأس مال المركز الطبي", category = "حقوق ملكية", accountType = "حقوق ملكية", currentBalance = 1000000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "40101", accountName = "إيرادات كشوفات ومعاينات العيادات", category = "إيرادات", accountType = "إيراد خدمات", currentBalance = 240000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "40102", accountName = "إيرادات باقات العلاج الطبيعي والتأهيل", category = "إيرادات", accountType = "إيراد خدمات", currentBalance = 160000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "40103", accountName = "إيرادات خدمات الليزر والتجميل", category = "إيرادات", accountType = "إيراد خدمات", currentBalance = 120000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "50101", accountName = "مصروفات رواتب وأجور الكادر", category = "مصروفات", accountType = "مصروف رواتب", currentBalance = 280000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "50102", accountName = "مصروفات مستلزمات طبية وأدوية", category = "مصروفات", accountType = "مصروفات تشغيلية", currentBalance = 45000.0))
      dao.insertAccount(ChartOfAccount(accountCode = "50103", accountName = "مصروفات إيجار وكهرباء وخدمات", category = "مصروفات", accountType = "مصروفات تشغيلية", currentBalance = 60000.0))

      // Departments
      val dentalId = dao.insertDepartment(Department(name = "قسم الأسنان وجراحة الفم", iconName = "dental", sortOrder = 1))
      val physioId = dao.insertDepartment(Department(name = "قسم العلاج الطبيعي والتأهيل", iconName = "physio", sortOrder = 2))
      val dermaId = dao.insertDepartment(Department(name = "قسم الجلدية والتجميل والليزر", iconName = "derma", sortOrder = 3))
      val eyeId = dao.insertDepartment(Department(name = "قسم العيون والبصريات", iconName = "eye", sortOrder = 4))
      val pediaId = dao.insertDepartment(Department(name = "قسم طب الأطفال", iconName = "pedia", sortOrder = 5))
      val internalId = dao.insertDepartment(Department(name = "قسم الباطنية والقلب", iconName = "internal", sortOrder = 6))
      val labId = dao.insertDepartment(Department(name = "قسم المختبر والتحاليل الطبية", iconName = "lab", sortOrder = 7))

      // Medical Services
      dao.insertService(MedicalService(departmentId = dentalId, name = "كشفية واستشارة أسنان", defaultPrice = 3000.0, doctorSharePercent = 50.0, durationMinutes = 20))
      dao.insertService(MedicalService(departmentId = dentalId, name = "تنظيف وتلميع أسنان شامل", defaultPrice = 12000.0, doctorSharePercent = 35.0, durationMinutes = 30))
      dao.insertService(MedicalService(departmentId = dentalId, name = "حشو تجميلي ليزري", defaultPrice = 18000.0, doctorSharePercent = 40.0, durationMinutes = 45))
      dao.insertService(MedicalService(departmentId = dentalId, name = "علاج عصب وسحب جذور", defaultPrice = 25000.0, doctorSharePercent = 40.0, durationMinutes = 60))

      dao.insertService(MedicalService(departmentId = physioId, name = "جلسة علاج طبيعي ظهر وفقرات", defaultPrice = 10000.0, doctorSharePercent = 30.0, durationMinutes = 45))
      dao.insertService(MedicalService(departmentId = physioId, name = "جلسة تأهيل وإعادة حركة", defaultPrice = 8000.0, doctorSharePercent = 30.0, durationMinutes = 40))
      dao.insertService(MedicalService(departmentId = physioId, name = "جلسة ليزر علاجي وأمواج تصادمية", defaultPrice = 15000.0, doctorSharePercent = 35.0, durationMinutes = 30))

      dao.insertService(MedicalService(departmentId = dermaId, name = "جلسة ليزر كربوني ونضارة", defaultPrice = 20000.0, doctorSharePercent = 35.0, durationMinutes = 40))
      dao.insertService(MedicalService(departmentId = dermaId, name = "جلسة تنظيف بشرة هيدرافيشل", defaultPrice = 15000.0, doctorSharePercent = 30.0, durationMinutes = 45))

      dao.insertService(MedicalService(departmentId = eyeId, name = "فحص النظر وقاع العين", defaultPrice = 7000.0, doctorSharePercent = 40.0, durationMinutes = 25))
      dao.insertService(MedicalService(departmentId = pediaId, name = "معاينة ومتابعة نمو أطفال", defaultPrice = 5000.0, doctorSharePercent = 50.0, durationMinutes = 20))
      dao.insertService(MedicalService(departmentId = internalId, name = "كشف باطنية مع تخطيط قلب ECG", defaultPrice = 9000.0, doctorSharePercent = 45.0, durationMinutes = 30))
      dao.insertService(MedicalService(departmentId = labId, name = "باقة تحاليل شاملة CBC + Lipid + Sugar", defaultPrice = 18000.0, doctorSharePercent = 20.0, durationMinutes = 15))

      // Medical Staff (Doctors & Specialists)
      val doc1 = dao.insertMedicalStaff(
        MedicalStaff(
          name = "د. وسيم الفرح",
          role = "طبيب استشاري",
          specialty = "جراحة وتجميل الأسنان",
          departmentId = dentalId,
          phone = "774486588",
          qualification = "بورد في جراحة وزراعة الأسنان",
          contractType = "نسبة",
          sharePercent = 40.0,
          balanceDues = 48000.0,
          workDays = "السبت - الخميس",
          workHours = "09:00 - 18:00"
        )
      )
      val doc2 = dao.insertMedicalStaff(
        MedicalStaff(
          name = "د. أحمد المنصوري",
          role = "طبيب أخصائي",
          specialty = "العلاج الطبيعي والتأهيل الحركي",
          departmentId = physioId,
          phone = "771234567",
          qualification = "ماجستير تأهيل عصبي وحركي",
          contractType = "نسبة",
          sharePercent = 35.0,
          balanceDues = 28000.0,
          workDays = "السبت - الأربعاء",
          workHours = "10:00 - 17:00"
        )
      )
      val doc3 = dao.insertMedicalStaff(
        MedicalStaff(
          name = "د. سارة الكندي",
          role = "طبيبة أخصائية",
          specialty = "الجلدية والتجميل والعلاج بالليزر",
          departmentId = dermaId,
          phone = "772345678",
          qualification = "زمالة الأمراض الجلدية والليزر",
          contractType = "نسبة",
          sharePercent = 35.0,
          balanceDues = 35000.0,
          workDays = "الأحد - الخميس",
          workHours = "11:00 - 19:00"
        )
      )
      dao.insertMedicalStaff(
        MedicalStaff(
          name = "مروة العولقي",
          role = "ممرضة رئيسية",
          specialty = "تمريض عام ورعاية سريرية",
          departmentId = dentalId,
          phone = "773456789",
          qualification = "بكالوريوس علوم تمريض",
          contractType = "راتب شهري",
          monthlySalary = 180000.0,
          balanceDues = 0.0
        )
      )

      // General Staff
      dao.insertGeneralStaff(
        GeneralStaff(
          fullName = "ماجد القدسي",
          jobTitle = "موظف استقبال واستعلامات",
          department = "الاستقبال",
          phone = "770112233",
          nationalId = "109823441",
          address = "صنعاء - التحرير",
          hireDate = "2023-01-15",
          monthlySalary = 120000.0,
          allowances = 15000.0,
          bonuses = 10000.0,
          advances = 0.0,
          deductions = 5000.0,
          netSalary = 140000.0
        )
      )
      dao.insertGeneralStaff(
        GeneralStaff(
          fullName = "فاطمة الزهراء البعداني",
          jobTitle = "محاسب مالي رئيسي",
          department = "الإدارة والمالية",
          phone = "770223344",
          nationalId = "109832115",
          address = "صنعاء - حدة",
          hireDate = "2023-03-01",
          monthlySalary = 160000.0,
          allowances = 20000.0,
          bonuses = 15000.0,
          advances = 10000.0,
          deductions = 0.0,
          netSalary = 185000.0
        )
      )

      // Package Definitions
      val pkgDef1 = dao.insertPackageDefinition(
        PackageDefinition(
          name = "باقة علاج طبيعي مكثفة (10 جلسات)",
          departmentId = physioId,
          departmentName = "قسم العلاج الطبيعي والتأهيل",
          totalSessions = 10,
          price = 80000.0,
          validityDays = 60
        )
      )
      val pkgDef2 = dao.insertPackageDefinition(
        PackageDefinition(
          name = "باقة تجميل ونضارة البشرة (4 جلسات)",
          departmentId = dermaId,
          departmentName = "قسم الجلدية والتجميل والليزر",
          totalSessions = 4,
          price = 65000.0,
          validityDays = 90
        )
      )

      // Initial Patients
      val p1 = dao.insertPatient(
        Patient(
          patientCode = "P-1001",
          fullName = "محمد عبدالله الحميري",
          phone = "777123987",
          address = "حدة - شارع بيروت",
          gender = "ذكر",
          birthDate = "1988-05-14",
          age = 36,
          emergencyRelation = "أخ - علي",
          emergencyPhone = "777987654",
          departmentId = dentalId,
          referralSource = "مباشر",
          notes = "يعاني من تحسس البنسلين"
        )
      )
      val p2 = dao.insertPatient(
        Patient(
          patientCode = "P-1002",
          fullName = "أميرة خالد السقاف",
          phone = "775667788",
          address = "شارع عمان",
          gender = "أنثى",
          birthDate = "1994-11-20",
          age = 30,
          emergencyRelation = "زوج - ياسر",
          emergencyPhone = "775990011",
          departmentId = physioId,
          referralSource = "توصية مريض سابق",
          notes = "إصابة انزلاق غضروفي قطني L4-L5"
        )
      )
      val p3 = dao.insertPatient(
        Patient(
          patientCode = "P-1003",
          fullName = "عمر صالح اليافعي",
          phone = "773322110",
          address = "حي الأصبحي",
          gender = "ذكر",
          birthDate = "1975-02-10",
          age = 49,
          emergencyRelation = "ابن - أسامة",
          emergencyPhone = "773344556",
          departmentId = dentalId,
          referralSource = "طبيب خارجي",
          notes = "مريض سكري وضغط"
        )
      )

      // Initial Medical Cases (الأمراض والحالات)
      val case1 = dao.insertMedicalCase(
        MedicalCase(
          caseCode = "CAS-0001",
          patientId = p2,
          patientName = "أميرة خالد السقاف",
          title = "انزلاق غضروفي قطني L4-L5 مع ألم عصب الورك",
          registrationDate = "2026-08-15",
          doctorId = doc2,
          doctorName = "د. أحمد المنصوري",
          departmentId = physioId,
          departmentName = "قسم العلاج الطبيعي والتأهيل",
          serviceId = 5,
          serviceName = "جلسة علاج طبيعي ظهر وفقرات",
          status = "نشطة",
          notes = "خطة علاجية 10 جلسات تأهيل وتقوية عضلات الجذع",
          attachments = "رنين مغناطيسي MRI للفقرات القطنية"
        )
      )
      val case2 = dao.insertMedicalCase(
        MedicalCase(
          caseCode = "CAS-0002",
          patientId = p1,
          patientName = "محمد عبدالله الحميري",
          title = "التهاب دواعم السن وترسبات كلسية شديدة",
          registrationDate = "2026-09-10",
          doctorId = doc1,
          doctorName = "د. وسيم الفرح",
          departmentId = dentalId,
          departmentName = "قسم الأسنان وجراحة الفم",
          serviceId = 2,
          serviceName = "تنظيف وتلميع أسنان شامل",
          status = "مكتملة",
          notes = "تم إجراء التنظيف وجراحة كحت لثة مصغرة بنجاح",
          attachments = "أشعة بانوراما رقمية"
        )
      )

      // Initial Patient Package for P2
      val pkg2 = dao.insertPatientPackage(
        PatientPackage(
          patientId = p2,
          packageDefId = pkgDef1,
          packageName = "باقة علاج طبيعي مكثفة (10 جلسات)",
          totalSessions = 10,
          usedSessions = 9,
          remainingSessions = 1, // Alert condition: 1 session remaining!
          purchaseDate = "2026-08-15",
          expiryDate = "2026-10-15",
          price = 80000.0,
          paidAmount = 80000.0,
          remainingBalance = 0.0,
          status = "نشطة"
        )
      )

      // Initial Clinical Sessions (الجلسات)
      dao.insertClinicalSession(
        ClinicalSession(
          sessionCode = "SES-0001",
          patientId = p2,
          patientName = "أميرة خالد السقاف",
          doctorId = doc2,
          doctorName = "د. أحمد المنصوري",
          packageId = pkg2,
          packageName = "باقة علاج طبيعي مكثفة (10 جلسات)",
          caseId = case1,
          sessionNumber = 9,
          sessionDate = "2026-09-20",
          checkInTime = "11:00",
          checkOutTime = "11:45",
          status = "مكتملة",
          notes = "تحسن كبير في مدى الحركة مع انخفاض الألم 70%",
          sessionTransactionId = "STX-20260920-P2-09",
          isDeducted = true
        )
      )

      // Initial Appointments
      dao.insertAppointment(
        Appointment(
          appointmentCode = "APT-0001",
          patientId = p1,
          patientName = "محمد عبدالله الحميري",
          patientPhone = "777123987",
          departmentId = dentalId,
          departmentName = "قسم الأسنان وجراحة الفم",
          serviceId = 2,
          serviceName = "تنظيف وتلميع أسنان شامل",
          doctorId = doc1,
          doctorName = "د. وسيم الفرح",
          appointmentDate = "2026-09-24",
          startTime = "10:00",
          endTime = "10:30",
          status = "تم الحضور",
          notes = "جلسة تنظيف وتلميع دورية"
        )
      )
      dao.insertAppointment(
        Appointment(
          appointmentCode = "APT-0002",
          patientId = p2,
          patientName = "أميرة خالد السقاف",
          patientPhone = "775667788",
          departmentId = physioId,
          departmentName = "قسم العلاج الطبيعي والتأهيل",
          serviceId = 5,
          serviceName = "جلسة علاج طبيعي ظهر وفقرات",
          doctorId = doc2,
          doctorName = "د. أحمد المنصوري",
          appointmentDate = "2026-09-24",
          startTime = "11:00",
          endTime = "11:45",
          status = "في الانتظار",
          notes = "جلسة الباقة الأخيرة رقم 10"
        )
      )
      dao.insertAppointment(
        Appointment(
          appointmentCode = "APT-0003",
          patientId = p3,
          patientName = "عمر صالح اليافعي",
          patientPhone = "773322110",
          departmentId = dentalId,
          departmentName = "قسم الأسنان وجراحة الفم",
          serviceId = 3,
          serviceName = "حشو تجميلي ليزري",
          doctorId = doc1,
          doctorName = "د. وسيم الفرح",
          appointmentDate = "2026-09-25",
          startTime = "16:00",
          endTime = "16:45",
          status = "مؤكد",
          notes = "الضرس العلوي الأيمن"
        )
      )

      // Initial Timeline
      dao.insertTimeline(
        PatientTimeline(
          patientId = p1,
          visitDate = "2026-08-10",
          doctorName = "د. وسيم الفرح",
          serviceName = "كشفية واستشارة أسنان",
          diagnosis = "التهاب لثة خفيف مع ترسبات جيرية",
          prescription = "غسول فم كلورهيكسيدين + مسكن بروفين 400",
          attachmentTitle = "بانوراما أسنان رقمية",
          attachmentType = "أشعة",
          notes = "تحتاج لتنظيف جير كامل في الزيارة القادمة"
        )
      )

      // Initial Finance Transactions (Double Entry Bookkeeping records)
      dao.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = "REC-000001",
          docType = "سند قبض",
          date = "2026-09-24",
          amount = 12000.0,
          paymentMethod = "نقداً",
          payerOrBeneficiary = "محمد عبدالله الحميري",
          patientId = p1,
          debitAccount = "الصندوق الرئيسي (نقدية)",
          creditAccount = "إيرادات كشوفات ومعاينات العيادات",
          previousBalance = 0.0,
          finalBalance = 12000.0,
          notes = "رسوم تنظيف وتلميع أسنان شامل"
        )
      )
      dao.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = "REC-000002",
          docType = "سند قبض",
          date = "2026-08-15",
          amount = 80000.0,
          paymentMethod = "شبكة / بنك",
          payerOrBeneficiary = "أميرة خالد السقاف",
          patientId = p2,
          debitAccount = "حساب بنك الكريمي للتمويل",
          creditAccount = "إيرادات باقات العلاج الطبيعي والتأهيل",
          previousBalance = 0.0,
          finalBalance = 80000.0,
          notes = "قيمة باقة علاج طبيعي 10 جلسات"
        )
      )
      dao.insertFinanceTransaction(
        FinanceTransaction(
          docNumber = "PAY-000001",
          docType = "سند صرف",
          date = "2026-09-22",
          amount = 25000.0,
          paymentMethod = "نقداً",
          payerOrBeneficiary = "مؤسسة التجهيزات الطبية",
          debitAccount = "مصروفات مستلزمات طبية وأدوية",
          creditAccount = "الصندوق الرئيسي (نقدية)",
          previousBalance = 25000.0,
          finalBalance = 0.0,
          notes = "شراء كمامات ومطهرات وقفازات طبية"
        )
      )

      // Initial Notifications (مركز الإشعارات الموحد)
      dao.insertNotification(
        AppNotification(
          title = "تنبيه باقة علاجية أوشكت على النفاد",
          message = "المريضة أميرة خالد السقاف متبقي لها جلسة واحدة (1) فقط في باقة العلاج الطبيعي.",
          type = "انتهاء باقة",
          date = "2026-09-24 10:00"
        )
      )
      dao.insertNotification(
        AppNotification(
          title = "حضور مريض للعيادة",
          message = "تم تسجيل حضور المريض محمد عبدالله الحميري لعيادة د. وسيم الفرح.",
          type = "حضور مريض",
          date = "2026-09-24 09:55"
        )
      )
      dao.insertNotification(
        AppNotification(
          title = "سند قبض جديد",
          message = "تم إصدار سند قبض رقم REC-000001 بمبلغ 12,000 ر.ي للمريض محمد الحميري.",
          type = "سند قبض",
          date = "2026-09-24 09:58"
        )
      )

      // Initial Audit Log
      dao.insertAuditLog(
        AuditLog(
          username = "admin",
          userRole = "المدير",
          action = "إضافة مريض",
          targetEntity = "سجل مريض",
          entityId = "P-1001",
          oldValue = "جديد",
          newValue = "محمد عبدالله الحميري",
          dateFormatted = "2026-09-24 09:30"
        )
      )

      // Message Templates (مطابقة تماماً للمواصفات المطلوبة في القسم 12)
      dao.insertTemplate(
        MessageTemplate(
          key = "session_attendance",
          title = "حضور جلسة وخصم",
          templateBody = "تم تسجيل حضوركم للجلسة، وتم خصم جلسة واحدة. المتبقي لكم {REMAINING} جلسات.\n{CENTER_NAME} يتمنى لكم دوام الصحة والعافية.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "receipt",
          title = "سند قبض مالي",
          templateBody = "تم استلام {AMOUNT} ريال. الرصيد السابق {PREV_BALANCE} ريال، والرصيد الحالي {FINAL_BALANCE} ريال.\nشكراً لتعاملكم مع {CENTER_NAME}.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "payment",
          title = "سند صرف مالي",
          templateBody = "تم تسجيل صرف {AMOUNT} ريال. الرصيد السابق {PREV_BALANCE} ريال، والمتبقي {FINAL_BALANCE} ريال.\n{CENTER_NAME}.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "new_case_doctor",
          title = "حالة جديدة للطبيب",
          templateBody = "تم تسجيل حالة جديدة للمريض {PATIENT_NAME} مرتبطة بك. يرجى مراجعة الحالة من النظام.\n{CENTER_NAME}.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "welcome",
          title = "ترحيب وفتح ملف جديد",
          templateBody = "مرحباً بكم أخي الكريم / أختي الفاضلة في {CENTER_NAME} 🏥.\nيسعدنا انضمامكم إلينا ونتشرف بخدمتكم دائماً.\nتم تسجيل ملفكم الطبي بنجاح برقم: {PATIENT_ID}.\nنتمنى لكم دوام الصحة والعافية.\n{DEVELOPER_TAG}"
        )
      )
      dao.insertTemplate(
        MessageTemplate(
          key = "appointment_reminder",
          title = "تذكير بموعد الحضور",
          templateBody = "مرحباً {PATIENT_NAME} 🌸،\nنود تذكيركم بموعدكم القادم في {CENTER_NAME}:\n📅 التاريخ: {DATE}\n⏰ الوقت: {TIME}\n👨‍⚕️ الطبيب: {DOCTOR_NAME}\n🩺 الخدمة: {SERVICE_NAME}\nيرجى التكرم بالحضور قبل الموعد بـ 10 دقائق.\nللتواصل: {PHONE}\n{DEVELOPER_TAG}"
        )
      )
    }
  }
}
